#!/bin/sh
# ==== ISP FIRST GATE - prerequisite tooling: python3 + git + gcloud ====
# sh (NOT Python) on purpose: /bin/sh is ALWAYS present, so this gate runs even if
# python/git/gcloud are missing and can detect them - a Python hook cannot (if python is
# gone, no python hook runs). If ANY of the three is missing the whole ISP safety layer is
# compromised -> BLOCK everything.
# FAIL-CLOSED: default is to block; the script reaches "exit 0" ONLY on the explicit
# all-clear path. Wired on UserPromptSubmit + PreToolUse (exit 2 = block) and SessionStart
# (message). python3 + git come from the rule in find-python.sh (system root, file + every parent
# folder root-owned) - the SAME interpreter run-hook.sh uses for every hook; python3 is also checked
# for version >= 3.9 under -E -S, as the hooks run it. gcloud: presence only (it runs no
# guard), via `command -v`.
# No environment variable is read (no test seam): the user controls the environment.
here=${0%/*}
. "$here/find-python.sh"
miss=""
if [ -n "$PY" ]; then
  "$PY" -E -S -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)' 2>/dev/null || miss="$miss python3(>=3.9)"
else
  miss="$miss python3"
fi
[ -n "$GIT" ] || miss="$miss git"
command -v gcloud >/dev/null 2>&1 || miss="$miss gcloud"
if [ -n "$miss" ]; then
  echo "BLOCKED by ISP policy [FIRST GATE]: required tooling missing:$miss. The ISP safety layer cannot run without it. Install git + python3 (Xcode Command Line Tools) / gcloud (Google Cloud CLI), then restart Claude Code." >&2
  exit 2
fi
exit 0
