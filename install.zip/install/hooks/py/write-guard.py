"""PreToolUse(Edit|Write) hook — confine writes to the project root (sandbox emulation).

Confine writes to the working directory. Until the OS sandbox is
in place this hook emulates that for the Edit/Write tools: any tool_input.file_path that
escapes the project root (workspace.project_dir / CLAUDE_PROJECT_DIR) is blocked, except
~/.claude (Claude Code's own state - Plan Mode files, auto-memory, etc.), symmetric with
read-guard's allowlist. .claude/.credentials.json still has its own permissions.deny.
Reads are NOT restricted here (see read-guard). PANIC-aware. exit 2 = block.

Note: this covers Claude's Edit/Write tools (reliable, absolute file_path). Writes issued
via Bash redirects to an outside path are the OS sandbox's job (bash-guard only blocks the
obvious cases + cd-escape).
"""
import os
import sys
import isp_hooks as h


def main():
    d = h.read_stdin_json()
    h.panic_block()

    fp = (d.get("tool_input") or {}).get("file_path") or ""
    if not fp:
        sys.exit(0)  # nothing to confine

    root = h.project_root(d)
    if h.path_within(fp, root):
        sys.exit(0)

    claude_dir = os.path.join(os.path.expanduser("~"), ".claude")
    if h.path_within(fp, claude_dir):
        sys.exit(0)

    h.block("Write to '%s' is OUTSIDE the project directory. Writes are confined to the "
            "project root (workspace.project_dir) + ~/.claude (Claude Code's own state). "
            "(Sandbox emulation - see pending/sandbox/)." % fp)


if __name__ == "__main__":
    h.run_guard(main, "write-guard")
