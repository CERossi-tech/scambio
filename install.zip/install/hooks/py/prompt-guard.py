"""UserPromptSubmit hook — block prompts containing pasted credentials.

Scope: secrets/credentials only (unique high-signal prefixes). General PII
(IBAN/codice fiscale/PAN) is intentionally NOT scanned here — see hooks/README
(customer data = data-minimization + DLP, Phase 2).
exit 2 = block (the prompt is not submitted).
"""
import re
import sys
import isp_hooks as h

PATTERNS = [
    (r"AKIA[0-9A-Z]{16}", "AWS access key id"),
    (r"(?i)aws_secret_access_key\s*=\s*['\"]?[A-Za-z0-9/+=]{40}", "AWS secret access key"),
    (r"-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----", "Private key (PEM)"),
    # JWT: an example JWT is byte-identical to a real one -> a pasted doc example
    # is still blocked (committed JWTs are separately caught by secret-scan).
    (r"eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}", "JWT"),
    # Bearer (anchored): token must be >=20 chars AND contain a digit, so an
    # English phrase ("bearer" + hyphenated words, no digit) is NOT matched.
    (r"(?i)bearer\s+(?=[A-Za-z0-9._+/=-]{20,})[A-Za-z0-9._+/=-]*[0-9][A-Za-z0-9._+/=-]*", "Bearer token"),
    (r"ya29\.[A-Za-z0-9_-]{20,}", "Google OAuth token"),
    (r"AIza[A-Za-z0-9_-]{35}", "Google API key"),
    (r"sk-ant-api[0-9]+-[A-Za-z0-9_-]{20,}", "Anthropic API key"),
    (r"ghp_[A-Za-z0-9]{36}", "GitHub personal token"),
    (r"glpat-[A-Za-z0-9_-]{20,}", "GitLab personal token"),
    (r"xox[baprs]-[A-Za-z0-9-]{10,}", "Slack token"),
]
COMPILED = [(re.compile(p), lbl) for p, lbl in PATTERNS]


def main():
    d = h.read_stdin_json()
    prompt = d.get("prompt") or d.get("user_input") or ""
    # System-generated task-notifications (background-agent results re-injected as a prompt)
    # are NOT a user secret-entry channel: they can legitimately quote example keys from
    # docs/summaries, and blocking them is post-hoc (the work already ran). prompt-guard's
    # scope is genuine USER prompt input -> skip system task-notifications.
    if prompt.lstrip().startswith("<task-notification"):
        sys.exit(0)
    findings = h.scan_text(prompt, COMPILED)   # raw + de-obfuscated (anti split-evasion)
    if findings:
        h.log_siem({"type": "secret_in_prompt", "findings": findings,
                    "session": d.get("session_id", "")})
        h.block("the prompt contains what looks like a secret (%s). "
                "Remove it before submitting." % ", ".join(findings))
    sys.exit(0)


if __name__ == "__main__":
    h.run_guard(main, "prompt-guard")
