"""SessionStart + PreToolUse(.*) gate — validity + coherence of Vertex/telemetry config (per-dir).

Reads <project_dir>/.claude/settings.local.json (the user's PERSONAL, non-committed
file, written by set-vertex-project). project_dir is anchored to CLAUDE_PROJECT_DIR
(the folder where Claude was launched) so the check is STABLE even if the working
directory changes mid-session (e.g. `cd` into a subfolder); falls back to the stdin
cwd, then getcwd().

BLOCKS every tool (PreToolUse -> exit 2) if even ONE condition is not met:

  EXISTENCE
   - ANTHROPIC_VERTEX_PROJECT_ID present and non-empty
   - OTEL_RESOURCE_ATTRIBUTES present
   - gcp.project_id, developer.id, isp.project_id present in OTEL
  FORMAT
   - isp.project_id: starts with PRG / STRE / RELE / OPEX (prefix check, not format-bound)
  COHERENCE
   - gcp.project_id (OTEL) == ANTHROPIC_VERTEX_PROJECT_ID
   - developer.id (OTEL) == ISP userid of the user who starts Claude (isp_hooks.resolve_userid())
   - isp.pkg_version (OTEL) present and == 'version' in the managed config/version.json (fail-closed)

Note: reads from settings.local.json (not from env) because OTEL_RESOURCE_ATTRIBUTES is
scrubbed from the subprocess env. Remedy: run set-vertex-project in the folder
where you start Claude, then restart.
- PreToolUse: exit 2 (blocks the tool) with a specific reason.
- SessionStart / other: guidance system message (tools stay blocked by PreToolUse).
"""
import json
import os
import re
import sys
import isp_hooks as h

REMEDY = ("Invalid Vertex/telemetry config. From the folder where you start Claude, run "
          "set-vertex-project (.cmd on Windows / .sh on macOS), then restart Claude Code.")
_LITERAL = ("", "${USER}", "${USERNAME}")
# Prefix-only sanity check: must START WITH PRG/STRE/RELE/OPEX. Deliberately NOT tied to a rigid
# format (real validation is server-side; a strict pattern risks rejecting valid PNOW keys).
# Keep in sync with set-vertex-project.py ISP_RE.
ISP_RE = re.compile(r"^(?:PRG|STRE|RELE|OPEX)")


def _read_env(cwd):
    path = os.path.join(cwd or os.getcwd(), ".claude", "settings.local.json")
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f).get("env") or {}
    except Exception:
        return {}


def _adc_quota_project(env):
    """Returns quota_project_id from ADC credentials file. `env` is the settings.local.json
    env dict (same source as ANTHROPIC_VERTEX_PROJECT_ID/OTEL_RESOURCE_ATTRIBUTES) —
    GOOGLE_APPLICATION_CREDENTIALS must be read from there, not os.environ, for the same
    reason OTEL_RESOURCE_ATTRIBUTES is (see module docstring: scrubbed from the subprocess
    env). Raises RuntimeError if absent, unreadable, or quota_project_id not set (all
    treated as misconfig — fail-closed)."""
    path = h.test_value("CLAUDE_ADC_FILE")   # test-seam (cf. CLAUDE_VERSION_FILE)
    if not path:
        path = (env.get("GOOGLE_APPLICATION_CREDENTIALS") or "").strip() or None
    if not path:
        if sys.platform == "win32":
            base = os.environ.get("APPDATA", "")
        else:
            base = os.path.join(os.path.expanduser("~"), ".config")
        path = os.path.join(base, "gcloud", "application_default_credentials.json")
    try:
        with open(path, encoding="utf-8") as f:
            val = json.load(f).get("quota_project_id") or ""
    except FileNotFoundError:
        raise RuntimeError("ADC credentials not found (%s) — run set-vertex-project" % path)
    except Exception as e:
        raise RuntimeError("cannot read ADC credentials: %s" % e)
    if not val:
        raise RuntimeError("quota_project_id not set in ADC credentials — run set-vertex-project")
    return val


def _pkg_version():
    """Returns the declared install-package version from the managed config/version.json.
    Raises RuntimeError if the file is absent/unreadable or 'version' is empty (fail-closed:
    a missing version.json is a deploy issue, not a silent pass)."""
    path = h.test_value("CLAUDE_VERSION_FILE")   # test-seam (cf. CLAUDE_EGRESS_ALLOWLIST)
    if not path:
        if sys.platform == "win32":
            path = r"C:\Program Files\ClaudeCode\config\version.json"
        else:
            path = "/Library/Application Support/ClaudeCode/config/version.json"
    try:
        with open(path, encoding="utf-8") as f:
            val = (json.load(f).get("version") or "").strip()
    except FileNotFoundError:
        raise RuntimeError("package version file not found (%s) — deploy issue" % path)
    except Exception as e:
        raise RuntimeError("cannot read package version file: %s" % e)
    if not val:
        raise RuntimeError("version not set in %s — deploy issue" % path)
    return val


def _parse_otel(s):
    out = {}
    for part in (s or "").split(","):
        if "=" in part:
            k, v = part.split("=", 1)
            out[k.strip()] = v.strip()
    return out


def validate(cwd):
    """Returns (ok, reason). ok=False -> block."""
    env = _read_env(cwd)
    p = (env.get("ANTHROPIC_VERTEX_PROJECT_ID") or "").strip()
    otel_raw = env.get("OTEL_RESOURCE_ATTRIBUTES")
    otel = _parse_otel(otel_raw)
    dev = (otel.get("developer.id") or "").strip()
    gpid = (otel.get("gcp.project_id") or "").strip()
    isp = (otel.get("isp.project_id") or "").strip()
    try:
        uid = h.resolve_userid()
    except Exception as e:
        # e carries the full, paste-friendly fix (klist/PSSO/password). Point to the doctor too.
        return False, "cannot resolve the ISP matricola (identity gate) — %s [run set-vertex-project-doctor]" % e

    # --- existence ---
    if not p:
        return False, "ANTHROPIC_VERTEX_PROJECT_ID missing"
    if not otel_raw:
        return False, "OTEL_RESOURCE_ATTRIBUTES missing"
    if not gpid:
        return False, "gcp.project_id missing from OTEL_RESOURCE_ATTRIBUTES"
    if dev in _LITERAL:
        return False, "developer.id missing or unresolved in OTEL_RESOURCE_ATTRIBUTES"
    if not isp:
        return False, "isp.project_id missing from OTEL_RESOURCE_ATTRIBUTES"
    # --- format ---
    if not ISP_RE.match(isp):
        return False, ("isp.project_id '%s' invalid "
                       "(must start with PRG, STRE, RELE, or OPEX)" % isp)
    # --- coherence ---
    if gpid != p:
        return False, "gcp.project_id (%s) != ANTHROPIC_VERTEX_PROJECT_ID (%s)" % (gpid, p)
    if dev != uid:
        return False, "developer.id (%s) != current user (%s)" % (dev, uid)
    # --- ADC quota project coherence (fail-closed) ---
    try:
        adc_qp = _adc_quota_project(env)
    except Exception as e:
        return False, str(e)
    if adc_qp != p:
        return False, "ADC quota_project_id (%s) != ANTHROPIC_VERTEX_PROJECT_ID (%s)" % (adc_qp, p)
    # --- package version coherence (fail-closed): declared version.json == settings.local.json ---
    pkg = (otel.get("isp.pkg_version") or "").strip()
    try:
        declared = _pkg_version()
    except Exception as e:
        return False, str(e)
    if not pkg:
        return False, "isp.pkg_version missing from OTEL_RESOURCE_ATTRIBUTES — run set-vertex-project"
    if pkg != declared:
        return False, ("isp.pkg_version (%s) != declared package version (%s) — run set-vertex-project"
                       % (pkg, declared))

    return True, ""


def banner(cwd):
    """Banner shown to the user at SessionStart: the 3 config vars, one per line."""
    env = _read_env(cwd)
    otel = _parse_otel(env.get("OTEL_RESOURCE_ATTRIBUTES"))
    dev = (otel.get("developer.id") or "-").strip() or "-"
    gcp = (env.get("ANTHROPIC_VERTEX_PROJECT_ID") or "-").strip() or "-"
    isp = (otel.get("isp.project_id") or "-").strip() or "-"
    pkg = (otel.get("isp.pkg_version") or "-").strip() or "-"
    return ("usr:%s\ngcp:%s\nisp.prj:%s\npkg:%s\n"
            "To change these 3 values, run set-vertex-project (.cmd Windows / .sh macOS) "
            "from the folder where you start Claude." % (dev, gcp, isp, pkg))


def _project_dir(d):
    """Anchor to the launch/project root (CLAUDE_PROJECT_DIR), stable across `cd`.
    The stdin 'cwd' follows the working dir; the env var does not. Fallbacks:
    stdin cwd, then getcwd()."""
    return os.environ.get("CLAUDE_PROJECT_DIR") or d.get("cwd") or os.getcwd()


def main():
    d = h.read_stdin_json()
    proj = _project_dir(d)
    ok, reason = validate(proj)
    if d.get("hook_event_name", "") == "PreToolUse":
        if not ok:
            h.block(h.box("⚠  Invalid Vertex/telemetry config", [REMEDY, "reason: " + reason]))   # exit 2 -> tool blocked
        sys.exit(0)
    # SessionStart (and any other non-PreToolUse): ALWAYS banner + remedy if invalid
    out = banner(proj)
    if not ok:
        out += "\n" + h.box("⚠  Invalid Vertex/telemetry config", [REMEDY, "reason: " + reason])
    h.system_message(out)
    sys.exit(0)


if __name__ == "__main__":
    h.run_guard(main, "vertex-guard")
