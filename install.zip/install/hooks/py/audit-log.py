"""ConfigChange (and generic) audit-log hook — cross-platform Python.

Two modes:
  1) args: log argv as the message (session-audit calls it this way).
  2) no args: read JSON on stdin and build "<event> sid=<id>".

Writes via isp_hooks.audit_log (mac syslog / file fallback). Never blocks.
"""
import sys
import isp_hooks as h


def main():
    if len(sys.argv) > 1:
        msg = " ".join(sys.argv[1:])
    else:
        d = h.read_stdin_json()
        sid = d.get("session_id") or "?"
        evt = d.get("hook_event_name") or "event"
        msg = "%s sid=%s" % (evt, sid)
    h.audit_log(msg)
    sys.exit(0)


if __name__ == "__main__":
    h.run_guard(main, "audit-log")
