"""PreToolUse(mcp__.*|WebFetch) hook — MCP lockdown + WebFetch domain allowlist.

1. MCP: disabled fleet-wide EXCEPT mcp__ide__* (VS Code/JetBrains built-in) and
   mcp__isp-* (ISP marketplace plugins; naming enforced by the ISP marketplace).
   Defense-in-depth (4th layer), fail-closed.
2. WebFetch (enforce domain allowlist; block disallowed external fetches):
   parse tool_input.url, deny hosts in the denylist first
   (metadata SSRF, provider pin, third-party LLM APIs), then require the host to
   match the allowlist (egress-domains.json) - a hostname-only denylist can't
   see the query string, so a non-denied host would otherwise fetch arbitrary
   "?d=<data>" verbatim, a working exfiltration path. ISP internal domains are
   ordinary allowedHosts wildcard entries (*.intesasanpaolo.com etc.) - no separate
   bypass, so every allowed domain is visible in one reviewable place. On allow,
   sys.exit(0) lets the native WebFetch tool actually run - this hook only decides,
   it doesn't fetch.
"""
import sys
from urllib.parse import urlparse
import isp_hooks as h


def main():
    d = h.read_stdin_json()
    tool = d.get("tool_name", "") or ""

    if tool.startswith("mcp__"):
        if tool.startswith("mcp__ide__") or tool.startswith("mcp__isp-"):
            sys.exit(0)
        h.deny("MCP is disabled fleet-wide except mcp__ide__* (VS Code/JetBrains "
               "built-in) and mcp__isp-* (ISP marketplace plugins). Tool '%s' rejected." % tool)

    if tool == "WebFetch":
        url = (d.get("tool_input") or {}).get("url", "") or ""
        if not url:
            sys.exit(0)
        try:
            hostname = urlparse(url).hostname or ""
        except Exception:
            h.deny("WebFetch: cannot parse URL '%s'" % url)
        if h.host_matches(hostname, h.load_egress_denylist()):
            h.deny("WebFetch to '%s' explicitly denied by ISP policy (cyber) - "
                   "see egress-domains.json deniedHosts" % hostname)
        if not h.host_matches(hostname, h.load_egress_allowlist() or []):
            h.deny("WebFetch to '%s' not authorized: not in the ISP allowlist "
                   "(egress-domains.json allowedHosts)" % hostname)
        sys.exit(0)

    # WebSearch has no URL to filter -> pass; permissions.ask prompt still fires
    sys.exit(0)


if __name__ == "__main__":
    h.run_guard(main, "egress-guard")
