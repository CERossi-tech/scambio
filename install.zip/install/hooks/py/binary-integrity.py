"""binary-integrity hook — verify the running claude binary vs manifest.json.

Registered on SessionStart (startup|resume) AND UserPromptSubmit (throttled).

SessionStart: full check (path + SHA256); writes state <proj>/.claude/.binary-integrity-state.
UserPromptSubmit: reads state.
  - result == failed  OR state missing  ->  re-check + BLOCK if still fails.
  - result == ok  AND  age < TTL        ->  skip (zero overhead).
  - result == ok  AND  age >= TTL       ->  re-check + update state.

Dedicated state file (NOT shared with settings-consistency): all matching hooks run
in PARALLEL (Claude Code harness), so a shared file would race — the slower writer
(this hook, ~2s SHA of the 236MB binary) would clobber the faster one's update.

TTL and all parameters are HARDCODED (security-posture constants, not env-overridable).
"""
import json
import os
import sys
import time
import isp_hooks as h

TTL_SECONDS = 60   # re-check cadence for UserPromptSubmit — hardcoded, not env-overridable


def _state_path(proj):
    return os.path.join(proj, ".claude", ".binary-integrity-state")


def _read_state(proj):
    try:
        with open(_state_path(proj), encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _write_state(proj, result):
    p = _state_path(proj)
    try:
        os.makedirs(os.path.dirname(p), exist_ok=True)
        tmp = "%s.%d.tmp" % (p, os.getpid())
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump({"result": result, "checked_at": time.time()}, f)
        os.replace(tmp, p)
    except Exception as e:
        h.audit_log("binary-integrity state write failed type=%s" % type(e).__name__)


def get_event():
    raw = h.read_stdin_raw()
    if raw:
        try:
            d = json.loads(raw)
            return d.get("hook_event_name") or "SessionStart", d
        except Exception:
            pass
    return "SessionStart", {}


def fail_open(event, reason):
    """SessionStart: warn only (SessionStart cannot block). Returns False."""
    h.system_message("WARN binary-integrity: %s." % reason)
    return False


def do_block(event, reason):
    h.log_siem({"type": "binary_integrity_violation", "reason": reason, "event": event})
    if event == "UserPromptSubmit":
        h.halt_turn(h.box("Blocco integrita binario Claude Code",
                          [reason, "Contatta IT/Security."]))
    sys.stderr.write("BLOCKED by ISP policy: " + reason + "\n")
    sys.exit(2)


def _same(a, b):
    return os.path.normcase(os.path.normpath(a)) == os.path.normcase(os.path.normpath(b))


def _fail(event, reason):
    """On SessionStart -> warn+continue (return False). On UserPromptSubmit -> block."""
    if event == "SessionStart":
        return fail_open(event, reason)
    do_block(event, reason)


def _check(event):
    """Run path + SHA check. Returns True if ok; on failure warns (SessionStart) or blocks."""
    if not os.path.exists(h.MANIFEST):
        return _fail(event, "manifest.json not found at %s" % h.MANIFEST)
    try:
        with open(h.MANIFEST, encoding="utf-8") as f:
            manifest = json.load(f)
    except Exception:
        return _fail(event, "manifest.json parse error")

    plat = h.platform_key()
    info = (manifest.get("platforms") or {}).get(plat)
    if not info:
        return _fail(event, "platform '%s' not in manifest.json" % plat)
    expected_name = info.get("binary")
    expected_sha = (info.get("checksum") or "").lower()
    if not expected_name:
        return _fail(event, "platform '%s' has no binary in manifest.json" % plat)

    expected_path = os.path.join(h.BIN_DIR, expected_name)
    claude_path = h.resolve_claude_binary()
    if not claude_path:
        return _fail(event, "claude binary not found in the parent process chain")

    if not _same(claude_path, expected_path):
        do_block(event,
                 "binary path mismatch. Expected: '%s'. Actual: '%s'. "
                 "Only the admin-installed binary in %s is authorized."
                 % (expected_path, claude_path, h.BIN_DIR))

    actual = h.sha256_file(claude_path)
    if not actual:
        return _fail(event, "unable to compute SHA256 of %s" % claude_path)
    if actual != expected_sha:
        do_block(event,
                 "binary SHA256 mismatch. Expected: %s. Actual: %s. "
                 "Possible compromise — contact IT/Security." % (expected_sha, actual))

    h.log_siem({"type": "binary_integrity_ok", "path": claude_path,
                "sha": expected_sha, "platform": plat})
    return True


def main():
    event, d = get_event()
    proj = h.project_root(d)

    if event == "SessionStart":
        ok = _check(event)
        _write_state(proj, "ok" if ok else "failed")
        return

    # UserPromptSubmit
    st = _read_state(proj)
    result = st.get("result")
    try:
        age = time.time() - float(st.get("checked_at") or 0)
    except (TypeError, ValueError):
        age = -1          # malformed (user-writable) state: re-check

    # 0 <= age: the state file is user-writable, a checked_at in the future must not skip the re-check
    if result == "ok" and 0 <= age < TTL_SECONDS:
        sys.exit(0)    # fresh ok — skip

    ok = _check(event)                 # failed / missing / stale -> re-check (blocks if it fails)
    _write_state(proj, "ok" if ok else "failed")


if __name__ == "__main__":
    h.run_guard(main, "binary-integrity")
