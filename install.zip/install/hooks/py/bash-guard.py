"""PreToolUse(Bash) hook — destructive/exfil command guard + curl/wget block.

Single cross-platform guard: covers both unix (rm -rf, fork bomb, pipe-to-shell,
base64|sh) and Windows (Remove-Item, IEX base64, iwr|iex, AV/firewall disable)
destructive forms, the anchored matches (low false-positive), the
shell-redirect-into-guardrail-config -> ask, and a curl/wget block (they can't
authenticate to the corporate proxy from Bash - use WebFetch), WITH ONE NARROW
EXCEPTION: plain GET requests to an ISP-internal host (config/egress-domains.json
"internalHosts") are allowed, since those never leave the corporate network and
don't need proxy auth. Any explicit non-GET method (-X/--request/--method =
POST/PUT/PATCH/DELETE) or body/upload flag (-d/--data*/-F/--form/-T/--upload-file/
--post-data/--post-file/--body-data/--body-file) is still blocked unconditionally,
even to an internal host. Fail-closed: a command whose URL/host can't be
determined is blocked, not allowed.
PANIC-aware. exit 2 = block; permissionDecision:ask on stdout for the redirect case.

High-signal AV/AMSI tokens are FRAGMENTED (string concat) so no contiguous
signature ships on disk.
"""
import os
import re
import sys
from urllib.parse import urlparse
import isp_hooks as h

# --- destructive patterns (block, exit 2). Covers unix + Windows forms. ---
RM_UNIX = r'(?i)\brm\s+(-[a-z]*r[a-z]*f[a-z]*|-[a-z]*f[a-z]*r[a-z]*|-r\s+-f|-f\s+-r|--recursive\s+--force|--force\s+--recursive|--recursive\s+-f|-f\s+--recursive|-r\s+--force|--force\s+-r)[^;&|]*\s["\']?(/etc|/usr|/bin|/sbin|/var|/lib64|/lib|/boot|/dev|/proc|/sys|/root|/opt|/srv|/home|/System|/Library|/Applications|/Users|/private|/Volumes|/|~|\$HOME|\$\{HOME\})(/\*|/|\*)?["\']?(\s|$)'
RM_WIN = r'(?i)Remove-Item\s+(-Recurse\s+-Force|-Force\s+-Recurse|-r\s+-Force|-Recurse\s+-f)[^;&|]*?\s["\']?(C:\\Windows|C:\\Users|C:\\|\$env:USERPROFILE|\$env:SystemRoot|\$HOME)(\\\*|\\|\*)?["\']?(\s|$)'
# find targeting a root/system/home path with -delete or -exec rm (anchored like RM_UNIX -> low FP)
FIND_UNIX = r'(?i)\bfind\s+["\']?(/etc|/usr|/bin|/sbin|/var|/lib64|/lib|/boot|/dev|/proc|/sys|/root|/opt|/srv|/home|/System|/Library|/Applications|/Users|/private|/Volumes|/|~|\$HOME|\$\{HOME\})(/\*|/|\*)?["\']?\s[^;&|]*(-delete\b|-exec\s+rm\b)'

DESTRUCTIVE = [
    (RM_UNIX, "destructive recursive delete of a root/home/system path"),
    (RM_WIN, "destructive recursive delete of a root/home/system path"),
    (FIND_UNIX, "recursive deletion via find -delete/-exec rm of a root/home/system path"),
    (r"(?i)\bgit\b[^;&|]*\s--no-verify(\s|$)", "git verification bypass"),
    (r"(?i)core\.hooksPath[ =]/dev/null", "git verification bypass (hooksPath)"),
    (r"(?i)(^|[;&|]\s*)history\s+-c", "shell history tampering"),
    (r"(?i)(rm\s+[^ ]*\.(bash|zsh)_history|unset\s+HISTFILE)", "shell history tampering"),
    (r":\(\)\s*\{.*:\|:&.*\}\s*;\s*:", "fork bomb pattern"),
    (r"(?i)(curl|wget)\s+[^|]+\|\s*(sh|bash|dash|zsh|ksh)\b", "pipe-to-shell remote execution"),
    (r"(?i)(\|\s*(nc|ncat)\s|>\s*/dev/tcp/)", "network exfiltration via netcat/tcp"),
    (r"(?i)chmod\s+(-R\s+)?777", "world-writable permission change"),
    (r"(?i)(Set-MpPref" + r"erence\s+-DisableRealtimeMonitoring\s+\$true|netsh\s+adv" + r"firewall\s+set\s+.+\s+state\s+off)", "security service disable attempt (Windows)"),
    (r"(?i)(tar|zip|gzip|bzip2|xz|7z|base64|Compress-Archive|\[Convert\]::ToBase64" + r"String)[^|]*\|\s*(curl|wget|Invoke-WebRequest|iwr|Invoke-RestMethod|irm|nc|ncat|scp|sftp|rsync|aws\s+s3|gsutil|gcloud\s+storage|az\s+storage)\b", "archive/encoding piped to outbound transfer (potential exfiltration)"),
    (r"(?i)\[Convert\]::FromBase64" + r"String[^|]*\|\s*(iex\b|Invoke-Expression\b)", "base64 decode-and-execute (PowerShell payload obfuscation)"),
    (r"(?i)base64\s+(-d|-D|--decode)[^|]*\|\s*(sh|bash|dash|zsh|ksh|eval)\b", "base64 decode-and-execute (payload obfuscation)"),
    (r"(?i)(\b(iwr|Invoke-WebRequest|Invoke-RestMethod|irm)\b[^|]*\|\s*(iex\b|Invoke-Expression\b)|Net\.Web" + r"Client.*Download" + r"String[^|]*\|\s*(iex\b|Invoke-Expression\b)|\b(iex|Invoke-Expression)\b\s*\(\s*(iwr|Invoke-WebRequest|Invoke-RestMethod|irm)\b)", "download-and-execute PowerShell (iex + web fetch)"),
    (r"(?i)(csrutil disable|systemctl stop firewalld|ufw disable)", "security service disable attempt"),
]
DESTRUCTIVE_COMPILED = [(re.compile(p), r) for p, r in DESTRUCTIVE]

# --- shell write into a guardrail-config class -> ask ---
_PROT = r"(\.claude/|\.claude$|CLAUDE\.md|\.mcp\.json|\.github/workflows/|\.git/hooks/|\.husky/|risk-class\.json)"
REDIRECT_ASK = [
    re.compile(r'>>?\s*"?[^;&|]*' + _PROT),
    re.compile(r"(^|\s)tee(\s+-[^ ]+)*\s+[^;&|]*" + _PROT),
    re.compile(r"(^|\s)sed\s+[^;&|]*-i[^;&|]*" + _PROT),
    re.compile(r"(^|\s)dd\s+[^;&|]*of=[^;&|]*" + _PROT),
    re.compile(r"(?i)(Set-Content|Add-Content|Out-File|Tee-Object)\b[^;&|]*" + _PROT),
]

CURL_WORD = re.compile(r"(?i)(^|[^A-Za-z0-9_/.\-])(curl|wget)(\s|$)")

# --- GET-only exception for ISP-internal hosts (config/egress-domains.json
#     internalHosts). Any explicit non-GET method or body/upload flag disqualifies
#     the exception regardless of destination. ---
URL_RE = re.compile(r"(?i)\bhttps?://[^\s'\"|;&<>]+")
NON_GET_METHOD_RE = re.compile(
    r"(?i)(?:-X\s*|--request(?:=|\s+)|--method(?:=|\s+))(POST|PUT|PATCH|DELETE)\b")
# Explicit body/upload flags -> fast, obvious non-GET signal. File-write (-o/-O/-D/
# -c/--trace/...), proxy (-x/--proxy), DNS override (--resolve/--connect-to), options-
# from-file (-K) and multi-request (--next/-:) are NOT listed here: they are blocked by
# omission from the _flags_all_safe positive allowlist below (an allowlist can't be
# out-enumerated, and -O\b here would wrongly catch wget's safe stdout token -O-).
# NOTE: case-SENSITIVE (no (?i)): curl short flags are case-sensitive and differ in
# meaning by case — -f(--fail, safe GET) vs -F(--form, upload); -d(--data) vs -D(dump
# header); -t vs -T(--upload-file). A global (?i) made -F\b match -f and wrongly block a
# plain GET. Long flags are lowercase-canonical, so case-sensitive matching is correct.
BODY_UPLOAD_RE = re.compile(
    r"(^|\s)(-d\b|--data\b|--data-raw\b|--data-binary\b|--data-urlencode\b|"
    r"--data-ascii\b|--json\b|--body-data\b|--post-data\b|-T\b|--upload-file\b|"
    r"--post-file\b|--body-file\b|-F\b|--form\b)")


def is_non_get(cmd):
    return bool(NON_GET_METHOD_RE.search(cmd) or BODY_UPLOAD_RE.search(cmd))


# --- Positive allowlist of flags permitted on an internal-host GET. Anything NOT
#     listed here disqualifies the exception (fail-closed). A denylist can't be
#     exhaustive - curl has dozens of file-writing / redirecting flags (-o, -O, -D,
#     -c/--cookie-jar, --trace, --trace-ascii, --libcurl, --etag-save, ...) any of
#     which would let a "GET" write to disk or be redirected - so the exception is
#     gated on an allowlist of read-only, no-side-effect flags instead. Mirrors the
#     "only these params" contract documented in CLAUDE-security-rules.md. ---
_SAFE_LONG_NOARG = {
    "--silent", "--show-error", "--verbose", "--include", "--fail",
    "--location", "--compressed", "--quiet",            # last one: wget
}
_SAFE_LONG_ARG = {
    "--max-time", "--connect-timeout", "--header", "--user", "--user-agent",
    "--timeout",                                         # wget
}
_SAFE_SHORT_NOARG = set("sSvifLq")   # -s -S -v -i -f -L (curl), -q (wget)
_SAFE_SHORT_ARG = set("mHuA")        # -m -H -u -A


def _flags_all_safe(cmd):
    """True only if every dash-prefixed token is in the safe allowlist. Handles long
    options (--flag / --flag=val), short bundles (-sL, -sm30), separate-arg flags
    (-H 'Accept: x'), and the wget stdout token -O-. Unknown/unsafe flag -> False."""
    toks = cmd.split()
    i = 0
    while i < len(toks):
        t = toks[i]
        if t in ("curl", "wget") or not t.startswith("-") or t in ("-", "--", "-O-"):
            i += 1
            continue
        if t.startswith("--"):
            base = t.split("=", 1)[0]
            if base in _SAFE_LONG_NOARG:
                i += 1
            elif base in _SAFE_LONG_ARG:
                i += 1 if "=" in t else 2
            else:
                return False
            continue
        # short flag or bundle, e.g. -s / -sL / -m30 / -sm30 / -H
        chars = t[1:]
        j = 0
        consumed_next = False
        while j < len(chars):
            ch = chars[j]
            if ch in _SAFE_SHORT_NOARG:
                j += 1
                continue
            if ch in _SAFE_SHORT_ARG:
                consumed_next = (j == len(chars) - 1)  # value is next token, else inline
                break
            return False
        i += 2 if consumed_next else 1
    return True


def extract_hosts(cmd):
    hosts = []
    for m in URL_RE.finditer(cmd):
        try:
            host = urlparse(m.group(0)).hostname
        except Exception:
            host = None
        if host:
            hosts.append(host)
    return hosts


def is_internal_get(cmd):
    """True only if (a) every URL resolves to an ISP-internal host, (b) there is no
    explicit non-GET method/body/upload flag, and (c) every flag is in the read-only
    safe allowlist (_flags_all_safe). External hosts are never eligible."""
    hosts = extract_hosts(cmd)
    if not hosts or is_non_get(cmd) or not _flags_all_safe(cmd):
        return False
    internal = h.load_internal_hosts()
    return all(h.host_matches(host, internal) for host in hosts)

# --- heredoc bodies are DATA (e.g. a git commit message), not commands to execute -
#     strip them before pattern-scanning so prose mentioning "curl"/"rm -rf"/etc. in a
#     commit message or file content doesn't trigger a false block. ---
_HEREDOC_START = re.compile(r"<<-?\s*(['\"]?)(\w+)\1")


def _strip_heredocs(cmd):
    lines = cmd.split("\n")
    out = []
    i = 0
    while i < len(lines):
        out.append(lines[i])
        m = _HEREDOC_START.search(lines[i])
        if m:
            marker = m.group(2)
            i += 1
            while i < len(lines) and lines[i].strip() != marker:
                i += 1
            if i < len(lines):
                out.append(lines[i])   # keep the closing marker line itself (harmless)
        i += 1
    return "\n".join(out)

# --- cd/pushd confinement to the project root (sandbox emulation) ---
_CD_RE = re.compile(r'(?i)(?:^|[;&|])\s*(cd|pushd)\b[ \t]*("[^"]*"|\'[^\']*\'|[^\s;&|]*)')


def check_cd(cmd, root):
    """Confine `cd`/`pushd` to the project root. Conservative: blocks home/no-arg/~/$var/`-`
    targets, any '..' traversal, and absolute paths outside the root; relative forward paths
    (no '..') are allowed. NOTE: ~/.claude is reachable by the Read/Write tools (read-guard/
    write-guard allowlist) and scripts there run via absolute path (`node ~/.claude/...`) -
    `cd` into it stays blocked (confinement). Best-effort - definitive control is the OS sandbox."""
    for m in _CD_RE.finditer(cmd):
        verb = m.group(1).lower()
        tgt = m.group(2).strip().strip('"').strip("'")
        if not tgt:
            h.block("`%s` with no path goes to the home directory, outside the project root. "
                    "Stay within workspace.project_dir." % verb)
        if tgt.startswith("~") or tgt.startswith("$") or tgt == "-":
            h.block("`%s %s` may leave the project root (home/env/previous dir). "
                    "Stay within workspace.project_dir." % (verb, tgt))
        if ".." in re.split(r"[\\/]+", tgt):
            h.block("`%s %s` uses '..' and may leave the project root. Stay within "
                    "workspace.project_dir (use paths inside the project)." % (verb, tgt))
        if os.path.isabs(tgt) and not h.path_within(tgt, root):
            h.block("`%s %s` targets a path outside the project root. Stay within "
                    "workspace.project_dir." % (verb, tgt))


def main():
    d = h.read_stdin_json()
    h.panic_block()
    cmd = (d.get("tool_input") or {}).get("command") or ""
    if not cmd:
        sys.exit(0)
    cmd = _strip_heredocs(cmd)
    norm = " ".join(cmd.split())
    # Anti split-evasion: also match the de-obfuscated form (rm -r""f /, cu"r"l).
    candidates = [norm]
    nd = h.deobfuscate(norm)
    if nd != norm:
        candidates.append(nd)

    for c in candidates:
        for rx, reason in DESTRUCTIVE_COMPILED:
            if rx.search(c):
                h.block(reason)

    for c in candidates:
        for rx in REDIRECT_ASK:
            if rx.search(c):
                h.ask("this Bash command writes into guardrail/config files (.claude, "
                      "CLAUDE.md, .mcp.json, CI workflows, git hooks). These normally "
                      "change via a reviewed Edit - confirm before proceeding.")

    root = h.project_root(d)
    for c in candidates:
        check_cd(c, root)

    for c in candidates:
        if CURL_WORD.search(c) and not is_internal_get(c):
            h.block("curl/wget are not available in Bash. For a GET to an internal ISP host "
                    "use the `get <url>` command (options: -H, -i, -m, --bearer-env, "
                    "--user-env/--pass-env, --header-env; `get --help`). For external "
                    "content use the WebFetch tool.")
    sys.exit(0)


if __name__ == "__main__":
    h.run_guard(main, "bash-guard")
