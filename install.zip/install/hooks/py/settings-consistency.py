"""settings-consistency hook — runtime consistency check of OTEL_RESOURCE_ATTRIBUTES.

Verifica che i valori in settings.local.json corrispondano alla realtà del sistema OS al
momento dell'esecuzione. Una modifica manuale (developer.id di un altro utente, os.type
sbagliato, gcp.project_id incoerente, host.name falsificato) invaliderebbe la telemetria e
la tracciabilità — questo hook la rileva e blocca l'operatività.

Registered on SessionStart (startup|resume) AND UserPromptSubmit (throttled).

State file DEDICATO <proj>/.claude/.settings-consistency-state (NON condiviso con
binary-integrity: gli hook girano in PARALLELO nel harness Claude Code, un file condiviso
andrebbe in race).

Stagger: a SessionStart il checked_at è scritto now-STAGGER_OFFSET, così il primo re-check
avviene ~15s dopo (TTL 60 - offset 45) e non coincide col ciclo di binary-integrity.

Fail-closed: settings.local.json / OTEL_RESOURCE_ATTRIBUTES assenti, chiavi developer.id / os.type /
host.name mancanti o matricola non risolvibile = violazione (blocco su UserPromptSubmit, dove
vertex-guard non gira).

Campi controllati (da OTEL_RESOURCE_ATTRIBUTES):
  developer.id   -> utente OS reale (resolve_userid())
  os.type        -> OS effettivo (windows; macOS: darwin = valore OTel scritto da set-vertex-project, o macos)
  gcp.project_id -> identico ad ANTHROPIC_VERTEX_PROJECT_ID
  host.name      -> socket.gethostname()

TTL e tutti i parametri HARDCODED (non sovrascrivibili via env).
"""
import json
import os
import socket
import sys
import time
import isp_hooks as h

TTL_SECONDS = 60       # re-check cadence — hardcoded, not env-overridable
STAGGER_OFFSET = 45    # SessionStart back-dates checked_at so re-check staggers vs binary-integrity


def _state_path(proj):
    return os.path.join(proj, ".claude", ".settings-consistency-state")


def _read_state(proj):
    try:
        with open(_state_path(proj), encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _write_state(proj, result, violations, checked_at=None):
    p = _state_path(proj)
    try:
        os.makedirs(os.path.dirname(p), exist_ok=True)
        tmp = "%s.%d.tmp" % (p, os.getpid())
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump({"result": result, "violations": violations,
                       "checked_at": checked_at if checked_at is not None else time.time()}, f)
        os.replace(tmp, p)
    except Exception as e:
        h.audit_log("settings-consistency state write failed type=%s" % type(e).__name__)


def _parse_otel(otel_str):
    result = {}
    for part in (otel_str or "").split(","):
        k, _, v = part.partition("=")
        k, v = k.strip(), v.strip()
        if k:
            result[k] = v
    return result


def _expected_os():
    # OTel semantic convention values, as written by set-vertex-project (platform.system().lower())
    return "windows" if h.IS_WIN else "darwin"


def _check(proj):
    """Verifica OTEL vs realtà OS. Ritorna (ok, violations[])."""
    violations = []
    sl_path = os.path.join(proj, ".claude", "settings.local.json")
    try:
        with open(sl_path, encoding="utf-8") as f:
            sl = json.load(f)
    except Exception:
        # fail-closed: vertex-guard does not run on UserPromptSubmit, so a missing/invalid file here
        # would let a prompt (without tools) reach the model from an unconfigured folder
        return False, ["settings.local.json missing or invalid in this folder"]

    env = (sl.get("env") if isinstance(sl, dict) else None) or {}
    otel = _parse_otel(env.get("OTEL_RESOURCE_ATTRIBUTES") or "")
    if not otel:
        return False, ["OTEL_RESOURCE_ATTRIBUTES missing in settings.local.json"]
    for k in ("developer.id", "os.type", "host.name"):
        if not otel.get(k, "").strip():
            violations.append("%s missing in OTEL_RESOURCE_ATTRIBUTES" % k)

    declared_id = otel.get("developer.id", "").strip()
    if declared_id:
        try:
            actual_id = h.resolve_userid()
            if declared_id.upper() != actual_id.upper():
                violations.append("developer.id '%s' != OS user '%s'" % (declared_id, actual_id))
        except Exception as e:
            h.audit_log("settings-consistency: resolve_userid failed type=%s" % type(e).__name__)
            violations.append("cannot resolve the ISP matricola: %s" % e)

    declared_os = otel.get("os.type", "").strip().lower()
    if declared_os and declared_os not in (("windows",) if h.IS_WIN else ("darwin", "macos")):
        violations.append("os.type '%s' != actual OS '%s'" % (declared_os, _expected_os()))

    declared_gcp = otel.get("gcp.project_id", "").strip()
    env_vertex = (env.get("ANTHROPIC_VERTEX_PROJECT_ID") or "").strip()
    if declared_gcp and env_vertex and declared_gcp != env_vertex:
        violations.append("gcp.project_id '%s' != ANTHROPIC_VERTEX_PROJECT_ID '%s'" % (declared_gcp, env_vertex))

    declared_host = otel.get("host.name", "").strip()
    if declared_host:
        try:
            actual_host = socket.gethostname()
            if declared_host.lower() != actual_host.lower():
                violations.append("host.name '%s' != OS hostname '%s'" % (declared_host, actual_host))
        except Exception:
            violations.append("cannot read the OS hostname")

    return len(violations) == 0, violations


def do_block(event, violations):
    detail = "; ".join(violations)
    h.audit_log("settings-consistency violation: %s" % detail)
    h.log_siem({"type": "settings_consistency_violation", "violations": violations, "event": event})
    if event == "UserPromptSubmit":
        h.halt_turn(h.box("ISP configuration consistency block",
                          ["The ISP configuration of this folder is missing or does not match this machine."] +
                          violations +
                          ["Run set-vertex-project again to re-align the configuration."]))
    sys.stderr.write("BLOCKED by ISP policy: settings-consistency: %s\n" % detail)
    sys.exit(2)


def main():
    raw = h.read_stdin_raw()
    d, event = {}, "SessionStart"
    if raw:
        try:
            d = json.loads(raw)
            event = d.get("hook_event_name") or "SessionStart"
        except Exception:
            pass
    proj = h.project_root(d)

    if event == "SessionStart":
        ok, violations = _check(proj)
        # back-date checked_at for staggering vs binary-integrity
        _write_state(proj, "ok" if ok else "failed", violations, checked_at=time.time() - STAGGER_OFFSET)
        if not ok:
            h.system_message(h.box("WARN ISP configuration consistency",
                                   ["The ISP configuration of this folder is missing or does not match this machine:"] +
                                   violations +
                                   ["Run set-vertex-project again. Claude BLOCKED at the first prompt."]))
        return

    # UserPromptSubmit
    st = _read_state(proj)
    result = st.get("result")
    try:
        age = time.time() - float(st.get("checked_at") or 0)
    except (TypeError, ValueError):
        age = -1          # malformed (user-writable) state: re-check

    # 0 <= age: the state file is user-writable, a checked_at in the future must not skip the re-check
    if result == "ok" and 0 <= age < TTL_SECONDS:
        sys.exit(0)   # fresco — skip

    ok, violations = _check(proj)
    _write_state(proj, "ok" if ok else "failed", violations)
    if not ok:
        do_block(event, violations)


if __name__ == "__main__":
    h.run_guard(main, "settings-consistency")
