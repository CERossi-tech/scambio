"""PreToolUse(Edit|Write) hook — gate on protected file classes by repo risk.

Risk class read from .claude/risk-class.json in the repo cwd (default "medium"):
  high   -> deny (exit 2)
  medium -> ask (JSON permissionDecision)
  low    -> pass (audit only)
PANIC-aware.
"""
import json
import os
import re
import sys
import isp_hooks as h

# (regex on the forward-slash-normalized path, class label). First match wins.
CLASSES = [
    (r"/\.claude/risk-class\.json$", "risk-class manifest (self-protected: do NOT modify via Claude)"),
    (r"/\.github/workflows/|/\.gitlab-ci\.yml$|/azure-pipelines\.yml$|/bitbucket-pipelines\.yml$|/\.circleci/", "CI/CD pipeline"),
    (r"/\.claude/|/\.mcp\.json$|/CLAUDE\.md$", "Claude config"),
    (r"/\.husky/|/\.git/hooks/", "Git hooks"),
    (r"/Dockerfile$|/Containerfile$|/docker-compose\.ya?ml$", "container build"),
    (r"/terraform/|\.tf$|\.tfvars$", "IaC Terraform"),
    (r"/k8s/|/helm/|/charts/|/kustomization\.yaml$", "IaC Kubernetes"),
    (r"/package-lock\.json$|/yarn\.lock$|/pnpm-lock\.yaml$|/poetry\.lock$|/Pipfile\.lock$|/go\.sum$|/Cargo\.lock$|/requirements\.txt$|/pom\.xml$|/build\.gradle", "lockfile / supply-chain"),
    (r"/package\.json$|/Makefile$|/makefile$|/GNUmakefile$|/conftest\.py$|/setup\.py$|/setup\.cfg$|/noxfile\.py$|/tox\.ini$|/pyproject\.toml$", "build/test runner config"),
    (r"/\.gitleaks\.toml$|/\.semgrep\.yml$|/security/|/SECURITY\.md$", "security policy"),
    (r"/migrations/|/db/migrate/|\.sql$", "DB migration"),
]
COMPILED = [(re.compile(rx), lbl) for rx, lbl in CLASSES]


def read_risk():
    try:
        with open(os.path.join(os.getcwd(), ".claude", "risk-class.json"), encoding="utf-8") as f:
            return (json.load(f).get("risk") or "medium")
    except Exception:
        return "medium"


def main():
    d = h.read_stdin_json()
    h.panic_block()

    tool = d.get("tool_name", "")
    fp = (d.get("tool_input") or {}).get("file_path") or ""
    if not fp or tool not in ("Edit", "Write"):
        sys.exit(0)

    norm = fp.replace("\\", "/")
    matched = None
    for rx, lbl in COMPILED:
        if rx.search(norm):
            matched = lbl
            break
    if not matched:
        sys.exit(0)

    risk = read_risk()
    if risk == "high":
        h.block("'%s' is a %s in a high-risk repo. Modify through an external PR "
                "subject to review." % (fp, matched))
    elif risk == "low":
        h.audit_log("config_integrity_pass class=%s file=%s risk=%s" % (matched, fp, risk))
        sys.exit(0)
    else:  # medium (default)
        h.ask("%s is a %s. Confirm before modifying." % (fp, matched))


if __name__ == "__main__":
    h.run_guard(main, "config-integrity")
