"""PreToolUse(Bash git commit) + PostToolUse(Write|Edit) hook.

- PostToolUse(Write|Edit): scan written content -> WARN (secrets + destructive
  intent), never blocks.
- PreToolUse(Bash): only on `git commit` -> scan the staged diff (added lines
  only), BLOCK (exit 2) on findings; fail-closed if the diff can't be read.

SCOPE: secrets/credentials (unique prefixes) + PAN (Luhn, PCI-DSS). General PII
(IBAN/codice fiscale/...) intentionally NOT scanned -> see hooks/README
(data-minimization + DLP engine, Phase 2).
"""
import re
import subprocess
import sys
import isp_hooks as h

PATTERNS = [
    (r"AKIA[0-9A-Z]{16}", "AWS access key id"),
    (r"(?i)aws_secret_access_key\s*=\s*['\"]?[A-Za-z0-9/+=]{40}['\"]?", "AWS secret access key"),
    (r"(?i)api[_-]?key\s*[:=]\s*['\"][^'\"]{16,}['\"]", "Generic API key"),
    (r"-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----", "Private key (PEM)"),
    (r"eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}", "JWT"),
    (r"(?i)password\s*[:=]\s*['\"][^'\"]{6,}['\"]", "Hardcoded password"),
    (r"(?i)bearer\s+[A-Za-z0-9._-]{20,}", "Bearer token"),
    (r"ya29\.[A-Za-z0-9_-]{20,}", "Google OAuth access token"),
    (r"AIza[A-Za-z0-9_-]{35}", "Google API key"),
    (r"sk-ant-api[0-9]+-[A-Za-z0-9_-]{20,}", "Anthropic API key"),
    (r"ghp_[A-Za-z0-9]{36}", "GitHub personal token"),
    (r"glpat-[A-Za-z0-9_-]{20,}", "GitLab personal token"),
    (r"xox[baprs]-[A-Za-z0-9-]{10,}", "Slack token"),
    (r'"type"\s*:\s*"service_account"', "GCP service account JSON marker"),
    (r"[a-z0-9-]+@[a-z0-9-]+\.iam\.gserviceaccount\.com", "GCP service account email"),
    (r"\b1//0[A-Za-z0-9_-]{30,}", "GCP OAuth refresh token"),
]
COMPILED = [(re.compile(p), lbl) for p, lbl in PATTERNS]

# Destructive-intent patterns in script content (WARN only, defense-in-depth).
# High-signal AV/AMSI tokens are fragmented so no contiguous signature
# ships on disk.
DESTRUCTIVE = [
    (r"(?i)os\.system\s*\(\s*['\"][^'\"]*?(rm\s+-rf|chmod\s+777|/etc/passwd|/dev/tcp|mkfs|dd\s+if=)", "Python os.system with destructive command"),
    (r"(?i)subprocess\.(run|Popen|call|check_call|check_output|getoutput)\s*\(\s*\[?\s*['\"](rm|chmod\s+777|mkfs|dd|nc|ncat)\b", "Python subprocess with destructive/exfil command"),
    (r"(?i)eval\s*\(\s*base64\.b?64decode", "Python eval(base64.b64decode)"),
    (r"(?i)__import__\s*\(\s*['\"]os['\"]\s*\)\s*\.system", "Python __import__('os').system"),
    (r"(?i)pty\.spawn\s*\(\s*['\"]\s*/bin/(sh|bash)", "Python pty.spawn shell"),
    (r"(?i)exec\s*\(\s*open\s*\(", "Python exec(open(...))"),
    (r"(?i)child_process\.(exec|execSync|spawn|spawnSync)\s*\(\s*['\"](rm|chmod\s+777|nc|sh\s+-c|bash\s+-c)\b", "Node child_process destructive/exfil"),
    (r"(?i)eval\s*\(\s*atob\s*\(", "Node eval(atob(...))"),
    (r"(?i)Buffer\.from\s*\([^,]+,\s*['\"]base64['\"]\s*\)\.toString\(\)\s*;?\s*\)?\s*[\s\S]{0,100}?eval", "Node Buffer base64+eval"),
    (r"(?i)Remove-Item\s+-Recurse\s+-Force\s+(C:\\|\$env:USERPROFILE|/|~)", "PowerShell Remove-Item destructive root/home"),
    (r"(?i)Invoke-Expression\s*\(\s*\[Convert\]::FromBase64" + r"String", "PowerShell IEX base64"),
    (r"(?i)(Set-MpPref" + r"erence\s+-DisableRealtimeMonitoring|Stop-Service.*Defender|netsh\s+adv" + r"firewall\s+set.*state\s+off)", "PowerShell security service disable"),
    (r"(?m)^\s*rm\s+-rf?\s+(/|~|/\*|\$HOME)", "Shell rm -rf root/home"),
    (r":\s*\(\s*\)\s*\{\s*:\s*\|\s*:\s*&\s*\}\s*;\s*:", "Shell fork bomb"),
    (r"(?i)(curl|wget)\s+[^|]*\|\s*(sh|bash)\b", "Shell pipe-to-shell"),
    (r"(?i)(tar|zip|gzip|base64)\s+[^|]*\|\s*(curl|wget|nc|ncat)\b", "Shell archive piped to outbound"),
    (r">/dev/tcp/[^/\s]+/", "Shell TCP redirect"),
]
DESTRUCTIVE_COMPILED = [(re.compile(p), lbl) for p, lbl in DESTRUCTIVE]

PAN_REGEX = re.compile(r"\b(?:\d[ -]?){13,19}\b")


def luhn_ok(num_str):
    digits = [int(c) for c in num_str if c.isdigit()]
    if not (13 <= len(digits) <= 19):
        return False
    checksum = 0
    for i, d in enumerate(reversed(digits)):
        if i % 2 == 1:
            d *= 2
            if d > 9:
                d -= 9
        checksum += d
    return checksum % 10 == 0


def scan(text):
    if not text:
        return []
    findings = h.scan_text(text, COMPILED)   # raw + de-obfuscated (anti split-evasion)
    blob = text + "\n" + h.deobfuscate(text)
    for m in PAN_REGEX.finditer(blob):
        if luhn_ok(m.group()):
            findings.append("Possible PAN (Luhn-valid)")
            break
    return findings


def scan_destructive(text):
    return h.scan_text(text, DESTRUCTIVE_COMPILED)


def handle_post_write(d):
    ti = d.get("tool_input", {}) or {}
    fp = ti.get("file_path") or ""
    content = ti.get("content") or ti.get("new_string") or ""
    secrets = scan(content)
    destructive = scan_destructive(content)
    msgs = []
    if secrets:
        h.log_siem({"type": "secret_in_write", "file": fp, "findings": secrets,
                    "session": d.get("session_id")})
        msgs.append("possible secrets/PII (" + ", ".join(secrets) +
                    "). DO NOT commit before removing them.")
    if destructive:
        h.log_siem({"type": "destructive_intent_in_write", "file": fp,
                    "findings": destructive, "session": d.get("session_id")})
        msgs.append("destructive-intent patterns (" + ", ".join(destructive) +
                    "). Review required - the script contains literal destructive/"
                    "exfil commands; do not execute without verification.")
    if msgs:
        h.warn("ISP policy warning on " + fp + ": " + " | ".join(msgs))


def handle_pre_bash(d):
    cmd = (d.get("tool_input", {}) or {}).get("command", "") or ""
    if not re.search(r"\bgit\s+commit\b", cmd):
        return

    git_args = []
    m = re.search(r"\bgit\s+-C\s+(?:\"([^\"]+)\"|'([^']+)'|(\S+))", cmd)
    if m:
        git_args = ["-C", m.group(1) or m.group(2) or m.group(3)]

    git_exe = h.trusted_git()   # allowlisted absolute path, never PATH (a fake git could hide the diff)
    if not git_exe:
        h.block("secret-scan: no trusted git found (Git for Windows in C:\\Program Files / "
                "Xcode Command Line Tools). The commit gate cannot run without it.")

    def git(*a):
        # Force UTF-8 decoding of git output: the diff can contain bytes not
        # mappable in the Windows locale (cp1252) - e.g. curly quotes/em-dashes
        # in docs - which would crash the reader thread (and, pre fail-closed,
        # fail OPEN, skipping the scan). errors="replace" keeps it robust.
        return subprocess.run([git_exe] + git_args + list(a),
                              capture_output=True, text=True,
                              encoding="utf-8", errors="replace", timeout=20)

    specs = [["diff", "--cached", "--unified=0"]]
    if (re.search(r"\bcommit\b[^|;&]*\s-[A-Za-z]*a", cmd)
            or re.search(r"--all\b|--include\b", cmd)
            or re.search(r"\bgit\s+add\b", cmd)):
        try:
            if git("rev-parse", "--verify", "-q", "HEAD").returncode == 0:
                specs.append(["diff", "HEAD", "--unified=0"])
        except Exception:
            pass

    texts = []
    for spec in specs:
        try:
            r = git(*spec)
        except Exception:
            r = None
        if r is None or r.returncode != 0:
            h.block("secret-scan could not read the git diff. Stage explicitly "
                    "or commit from a valid repo state.")
        added = [ln[1:] for ln in r.stdout.splitlines()
                 if ln.startswith("+") and not ln.startswith("+++")]
        texts.append("\n".join(added))

    findings = scan("\n".join(texts))
    if findings:
        h.log_siem({"type": "secret_at_commit", "findings": findings,
                    "session": d.get("session_id")})
        h.block("the commit diff contains " + ", ".join(findings) +
                ". Remove before committing.")


def main():
    d = h.read_stdin_json()
    event = d.get("hook_event_name", "")
    tool = d.get("tool_name", "")
    if event == "PostToolUse" and tool in ("Write", "Edit"):
        handle_post_write(d)
    elif event == "PreToolUse" and tool == "Bash":
        handle_pre_bash(d)
    sys.exit(0)


if __name__ == "__main__":
    h.run_guard(main, "secret-scan")
