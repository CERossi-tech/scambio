"""SessionStart(startup|resume) hook — cross-platform Python.

Logs the session identity and prints the ISP AUP banner (Claude sees stdout at
SessionStart as additional context). Never blocks.
"""
import getpass
import os
import platform
import sys
import isp_hooks as h

BANNER = """=== Intesa Sanpaolo - Claude Code Acceptable Use Policy ===

You are using Claude Code in a corporate context. Reminder:

1. DO NOT paste secrets, credentials, tokens, customer data or production
   material into prompts. All prompts and tool calls are logged for DORA/NIS2
   audit purposes.
2. For repos classified as sensitive (payments, PII, IAM, prod IaC)
   use `plan` mode before any modification.
3. DO NOT attempt to disable or bypass security controls (sandbox, hooks,
   permission rules). Such attempts are detected.
4. Your actions are attributed to your account and reviewable by the SOC.
5. If in doubt about authorized use, consult the Security team before
   proceeding.

Full policy: [ISP intranet AUP link to be filled in]
=== End of banner ==="""


def main():
    # Emit UTF-8: the banner + injected rules contain non-ASCII (accents, arrows)
    # that the Windows console codepage (cp1252) cannot encode -> without this the
    # write would raise UnicodeEncodeError and the context would be silently dropped.
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    d = h.read_stdin_json()
    sid = d.get("session_id") or "unknown"
    cwd = d.get("cwd") or "unknown"
    src = d.get("source") or "startup"
    try:
        user = h.os_login() or "?"   # OS account, not env vars (audit identity)
    except Exception:
        user = "?"
    try:
        host = platform.node()
    except Exception:
        host = "?"
    h.audit_log("session_%s sid=%s user=%s host=%s cwd=%s" % (src, sid, user, host, cwd))
    sys.stdout.write(BANNER + "\n")
    # ISP secure-coding rules as SessionStart context: cyber-owned separate file
    # (CLAUDE-security-rules.md, deployed in BASE_DIR), injected here INSTEAD of a
    # CLAUDE.md @import -> avoids the external-import consent prompt. Best-effort.
    try:
        with open(os.path.join(h.BASE_DIR, "CLAUDE-security-rules.md"), encoding="utf-8") as f:
            sys.stdout.write("\n" + f.read() + "\n")
    except Exception:
        pass
    sys.exit(0)


if __name__ == "__main__":
    h.run_guard(main, "session-audit")
