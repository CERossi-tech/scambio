"""Shared helpers for the ISP Claude Code hooks — single cross-platform impl.

One Python implementation for macOS and Windows, invoked from
50-hooks-{MAC,WINDOWS}.json: through run-hook.{cmd,sh}, with python taken from the find-python allowlist
(admin/root-owned folders only, never PATH or the current directory) and run
-E -S -B. No jq, no bash, no PowerShell.

Stdlib only. Python >= 3.9 on macOS, >= 3.11 on Windows (enforced by the
deps-guard first gate).
"""
import json
import os
import re
import sys
import threading

IS_WIN = (os.name == "nt")            # sys.platform == "win32"
IS_MAC = (sys.platform == "darwin")

# macOS: /usr/bin/git, /usr/bin/python3... are xcode-select shims that run whatever DEVELOPER_DIR
# (or TOOLCHAINS/SDKROOT) points at, user folders included. Dropped here for this process and every
# command it runs (git, gcloud...), as find-python.sh does for the launchers; the user's shell and
# the commands Claude runs for the user are not touched.
if IS_MAC:
    for _v in ("DEVELOPER_DIR", "TOOLCHAINS", "SDKROOT"):
        os.environ.pop(_v, None)

# --- managed base dir + derived paths (per OS) ---
if IS_WIN:
    BASE_DIR = r"C:\Program Files\ClaudeCode"
else:
    BASE_DIR = "/Library/Application Support/ClaudeCode"

HOOKS_DIR  = os.path.join(BASE_DIR, "hooks")
PANIC_FILE = os.path.join(HOOKS_DIR, "PANIC")
CONFIG_DIR = os.path.join(BASE_DIR, "config")
# Binary + manifest location (checked by binary-integrity). On Windows it sits
# under the managed base; on macOS the app binary lives in /Applications.
BIN_DIR    = os.path.join(BASE_DIR, "bin") if IS_WIN else "/Applications/DevUtil/ClaudeCode"
MANIFEST   = os.path.join(BIN_DIR, "manifest.json")

# --- Test overrides: NEVER from environment variables ---
# The hooks inherit the environment of `claude`, so any env var they read can be set by the user
# (`CLAUDE_TEST_VPN=up claude`) to bypass a control. Test values are read ONLY from
# config/test-overrides.json of THIS package (hooks/py/../../config). Installed, that folder is
# admin/root-only (C:\Program Files\ClaudeCode\config, /Library/Application Support/ClaudeCode/config):
# a user cannot create the file. In the repo it is install/config/test-overrides.json, written by
# tests/py/run_all.py, gitignored, deleted at the end of the run, never copied by build-release.sh
# (explicit file list); set-vertex-project-doctor flags it if present on an installed machine.
# Defense in depth: when the hooks run from the installed package (under BASE_DIR) the file is NEVER
# read, so wrong permissions on the installed config folder cannot turn it into a bypass.
TEST_OVERRIDES_FILE = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__)))), "config", "test-overrides.json")


def _load_test_overrides():
    try:
        base = os.path.normcase(os.path.abspath(BASE_DIR))
        if os.path.commonpath([base, os.path.normcase(TEST_OVERRIDES_FILE)]) == base:
            return {}
    except ValueError:
        pass                      # different drives (Windows): not under BASE_DIR
    try:
        with open(TEST_OVERRIDES_FILE, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


TEST = _load_test_overrides()


def test_value(key, default=None):
    """Test override for `key` (see TEST_OVERRIDES_FILE), or default. Empty string = not set."""
    v = TEST.get(key)
    return default if v in (None, "") else v


EGRESS_ALLOWLIST = test_value("CLAUDE_EGRESS_ALLOWLIST") or \
    os.path.join(CONFIG_DIR, "egress-domains.json")

if IS_WIN:
    # fixed path, not %ProgramData% (user-controlled env var: it would move the audit trail)
    _default_audit = os.path.join(r"C:\ProgramData", "ClaudeCode", "audit.log")
else:
    _default_audit = "/var/log/claude-code-audit.log"
AUDIT_LOG = test_value("CLAUDE_AUDIT_LOG") or _default_audit   # not from env: a user could divert the audit trail
AUDIT_MAX_BYTES = 5 * 1024 * 1024    # 5 MB — hardcoded, non sovrascrivibile via env (parametro di sicurezza)

def _siem_url():
    """SIEM webhook from the admin-owned config/siem.json ({"hook_url": "https://..."}), never from env
    (a user could redirect the violation events to a URL of their own). Missing file = SIEM off."""
    try:
        with open(os.path.join(CONFIG_DIR, "siem.json"), encoding="utf-8") as f:
            return str(json.load(f).get("hook_url") or "").strip()
    except Exception:
        return ""


SIEM_URL = "" if TEST else _siem_url()   # test runs (overrides file present): SIEM always off


# --- trusted git (secret-scan) ---
# A fake git could return an empty diff and let secrets through the commit gate. Accepted only if
# trusted_exe(): under a system root and not modifiable by the user (file + every parent folder), the
# same rule as the hooks' interpreter. Candidates: these usual locations first (discovery hints, keep in
# sync with find-python.{cmd,sh}), then git on PATH; the first trusted one wins, wherever it is.
_TRUSTED_GIT = ([r"C:\Program Files\Git\cmd\git.exe", r"C:\Program Files (x86)\Git\cmd\git.exe"]
                if IS_WIN else
                ["/Library/Developer/CommandLineTools/usr/bin/git",
                 "/Applications/Xcode.app/Contents/Developer/usr/bin/git"])


def trusted_git():
    """Absolute path of the first trusted git (hints, then PATH), or None if none is trusted."""
    for p in _TRUSTED_GIT + [_which_abs("git")]:
        if p and os.path.isfile(p) and trusted_exe(p):
            return p
    return None


# --- system commands run by the hooks: resolved on PATH, then the location is checked ---
# No hardcoded paths (a slightly different but admin-owned location must keep working). The command is
# looked up on PATH (absolute entries only: never the current directory = the project folder) and the
# FIRST match is what runs, by its absolute path. It must sit in an admin-owned system folder: same rule
# as python/git (is_system_path) and, on macOS, file + every parent folder owned by root and not
# writable by group/others. Not found, or found outside an admin-owned folder (Homebrew, user folders,
# a user folder prepended to PATH) = not trusted: vpn-guard blocks every prompt for GATED_TOOLS.
# needed by the controls (vpn-guard: VPN state; binary-integrity: running binary)
GATED_TOOLS = ("ipconfig",) if IS_WIN else ("ifconfig", "ps", "lsof")
# the other system commands of the package: same resolution, never blocking (the feature that uses one
# behaves as if the command failed); all listed by the doctor
SYSTEM_TOOLS = GATED_TOOLS + (("powershell", "tasklist") if IS_WIN else ("app-sso", "klist", "logger", "scutil", "security"))
_forced = test_value("CLAUDE_TEST_SYSTEM_TOOLS")          # test seam: JSON {name: path}
_FORCED_TOOLS = json.loads(_forced) if _forced else {}


def _which_abs(name):
    """First match of `name` on PATH, absolute PATH entries only (no cwd, no relative entries)."""
    exts = [""] + ([e for e in os.environ.get("PATHEXT", ".EXE").split(";") if e] if IS_WIN else [])
    for d in os.environ.get("PATH", "").split(os.pathsep):
        d = d.strip().strip('"')
        if not d or not os.path.isabs(d):
            continue
        for e in exts:
            cand = os.path.join(d, name + e)
            if os.path.isfile(cand) and (IS_WIN or os.access(cand, os.X_OK)):
                return cand
    return None


def system_tool(name):
    """(absolute path, '') if `name` resolves on PATH inside an admin-owned folder, else (None, why)."""
    path = _FORCED_TOOLS.get(name) if name in _FORCED_TOOLS else _which_abs(name)
    if not path or not os.path.isfile(path):
        return None, "%s not found on PATH" % name
    if not is_system_path(path):
        return None, "%s resolves to %s: not an admin-owned system folder" % (name, path)
    return path, ""


def system_tool_path(name):
    """Path to run for `name`; raises RuntimeError if not trusted (callers treat it as a failed command)."""
    path, why = system_tool(name)
    if not path:
        raise RuntimeError(why)
    return path


def system_tools_check(names=None):
    """[('err', why)] for each of `names` (default GATED_TOOLS) not found or outside an admin-owned folder
    (vpn-guard blocks every prompt)."""
    return [("err", why) for n in (names or GATED_TOOLS) for path, why in [system_tool(n)] if not path]


# --- gcloud resolution (on PATH) ---
# gcloud is provisioned on PATH (presence-only in deps-guard: it runs no guard), resolved by name.
# Used by check-gcp-token and adc_check.
def find_gcloud():
    import shutil
    return shutil.which("gcloud") or (shutil.which("gcloud.cmd") if IS_WIN else None)


# --- runtime tools on PATH (set-vertex-project first window + doctor section 2): report only ---
# Where python/node/git/gcloud resolve on PATH, and whether that is an admin-owned system folder.
# A tool in a user-writable folder (C:\tools, ~/Applications, Homebrew, nvm...) still works, but can
# be replaced by the user and may behave differently (real case: a personal Python whose cert.pem had
# no ISP CA broke set-vertex-project). Report only: nothing is blocked here.
# Admin-owned = under one of these roots (common roots, not single folders: a slightly different system
# location must keep working) AND not modifiable by the user, checked on the real file and its folder:
# macOS: file + every parent folder owned by root, not writable by others, group-writable only for
# wheel/admin; Windows: the user's token has no write/delete/ACL right on the file and cannot add files to
# its folder (AccessCheck on the DACL: nothing is written). That excludes the user-writable folders
# under the roots (C:\Windows\Temp, C:\Windows\Tasks, Homebrew's /usr/local, apps dragged to /Applications).
_SYSTEM_PREFIXES = ((r"C:\Program Files" + "\\", r"C:\Program Files (x86)" + "\\", r"C:\Windows" + "\\")
                    if IS_WIN else
                    ("/usr/", "/bin/", "/sbin/", "/System/", "/Library/", "/Applications/"))


def _mac_admin_owned(path):
    """macOS: `path` (resolved) and every parent folder: owner root, not other-writable, group-writable
    only if the group is wheel (0) or admin (80, already sudo-capable)."""
    p = os.path.realpath(path)
    while True:
        st = os.stat(p)
        if st.st_uid != 0 or st.st_mode & 0o002 or (st.st_mode & 0o020 and st.st_gid not in (0, 80)):
            return False
        parent = os.path.dirname(p)
        if parent == p:
            return True
        p = parent


def _win_user_can_modify(path):
    """Windows: True if the current user's token may modify `path` (write data, delete, change ACL/owner),
    add/delete entries in its folder, or rename/replace/re-ACL any parent folder up to the drive root
    (a swappable parent = a swappable file, or DLLs/stdlib planted next to it). From the DACL via
    AccessCheck (MAXIMUM_ALLOWED): nothing is written. An elevated process can write anywhere: then
    only the location counts (False)."""
    import ctypes
    from ctypes import wintypes
    if ctypes.windll.shell32.IsUserAnAdmin():
        return False
    adv = ctypes.WinDLL("advapi32", use_last_error=True)
    k32 = ctypes.WinDLL("kernel32", use_last_error=True)

    class _GM(ctypes.Structure):
        _fields_ = [("r", wintypes.DWORD), ("w", wintypes.DWORD), ("x", wintypes.DWORD), ("a", wintypes.DWORD)]
    k32.GetCurrentProcess.restype = wintypes.HANDLE
    adv.OpenProcessToken.argtypes = [wintypes.HANDLE, wintypes.DWORD, ctypes.POINTER(wintypes.HANDLE)]
    adv.DuplicateToken.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.POINTER(wintypes.HANDLE)]
    adv.GetFileSecurityW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, ctypes.c_void_p, wintypes.DWORD,
                                     ctypes.POINTER(wintypes.DWORD)]
    adv.AccessCheck.argtypes = [ctypes.c_void_p, wintypes.HANDLE, wintypes.DWORD, ctypes.POINTER(_GM),
                                ctypes.c_void_p, ctypes.POINTER(wintypes.DWORD), ctypes.POINTER(wintypes.DWORD),
                                ctypes.POINTER(wintypes.BOOL)]
    k32.CloseHandle.argtypes = [wintypes.HANDLE]
    mapping = _GM(0x120089, 0x120116, 0x1200A0, 0x1F01FF)       # FILE_GENERIC_READ/WRITE/EXECUTE, FILE_ALL_ACCESS

    def granted(target, tok):
        info = 0x1 | 0x2 | 0x4                                   # OWNER | GROUP | DACL
        need = wintypes.DWORD(0)
        adv.GetFileSecurityW(target, info, None, 0, ctypes.byref(need))
        if not need.value:
            raise OSError(ctypes.get_last_error(), "GetFileSecurityW", target)
        sd = ctypes.create_string_buffer(need.value)
        if not adv.GetFileSecurityW(target, info, sd, need.value, ctypes.byref(need)):
            raise OSError(ctypes.get_last_error(), "GetFileSecurityW", target)
        ps, pslen = ctypes.create_string_buffer(1024), wintypes.DWORD(1024)
        acc, ok = wintypes.DWORD(0), wintypes.BOOL(0)
        if not adv.AccessCheck(sd, tok, 0x02000000, ctypes.byref(mapping), ps, ctypes.byref(pslen),
                               ctypes.byref(acc), ctypes.byref(ok)):       # MAXIMUM_ALLOWED
            raise OSError(ctypes.get_last_error(), "AccessCheck", target)
        return acc.value if ok.value else 0

    proc_tok, tok = wintypes.HANDLE(), wintypes.HANDLE()
    if not adv.OpenProcessToken(k32.GetCurrentProcess(), 0x8 | 0x2, ctypes.byref(proc_tok)):  # QUERY|DUPLICATE
        raise OSError(ctypes.get_last_error(), "OpenProcessToken")
    try:
        if not adv.DuplicateToken(proc_tok, 2, ctypes.byref(tok)):           # SecurityImpersonation
            raise OSError(ctypes.get_last_error(), "DuplicateToken")
        try:
            # file: WRITE_DATA 0x2 | APPEND 0x4 | DELETE 0x10000 | WRITE_DAC 0x40000 | WRITE_OWNER 0x80000
            # folder: ADD_FILE 0x2 | ADD_SUBDIRECTORY 0x4 | DELETE_CHILD 0x40 | DELETE | WRITE_DAC | WRITE_OWNER
            # parents: DELETE_CHILD | DELETE | WRITE_DAC | WRITE_OWNER (adding an unrelated entry to C:\ ,
            # which Authenticated Users may do by default, does not touch this file)
            if os.path.isfile(path) and granted(path, tok) & (0x2 | 0x4 | 0x10000 | 0x40000 | 0x80000):
                return True
            folder = path if os.path.isdir(path) else os.path.dirname(path)
            if granted(folder, tok) & (0x2 | 0x4 | 0x40 | 0x10000 | 0x40000 | 0x80000):
                return True
            p = os.path.dirname(folder)
            while p and p != folder:
                if granted(p, tok) & (0x40 | 0x10000 | 0x40000 | 0x80000):
                    return True
                folder, p = p, os.path.dirname(p)
            return False
        finally:
            k32.CloseHandle(tok)
    finally:
        k32.CloseHandle(proc_tok)


def is_system_path(path):
    """True if `path` is admin-owned: under a system root (as found, symlinks NOT followed: a link in a
    user folder can be re-pointed by the user) AND not modifiable by the user (see _SYSTEM_PREFIXES).
    Any error in the ownership check = False (not trusted)."""
    if not path:
        return False
    p = os.path.normcase(os.path.abspath(path))
    if not any(p.startswith(os.path.normcase(x)) for x in _SYSTEM_PREFIXES):
        return False
    try:
        return (not _win_user_can_modify(path)) if IS_WIN else _mac_admin_owned(path)
    except Exception:
        return False


_xcode_dir_ok = None


def _mac_shim_ok(path):
    """macOS: a tool in /usr/bin may be an xcode-select shim (git, python3...): it runs the copy under the
    developer folder of `xcode-select -p` (DEVELOPER_DIR & co. are dropped at import), so that folder must
    pass the same check. Anything else: True."""
    global _xcode_dir_ok
    if not os.path.realpath(path).startswith("/usr/bin/"):
        return True
    if _xcode_dir_ok is None:
        import subprocess
        try:
            d = subprocess.run([system_tool_path("xcode-select"), "-p"], capture_output=True, text=True,
                               timeout=5).stdout.strip()
            _xcode_dir_ok = bool(d) and is_system_path(d)
        except Exception:
            _xcode_dir_ok = False
    return _xcode_dir_ok


def trusted_exe(path):
    """True if the executable `path` may run as a mandatory tool of the ISP layer (hooks' interpreter,
    git): under a system root and not modifiable by the user, file + every parent folder (is_system_path),
    wherever it sits under the roots; on macOS a /usr/bin shim also needs a trusted developer folder."""
    return is_system_path(path) and (not IS_MAC or _mac_shim_ok(path))


def interpreter_trusted():
    """Second step of the interpreter check (the launcher checked only the location): the running Python
    itself, file + every parent folder. Test override CLAUDE_TEST_INTERPRETER = trusted / untrusted."""
    forced = test_value("CLAUDE_TEST_INTERPRETER")
    if forced in ("trusted", "untrusted"):
        return forced == "trusted"
    return trusted_exe(sys.executable)


# A hook (main script in this folder, run by run-hook) refuses to run on an untrusted interpreter:
# exit 2 blocks the tool call / prompt (message only on SessionStart). Package scripts that import this
# module (wizard, doctor, statusline) are not blocked here: the doctor reports the interpreter instead.
if (os.path.dirname(os.path.abspath(sys.argv[0] or "")) == os.path.dirname(os.path.abspath(__file__))
        and not interpreter_trusted()):
    sys.stderr.write("BLOCKED by ISP policy [FIRST GATE]: the Python interpreter %s is not in an admin-owned "
                     "system folder (it or a parent folder can be modified by the user). The ISP safety layer "
                     "cannot run on it. Contact IT.\n" % sys.executable)
    sys.exit(2)


def runtime_deps():
    """[(name, path or '', required, system_required)] for the tools on PATH (same list as the doctor).
    required: True = missing is an error, 'warn' = missing is only a warning (presence, non-blocking).
    Same rule as the deps-guard gate: python and git must be in admin-owned folders (an impostor of
    either disables the guards); gcloud only has to exist (any folder). Only what the package uses
    (node is not: the claude binary is native, every package script is Python)."""
    import shutil
    py = "python" if IS_WIN else "python3"
    return [(py, shutil.which(py) or shutil.which("python3") or shutil.which("python") or "", True, True),
            ("git", shutil.which("git") or "", True, True),
            ("gcloud", find_gcloud() or "", True, False)]


def runtime_deps_check():
    """[(level, message)]: one 'ok' line if all is fine, otherwise one 'err' line per required tool
    that is missing or per python/git outside the admin-owned system folders."""
    out, ok = [], []
    for name, path, required, system_required in runtime_deps():
        if not path:
            if required == "warn":
                out.append(("warn", "%s not found on PATH (non-blocking)." % name))
            elif required:
                out.append(("err", "%s not found on PATH." % name))
        elif system_required and not is_system_path(path):
            out.append(("err", "%s outside the system folders: %s (user-writable folder: "
                               "it can be replaced or behave differently)." % (name, path)))
        elif system_required:
            ok.append(name)
    out += system_tools_check()      # system commands of the controls: missing = Claude blocked
    if not any(lv == "err" for lv, _ in out):
        out.insert(0, ("ok", "Software in the system folders: %s." % ", ".join(ok)))
    return out


# --- GCP ADC check (set-vertex-project + its doctor): one verdict, plain-language messages ---
# The login (`gcloud auth application-default login`) is the ACCOUNT's: one global ADC. The project is
# only its quota_project_id. gcp-auto on: each folder has its own copy (.claude/gcp/...local.json) with
# its quota_project_id, sharing the global refresh token (adc-mirror re-syncs it after a new login).
# gcp-auto off: every folder uses the global ADC -> one project at a time.
# Messages NEVER contain token or refresh_token values.
def global_adc_path():
    base = os.environ.get("APPDATA", "") if IS_WIN else os.path.join(os.path.expanduser("~"), ".config")
    return os.path.join(base, "gcloud", "application_default_credentials.json")


def _adc_json(path):
    try:
        with open(path, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else None
    except Exception:
        return None


_MINT_TIMEOUT = 30   # gcloud print-access-token takes ~9s on an ISP Windows machine; 15s gave false "expired"
# gcloud stderr that means the login itself is gone (a new login is needed). Anything else
# (timeout, network, proxy, certificate, gcloud crash) does NOT prove the login expired.
# OAuth error codes, not gcloud's generic "There was a problem refreshing your current auth tokens"
# prefix (not proven to be absent on network errors). Shared by check-gcp-token and adc_check.
GCLOUD_REFUSED_RE = re.compile(r"invalid_rapt|invalid_grant|invalid_client|unauthorized_client|reauth|"
                               r"re-authenticat|revoked|expired|"
                               r"could not (?:automatically determine|find default) credentials", re.I)


# certificate/TLS errors ("certificate has expired", "CERTIFICATE_VERIFY_FAILED") are never a refused
# login, even when they contain "expired" / "revoked"
_GCLOUD_TLS_RE = re.compile(r"certificate|\bssl\b|\btls\b", re.I)


def gcloud_error_why(returncode, stderr):
    """Classification of a failed `print-access-token`: 'refused' (a new login is needed) or
    'error: <first stderr line>' (login NOT verified, it may still be valid)."""
    err = (stderr or "").strip()
    if GCLOUD_REFUSED_RE.search(err) and not _GCLOUD_TLS_RE.search(err):
        return "refused"
    first = next((l.strip() for l in err.splitlines() if l.strip()), "exit code %s" % returncode)
    first = first.split("auth tokens: ", 1)[-1]          # keep the cause, drop gcloud's generic prefix
    return "error: " + first[:90]


def _mint_token(g, adc_path):
    """`print-access-token` against a SPECIFIC ADC file (GOOGLE_APPLICATION_CREDENTIALS), so global and
    per-folder credentials are tested independently. Returns (token, why): why = '' (ok), 'refused'
    (login expired/invalid), 'timeout' (gcloud did not answer within _MINT_TIMEOUT) or 'error: <cause>'
    (network/proxy/certificate...: login not verified, no new login needed). The token stays in memory
    only (tokeninfo lookup), never printed or logged."""
    import subprocess
    env = dict(os.environ)
    env["GOOGLE_APPLICATION_CREDENTIALS"] = adc_path
    try:
        p = subprocess.run([g, "auth", "application-default", "print-access-token", "--quiet"],
                           capture_output=True, text=True, timeout=_MINT_TIMEOUT, env=env,
                           encoding="utf-8", errors="replace")
    except subprocess.TimeoutExpired:
        return "", "timeout"
    except Exception as e:
        return "", "error: %s" % type(e).__name__
    if p.returncode == 0 and (p.stdout or "").strip():
        return p.stdout.strip(), ""
    return "", gcloud_error_why(p.returncode, p.stderr)


def _not_verified(why, what):
    """Warning text for a login that could not be verified (timeout / non-refusal error)."""
    if why == "timeout":
        cause = "gcloud did not answer within %ds (slow network or gcloud)" % _MINT_TIMEOUT
    else:
        cause = "gcloud returned an error that does not mean an expired login (%s)" % why[len("error: "):]
    return ("%s not verified: %s. No new login needed: check network/VPN and run the "
            "check again (set-vertex-project-doctor)." % (what, cause))


_TOKENINFO_URL = "https://oauth2.googleapis.com/tokeninfo"


def tokeninfo_email(tok):
    """Account (email) behind an access token via the OAuth tokeninfo endpoint, or None if unresolvable
    (offline/proxy). POST with the token in the body: in a query string it would end up in proxy logs.
    Shared by adc_check and check-gcp-token."""
    import urllib.parse
    import urllib.request
    if not tok:
        return None
    try:
        req = urllib.request.Request(_TOKENINFO_URL, data=urllib.parse.urlencode({"access_token": tok}).encode(),
                                     headers={"Content-Type": "application/x-www-form-urlencoded"})
        with urllib.request.urlopen(req, timeout=10) as r:
            return (json.load(r).get("email") or "").strip().lower() or None
    except Exception:
        return None


_adc_email = tokeninfo_email   # the ADC file of a user login has no usable 'account' field


def _gcloud_account():
    """Account of the active gcloud configuration ([core] account), '' if none. gcloud's own login is
    separate from the ADC one and can be a different account. Honors CLOUDSDK_CONFIG."""
    root = os.environ.get("CLOUDSDK_CONFIG") or os.path.dirname(global_adc_path())
    try:
        with open(os.path.join(root, "active_config"), encoding="utf-8") as f:
            name = f.read().strip() or "default"
        with open(os.path.join(root, "configurations", "config_" + name), encoding="utf-8") as f:
            for line in f:
                k, _, v = line.partition("=")
                if k.strip() == "account" and v.strip():
                    return v.strip().lower()
    except Exception:
        pass
    return ""


def _folder_identity(local_adc):
    """Account the folder's ADC copy was registered for (.claude/gcp/.identity, written by
    check-gcp-token), '' if not known yet."""
    try:
        with open(os.path.join(os.path.dirname(local_adc), ".identity"), encoding="utf-8") as f:
            return (json.load(f).get("email") or "").strip().lower()
    except Exception:
        return ""


def adc_check(project, auto, local_adc=None):
    """Checks of the GCP credentials Claude will use in this folder. Returns [(level, message)],
    level 'ok' / 'warn' / 'err'; every 'err' message says how to fix it."""
    out = []
    login = "gcloud auth application-default login"
    g = find_gcloud()
    if not g:
        out.append(("err", "gcloud not found on PATH: install the Google Cloud CLI (needed for the GCP login)."))
    gpath = global_adc_path()
    gj = _adc_json(gpath)
    email = None
    if gj is None:
        out.append(("err", "GCP login missing (%s not found): run  %s" % (gpath, login)))
    elif g:
        tok, why = _mint_token(g, gpath)
        if not tok and why != "refused":
            out.append(("warn", _not_verified(why, "GCP login")))
        elif not tok:
            out.append(("err", "GCP login expired or invalid: run  %s  (a browser opens; "
                               "valid for all folders)." % login))
        else:
            email = _adc_email(tok)
            out.append(("ok", "GCP login valid as %s." % email if email else
                        "GCP login valid (account not verifiable: Google tokeninfo service "
                        "not reachable)."))
            gacct = _gcloud_account()
            if email and not gacct:
                out.append(("warn", "gcloud has no active account: run  gcloud auth login %s  "
                                    "(needed for the automatic login renewal)." % email))
            elif email and gacct != email:
                out.append(("warn", "gcloud is logged in as %s, the ADC login as %s: use the same account "
                                    "(gcloud auth login %s), otherwise the automatic login renewal "
                                    "and the status line get confused." % (gacct, email, email)))
    if not auto:
        if gj is not None:
            q = gj.get("quota_project_id") or ""
            if q != project:
                out.append(("err", "Manual mode: the global ADC bills %s, this folder uses %s, "
                                   "so Claude will be blocked (vertex-guard). Run  "
                                   "gcloud auth application-default set-quota-project %s  (applies to all "
                                   "folders in manual mode). To use different projects in different "
                                   "folders run again:  set-vertex-project --gcp-auto"
                                   % (q or "(no project)", project, project)))
            else:
                out.append(("ok", "Manual mode: the global ADC bills %s." % project))
        return out
    lj = _adc_json(local_adc) if local_adc else None
    if lj is None:
        out.append(("err", "Folder ADC copy missing: run again  set-vertex-project --gcp-auto"))
        return out
    lq = lj.get("quota_project_id") or ""
    if lq != project:
        out.append(("err", "The folder ADC copy bills %s instead of %s: run again  "
                           "set-vertex-project --gcp-auto" % (lq or "(no project)", project)))
    else:
        out.append(("ok", "Folder ADC copy: bills %s." % project))
    if gj is not None and gj.get("refresh_token") != lj.get("refresh_token"):
        out.append(("warn", "The folder ADC copy is not aligned with the current login: it re-aligns "
                            "by itself at the first message in Claude (adc-mirror)."))
    known = _folder_identity(local_adc)
    if email and known and known != email:
        out.append(("warn", "The current login is %s, but this folder is registered for %s: Claude does not "
                            "re-align the copy with a different account. Log in as %s, or, if "
                            "the right account is %s, run again  set-vertex-project --gcp-auto"
                            % (email, known, known, email)))
    if g:
        ltok, lwhy = _mint_token(g, local_adc)
        if ltok:
            out.append(("ok", "Token issued with the folder copy."))
        elif lwhy != "refused":
            out.append(("warn", _not_verified(lwhy, "Folder ADC copy")))
        else:
            out.append(("err", "The folder ADC copy issues no token: run  %s  and then "
                               "set-vertex-project --gcp-auto" % login))
    return out


# --- ISP userid resolution (developer.id) ---
# Format: 'U'/'u' + 6 alphanumerics (7 chars total) — internal (U447742) and external users.
# Windows: getpass.getuser() already yields the matricola (e.g. "U447742").
# macOS: the console account is often "nome.cognome", so the matricola is looked up in order:
#   1. `app-sso platform -s` — first token anywhere in the output matching the UID format;
#   2. `klist` — local part of the Kerberos TGT principal (U######@SEDE);
#   3. neither -> FAIL-CLOSED: raises RuntimeError so callers (set-vertex-project, vertex-guard)
#      refuse to proceed. A masked app-sso value (g***a@domain) never matches the format.
# Result has the leading letter upper-cased (U######).
# (`_parse_upn`/`_appsso_upn` below are kept for set-vertex-project-doctor diagnostics.)
_UID_RE = re.compile(r"^[Uu][A-Za-z0-9]{6}$")
# Same format inside free text (app-sso output): not glued to other alphanumerics or to a mask '*'.
_UID_TOKEN_RE = re.compile(r"(?<![A-Za-z0-9*])[Uu][A-Za-z0-9]{6}(?![A-Za-z0-9*])")


_EMAIL_RE = re.compile(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}")
# klist header line: "        Principal: U######@SEDE.CORP.SANPAOLOIMI.COM" — colon-anchored so the
# krbtgt/service-ticket table rows are ignored. The local part is the ISP matricola.
_KLIST_RE = re.compile(r"Principal:\s*([A-Za-z0-9._%+\-]+)@", re.I)


def _parse_klist(text):
    """Extract the userid (matricola) from the `klist` Principal header. '' if absent
    (empty output / 'Cache not found' / no Principal line)."""
    if not text:
        return ""
    m = _KLIST_RE.search(text)
    return m.group(1).strip() if m else ""


def _parse_upn(text):
    """Extract the Platform SSO UPN (an email) from `app-sso platform -s` output.
    Tolerant to key naming: `upn`, `userPrincipalName`/`preferred_username` (via 'principal'/'username'),
    `login`, `email` — then, as a last resort, the first email-like token anywhere in the output.
    MASKED values are IGNORED: `app-sso -s` often redacts the username as `g***a@domain`; a naive match
    would yield the bogus local part `a` (-> developer.id 'A', see resolve_userid). A value containing
    '*', or an email-like token that is a fragment of a masked token, is skipped so the caller
    fails-closed instead of attributing telemetry to a wrong identity."""
    if not text:
        return ""
    for line in text.splitlines():
        if ":" in line and re.search(r"upn|principal|\blogin\b|username|mail", line, re.I):
            val = line.split(":", 1)[1].strip().strip(' \t",').replace('"', "").replace(",", "").strip()
            if "@" in val and "*" not in val:        # ignore masked UPN (e.g. g***a@domain)
                return val
    for m in _EMAIL_RE.finditer(text):               # format-agnostic fallback, skip masked fragments
        if "*" in m.group(0) or (m.start() > 0 and text[m.start() - 1] == "*"):
            continue
        return m.group(0)
    return ""


KLIST = "klist"     # resolved by system_tool (PATH + admin-owned folder), never run by name


def _klist_run(args=()):
    """(returncode, stdout) of klist (system_tool) in the C locale; (None, '') if it cannot run."""
    import subprocess
    try:
        env = dict(os.environ, LC_ALL="C")
        env.pop("KRB5CCNAME", None)      # user-set cache file could name any principal: system default only
        p = subprocess.run([system_tool_path("klist")] + list(args), capture_output=True, text=True, timeout=5,
                           env=env, encoding="utf-8", errors="replace")
        return p.returncode, p.stdout or ""
    except Exception:
        return None, ""


def _klist_uid():
    """macOS: userid (matricola) from the Kerberos TGT principal via `klist`. '' on any error
    (klist missing / no ticket). Fail-safe — never raises."""
    return _parse_klist(_klist_run()[1])


_KLIST_TIME_RE = re.compile(r"[A-Z][a-z]{2}\s+\d{1,2}\s+\d{1,2}:\d{2}(?::\d{2})?\s+\d{4}")


def _parse_klist_tgt(text):
    """(expires_epoch or None, expired_flag) of the krbtgt/ line of `klist` (Heimdal: 'Issued Expires
    Principal', or '>>>Expired<<<' in place of the expiry). (None, False) if there is no TGT line."""
    import time
    for line in (text or "").splitlines():
        if "krbtgt/" not in line:
            continue
        if "expired" in line.lower():
            return None, True
        stamps = _KLIST_TIME_RE.findall(line)
        if len(stamps) >= 2:
            s = " ".join(stamps[1].split())
            for fmt in ("%b %d %H:%M:%S %Y", "%b %d %H:%M %Y"):
                try:
                    return time.mktime(time.strptime(s, fmt)), False
                except ValueError:
                    pass
        return None, False
    return None, False


def kerberos_status():
    """macOS: state of the Kerberos TGT the matricola may come from, or None on Windows / if klist
    cannot run. {'present': principal in the cache, 'valid': `klist --test` ok (a valid ticket exists),
    'expires': krbtgt expiry (epoch) or None, 'uid': principal local part}."""
    if IS_WIN:
        return None
    rc, out = _klist_run()
    if rc is None:
        return None
    exp, expired_flag = _parse_klist_tgt(out)
    trc, _ = _klist_run(["--test"])
    return {"present": bool(_parse_klist(out)), "valid": trc == 0 and not expired_flag,
            "expires": exp, "uid": _parse_klist(out)}


def _appsso_upn():
    """macOS: UPN (email) from `app-sso platform -s`. '' on any error / no UPN. Fail-safe."""
    import subprocess
    try:
        out = subprocess.run([system_tool_path("app-sso"), "platform", "-s"],
                             capture_output=True, text=True, timeout=10)
    except Exception:
        return ""
    if out.returncode != 0 or not out.stdout:
        return ""
    return _parse_upn(out.stdout)


def _parse_appsso_uid(text):
    """First token in `app-sso platform -s` output matching the UID format, '' if none.
    The token must contain at least one digit, so plain words of the output (e.g. 'Unknown',
    'updated') are not taken for a userid. Masked values (g***a@...) never match."""
    for m in _UID_TOKEN_RE.finditer(text or ""):
        tok = m.group(0)
        if any(c.isdigit() for c in tok):
            return tok
    return ""


def _appsso_uid():
    """macOS: userid from `app-sso platform -s` (any field). '' on any error / no match. Fail-safe."""
    import subprocess
    try:
        out = subprocess.run([system_tool_path("app-sso"), "platform", "-s"],
                             capture_output=True, text=True, timeout=10)
    except Exception:
        return ""
    if out.returncode != 0:
        return ""
    return _parse_appsso_uid(out.stdout)


def _is_valid_uid(uid):
    """True if uid has the ISP userid format: 'U'/'u' + 6 alphanumerics (7 chars total).
    Rejects empty, masked ('*'), nome.cognome or junk like 'A' so resolve_userid FAILS-CLOSED
    instead of writing a wrong developer.id."""
    return bool(uid) and "*" not in uid and bool(_UID_RE.match(uid))


def os_login():
    """Login name of the current user from the OS, NOT from environment variables: getpass.getuser()
    reads LOGNAME/USER/LNAME/USERNAME first, which the user controls (LOGNAME=U123456 would impersonate
    another matricola in developer.id, CHAP0 calls and the identity checks)."""
    if IS_WIN:
        import ctypes
        from ctypes import wintypes
        buf = ctypes.create_unicode_buffer(257)
        size = wintypes.DWORD(len(buf))
        if ctypes.windll.advapi32.GetUserNameW(buf, ctypes.byref(size)):
            return buf.value
        return ""
    import pwd
    try:
        return pwd.getpwuid(os.getuid()).pw_name
    except KeyError:
        return ""


def resolve_userid_detail():
    """Same resolution as resolve_userid(), never raises, with the evidence for the user.
    Returns (uid, source, steps): uid with the leading letter upper-cased (None if not found),
    source = where it came from ('system login' / 'app-sso' / 'klist (Kerberos)'),
    steps = [(source, raw value or '', valid)] for every source tried, in order."""
    try:
        user = (os_login() or "").strip()
    except Exception:
        user = ""
    steps = [("system login", user, _is_valid_uid(user))]
    if steps[0][2]:
        return user[:1].upper() + user[1:], "system login", steps   # Windows / macOS matricola-login
    if not IS_WIN:
        for source, fetch in (("app-sso", _appsso_uid), ("klist (Kerberos)", _klist_uid)):
            candidate = (fetch() or "").strip()
            steps.append((source, candidate, _is_valid_uid(candidate)))
            if steps[-1][2]:
                return candidate[:1].upper() + candidate[1:], source, steps
    return None, None, steps


# --- Claude sessions started before the installed package (old version still in memory) ---
# A running `claude` keeps the binary and the OTEL resource attributes it started with: after a package
# upgrade an old session goes on with the old version and the old telemetry identity (seen on Mac:
# a 1.4.0 session still sending after the 1.5.1 install). Used by set-vertex-project and the doctor.
def _parse_ps_mac(text, uid):
    """[(pid, start_epoch, exe)] of the `claude` processes of `uid` from
    `ps -axo pid=,uid=,lstart=,comm=` (C locale; lstart = 'Thu Oct  8 16:34:46 2026')."""
    import time
    out = []
    for line in (text or "").splitlines():
        parts = line.split()
        if len(parts) < 8 or not parts[0].isdigit() or not parts[1].isdigit() or int(parts[1]) != uid:
            continue
        exe = " ".join(parts[7:])
        if os.path.basename(exe) != "claude":
            continue
        try:
            t0 = time.mktime(time.strptime(" ".join(parts[2:7]), "%a %b %d %H:%M:%S %Y"))
        except ValueError:
            continue
        out.append((int(parts[0]), t0, exe))
    return out


def claude_processes():
    """[(pid, start_epoch, exe)] of the `claude` processes of the current user; [] if not determinable."""
    import subprocess
    try:
        if IS_WIN:
            ps = (r"Get-Process -Name claude -ErrorAction SilentlyContinue | ForEach-Object { try { "
                  r"'{0}|{1}|{2}' -f $_.Id, ([DateTimeOffset]$_.StartTime).ToUnixTimeSeconds(), $_.Path } catch {} }")
            p = subprocess.run([system_tool_path("powershell"), "-NoProfile",
                                "-NonInteractive", "-Command", ps], capture_output=True, text=True, timeout=10,
                               encoding="utf-8", errors="replace", creationflags=0x08000000)  # no window
            out = []
            for line in (p.stdout or "").splitlines():
                f = line.strip().split("|", 2)
                if len(f) == 3 and f[0].isdigit() and f[1].isdigit():
                    out.append((int(f[0]), float(f[1]), f[2]))
            return out
        p = subprocess.run([system_tool_path("ps"), "-axo", "pid=,uid=,lstart=,comm="], capture_output=True, text=True,
                           timeout=10, env=dict(os.environ, LC_ALL="C"), encoding="utf-8", errors="replace")
        return _parse_ps_mac(p.stdout, os.getuid())
    except Exception:
        return []


def _session_records():
    """[(version, claude_pid or None, mtime)] of the session records (see session_pkg_check)."""
    out = []
    try:
        names = os.listdir(SESSION_PKG_DIR)
    except OSError:
        return out
    for fn in names:
        fp = os.path.join(SESSION_PKG_DIR, fn)
        try:
            v, pid = _read_session_record(fp)
            out.append((v, pid, os.path.getmtime(fp)))
        except Exception:
            continue
    return out


def _read_session_record(path):
    """(version, claude_pid or None) of a session record: JSON {"v", "pid"}; a plain version string is
    accepted too (records written before the pid was added)."""
    with open(path, encoding="utf-8") as f:
        raw = f.read().strip()
    try:
        d = json.loads(raw)
        if isinstance(d, dict):
            return (str(d.get("v") or ""), d.get("pid") if isinstance(d.get("pid"), int) else None)
    except ValueError:
        pass
    return raw, None


def stale_claude_sessions():
    """Processes of the authorized claude binary (current user) that still run a previous package:
    no session record written by THIS process (same pid, written after it started) for the installed
    version. Independent of file dates (Copy-Item keeps the source mtime on Windows). Processes of other
    executables called claude (e.g. Claude Desktop) are ignored. A session that never ran SessionStart
    with the current hooks (started before this check existed) has no record -> listed.
    Test override: CLAUDE_TEST_STALE_SESSIONS = JSON list of [pid, start, exe]."""
    forced = test_value("CLAUDE_TEST_STALE_SESSIONS")
    if forced is not None:
        try:
            return [tuple(x) for x in json.loads(forced)]
        except (ValueError, TypeError):
            return []
    cur = installed_pkg_version()
    if not cur:
        return []
    authorized = None
    try:
        with open(MANIFEST, encoding="utf-8") as f:
            name = ((json.load(f).get("platforms") or {}).get(platform_key()) or {}).get("binary")
        authorized = os.path.normcase(os.path.join(BIN_DIR, name)) if name else None
    except Exception:
        authorized = None
    records = [r for r in _session_records() if r[0] == cur and r[1]]
    out = []
    for pid, t0, exe in claude_processes():
        if authorized and os.path.normcase(exe or "") != authorized:
            continue
        if not any(r[1] == pid and r[2] >= t0 - 5 for r in records):    # 5 s tolerance
            out.append((pid, t0, exe))
    return out


SESSION_PKG_DIR = test_value("CLAUDE_TEST_SESSION_PKG_DIR") or \
    os.path.join(os.path.expanduser("~"), ".claude", ".session-pkg")
_SESSION_PKG_TTL = 30 * 86400        # records of sessions older than 30 days are pruned


def installed_pkg_version():
    """'version' of the installed config/version.json, or None."""
    try:
        with open(os.path.join(CONFIG_DIR, "version.json"), encoding="utf-8") as f:
            return (json.load(f).get("version") or "").strip() or None
    except Exception:
        return None


_NEW_PROCESS_SECS = 120     # a SessionStart within this time from the process start = a new process


def _version_for_session_start(source, pid, cur):
    """Package version to record at SessionStart. 'startup' = a new claude process -> the installed one.
    clear/compact/resume keep the SAME process (binary in memory): carry over the version already
    recorded for this pid, never the installed one (else /compact would unblock a stale session).
    No record for this pid: the installed version only if the process started moments ago (claude
    --resume launches a new process), otherwise None = do not record (an old process stays blocked)."""
    if source == "startup" or not pid:
        return cur
    import time
    start = next((t0 for p, t0, _e in claude_processes() if p == pid), None)
    # only records written by THIS process (after it started): a reused pid must not inherit the
    # version of a dead process (5 s tolerance, as stale_claude_sessions)
    mine = [r for r in _session_records() if r[1] == pid and (start is None or r[2] >= start - 5)]
    if mine:
        return max(mine, key=lambda r: r[2])[0]
    if start is not None and time.time() - start <= _NEW_PROCESS_SECS:
        return cur
    return None


def _new_claude_pid():
    """Fallback when the process-tree walk fails at a 'startup' SessionStart: the only claude process
    started in the last _NEW_PROCESS_SECS (the one running this hook), else None. Never used for
    clear/compact/resume: there it could pick another process and unblock a stale session."""
    import time
    now = time.time()
    young = [p for p, t0, _e in claude_processes() if 0 <= now - t0 <= _NEW_PROCESS_SECS]
    return young[0] if len(young) == 1 else None


def session_pkg_check(d):
    """Package upgraded under a running session. SessionStart (startup/resume/clear/compact): record
    session_id -> {installed package version, claude pid} (one file per session: hooks run in parallel;
    the pid lets set-vertex-project and the doctor tell which running claude processes are stale). Any other
    event: None if the session started with the installed version, else the block reason - also when
    the session was never recorded (started before this check existed, i.e. with an older package).
    No session_id / no version.json -> None (vertex-guard fails closed on a missing version.json).
    Client-side hygiene against forgotten sessions: the record is user-writable."""
    import time
    sid = re.sub(r"[^A-Za-z0-9-]", "", str((d or {}).get("session_id") or ""))[:80]
    cur = installed_pkg_version()
    if not sid or not cur:
        return None
    path = os.path.join(SESSION_PKG_DIR, sid)
    if ((d or {}).get("hook_event_name") or "SessionStart") == "SessionStart":
        try:
            source = (d or {}).get("source") or "startup"
            pid = claude_pid()
            if pid is None and source == "startup":
                pid = _new_claude_pid()   # else a record with pid null makes this new session look stale
            version = _version_for_session_start(source, pid, cur)
            if version is None:
                return None          # old process without a record: stays unrecorded -> blocked
            os.makedirs(SESSION_PKG_DIR, exist_ok=True)
            with open(path, "w", encoding="utf-8") as f:
                json.dump({"v": version, "pid": pid}, f)
            now = time.time()
            for fn in os.listdir(SESSION_PKG_DIR):
                fp = os.path.join(SESSION_PKG_DIR, fn)
                if now - os.path.getmtime(fp) > _SESSION_PKG_TTL:
                    os.remove(fp)
        except Exception as e:
            audit_log("session-pkg record failed type=%s" % type(e).__name__)
        return None
    try:
        started = _read_session_record(path)[0]
    except Exception:
        started = ""
    if started == cur:
        return None
    return ("The Claude Code ISP package was updated to %s, but this session started with %s: it still "
            "runs the previous version (binary in memory, old telemetry attributes). Close this session "
            "(/exit, or close the terminal/IDE) and start claude again."
            % (cur, started or "an older package"))


def kerberos_note(login_is_uid):
    """macOS: (level, text) on the Kerberos TGT for set-vertex-project and the doctor, or None (Windows,
    klist not runnable). The ticket matters when the login is not already the matricola: then the
    matricola may come from klist, and a missing/expired ticket stops it at the next logout/reboot.
    NEVER blocking: at most a warning (what blocks is the matricola check, resolve_userid).
    level: 'ok' | 'warn' | 'info'."""
    import time
    ks = kerberos_status()
    if ks is None:
        return None
    if not ks["present"]:
        return ("info" if login_is_uid else "warn"), "no Kerberos ticket (klist empty)"
    if not ks["valid"]:
        return ("info" if login_is_uid else "warn"), "Kerberos ticket EXPIRED (principal %s)" % ks["uid"]
    if ks["expires"] is None:
        return "ok", "Kerberos ticket valid (principal %s)" % ks["uid"]
    when = time.strftime("%d/%m %H:%M", time.localtime(ks["expires"]))
    if ks["expires"] - time.time() < 3600:
        return "warn", "Kerberos ticket expiring at %s (principal %s)" % (when, ks["uid"])
    return "ok", "Kerberos ticket valid until %s (principal %s)" % (when, ks["uid"])


def userid_step_why(val):
    """Why a value from resolve_userid_detail() steps is not a valid matricola (shown to the user)."""
    return ("empty / no value" if not val else
            "masked value" if "*" in val else
            "'%s' is not in the U + 6 characters format" % val)


def userid_fix_lines():
    """How to fix a missing matricola: same text in set-vertex-project and in the doctor."""
    if IS_WIN:
        return ["How to fix: sign in to Windows with your matricola (U######), not with another account."]
    return ["How to fix:",
            "  1) if the ISP password is EXPIRED or just changed, renew it first: without it Entra does not",
            "     issue the Kerberos ticket (the SSO token can be valid even without Kerberos)",
            "  2) System Settings > Users & Groups > (your user) > 'Platform Single Sign-On'",
            "     > 'Authenticate' (or 'Repair' if the registration is broken); or restart the Mac",
            "  3) check:  klist   (it must show  Principal: U######@SEDE.CORP.SANPAOLOIMI.COM)",
            "  4) run set-vertex-project again.   Full diagnosis: set-vertex-project-doctor"]


def resolve_userid():
    """ISP userid (e.g. 'U447742'), leading letter upper-cased. FAIL-CLOSED (raises) if a
    userid in the expected format cannot be derived.
    Resolution:
      1. getpass.getuser() when it already has the UID format (Windows, macOS matricola-login).
      2. macOS otherwise (e.g. 'nome.cognome' login), in order:
         a. `app-sso platform -s` — first token matching the UID format;
         b. `klist` — local part of the Kerberos TGT principal;
         c. none -> RAISE with a clear remediation.
    On failure set-vertex-project refuses to write and vertex-guard blocks the session, so telemetry
    is never attributed to a wrong developer.id."""
    uid, _source, _steps = resolve_userid_detail()
    if uid:
        return uid
    raise RuntimeError(
        "ISP matricola not resolvable (expected format U + 6 alphanumerics, e.g. U447742). "
        "Neither 'app-sso platform -s' nor 'klist' returned it (klist shows no "
        "\"Principal: U######@SEDE.CORP.SANPAOLOIMI.COM\"). Typical cause: the ISP password "
        "EXPIRED/CHANGED, so Platform SSO / Kerberos are not up to date. "
        "FIX: 1) renew your ISP password if expired; 2) System Settings > Users & Groups > <your user> "
        "> 'Platform Single Sign-On' > Authenticate (or 'Repair'); 3) verify 'klist' shows "
        "U######@SEDE; 4) re-run set-vertex-project. Full diagnosis: run set-vertex-project-doctor.")


# --- project-root confinement (sandbox emulation: reads/writes/cd confined to the root) ---
def project_root(d=None):
    """Launch/project root, STABLE across cd: CLAUDE_PROJECT_DIR, else stdin cwd, else getcwd().
    Same anchor as vertex-guard / statusline (workspace.project_dir)."""
    r = os.environ.get("CLAUDE_PROJECT_DIR") or ((d or {}).get("cwd")) or os.getcwd()
    try:
        return os.path.realpath(r)
    except Exception:
        return r


def path_within(path, root):
    """True if `path` (resolved; relative paths are taken against `root`) is inside `root`
    or equals it. Uses realpath so symlinks and `..` are resolved BEFORE the check
    (prevents `../../etc` and symlink escapes)."""
    try:
        p = path if os.path.isabs(path) else os.path.join(root, path)
        p = os.path.realpath(p)
        r = os.path.realpath(root)
    except Exception:
        return False
    pn = os.path.normcase(p)
    rn = os.path.normcase(r)
    return pn == rn or pn.startswith(rn + os.sep)


# --- stdin ---
def read_stdin_json():
    try:
        return json.load(sys.stdin)
    except Exception:
        return {}


def read_stdin_raw():
    try:
        return sys.stdin.read()
    except Exception:
        return ""


# --- decision helpers (Claude Code hook IO contract) ---
def block(reason):
    """PreToolUse/UserPromptSubmit: exit 2 = block; stderr = reason."""
    sys.stderr.write("BLOCKED by ISP policy: " + reason + "\n")
    sys.exit(2)


def _dumps(obj):
    return json.dumps(obj, separators=(",", ":"))  # compact (matches old -Compress)


def emit_decision(decision, reason, event="PreToolUse"):
    """PreToolUse JSON decision: allow | ask | deny."""
    print(_dumps({"hookSpecificOutput": {
        "hookEventName": event,
        "permissionDecision": decision,
        "permissionDecisionReason": "ISP policy: " + reason,
    }}))
    sys.exit(0)


def ask(reason):
    emit_decision("ask", reason)


def deny(reason):
    emit_decision("deny", reason)


def warn(context, event="PostToolUse"):
    """PostToolUse warn (no block): additionalContext to the model."""
    print(_dumps({"hookSpecificOutput": {
        "hookEventName": event,
        "additionalContext": context,
    }}))


def box(title, lines):
    """ASCII-framed multi-line block for user-facing hook text (systemMessage / stopReason /
    block reason). These render as PLAIN TEXT (no ANSI/color possible for hook output), so the
    emphasis is ASCII rules + newlines. `title` is the header, `lines` the body (list of str)."""
    w = 61
    out = ["", "=" * w, " " + title, "-" * w]
    out += [" " + str(x) for x in lines]
    out.append("=" * w)
    return "\n".join(out)


def system_message(msg):
    print(_dumps({"systemMessage": msg}))


def halt_turn(reason):
    """UserPromptSubmit: {continue:false} halts the turn before the model runs."""
    print(_dumps({"continue": False,
                  "stopReason": "BLOCKED by ISP policy: " + reason}))
    sys.exit(0)


# --- fail-CLOSED entry point: watchdog + error wrapper (used by every hook) ---
# Claude Code is fail-OPEN on hook timeout/crash: only exit 2 blocks; a killed,
# timed-out, or crashing hook lets the tool proceed silently. run_guard() flips
# that to fail-CLOSED: a watchdog forces exit 2 shortly before the configured
# `timeout`, and ANY unhandled exception also exits 2 with a retry message. A
# broken guard surfaces via developer reports rather than silently disabling
# protection.
def arm_watchdog(seconds, label):
    def _fire():
        sys.stderr.write("BLOCKED by ISP policy: %s exceeded %ds (fail-closed) - "
                         "operation inhibited, please retry.\n" % (label, int(seconds)))
        sys.stderr.flush()
        os._exit(2)   # from the timer thread: forces exit 2 (sys.exit wouldn't)
    t = threading.Timer(seconds, _fire)
    t.daemon = True
    t.start()
    return t


def run_guard(main_fn, label, deadline=25.0):
    """Wrap a hook's main(): watchdog (< the command `timeout` in 50-hooks.json)
    + fail-closed on any unhandled error. Explicit allow/ask/deny (sys.exit) pass
    through untouched."""
    arm_watchdog(deadline, label)
    try:
        main_fn()
    except SystemExit:
        raise                      # honour explicit decisions (sys.exit 0/2)
    except BaseException as e:
        try:
            audit_log("hook %s fail-closed on %s" % (label, type(e).__name__))
        except Exception:
            pass
        sys.stderr.write("BLOCKED by ISP policy: %s internal error (fail-closed) - "
                         "please retry; if it persists contact IT/Security.\n" % label)
        sys.stderr.flush()
        os._exit(2)


# --- PANIC killswitch (emergency containment) ---
def panic_active():
    if os.path.exists(PANIC_FILE):
        return True
    # Test-only ADDITIVE seam: the hardcoded PANIC_FILE is always checked first,
    # so this can NEVER disable the real killswitch (setting the var to a missing
    # path changes nothing; to an existing file only makes panic fire = self-DoS).
    extra = test_value("CLAUDE_TEST_PANIC_FILE")
    return bool(extra and os.path.exists(extra))


def panic_block():
    if panic_active():
        block("EMERGENCY KILLSWITCH ACTIVE. Contact IT/Security.")


# --- SIEM (best-effort, never blocks the dev loop) ---
def log_siem(payload):
    if not SIEM_URL:
        return
    try:
        import urllib.request
        req = urllib.request.Request(
            SIEM_URL,
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"},
        )
        urllib.request.urlopen(req, timeout=3)
    except Exception:
        pass


# --- local audit log (read by the SIEM agent) ---
def audit_log(msg):
    """mac: syslog via `logger`; else (win / no logger): append to the audit file.

    Windows Event Log writing is not used: it needs pywin32/admin registration
    and the audit file is collected by the SIEM agent anyway.
    """
    tag = "claude-code"
    if not IS_WIN:
        try:
            import subprocess
            subprocess.run([system_tool_path("logger"), "-t", tag, msg], timeout=5)   # never by name
            return
        except Exception:
            pass
    try:
        import datetime
        d = os.path.dirname(AUDIT_LOG)
        if d:
            os.makedirs(d, exist_ok=True)
        try:                                          # S-9: rotazione size-based (1 backup, atomica)
            if os.path.getsize(AUDIT_LOG) >= AUDIT_MAX_BYTES:
                os.replace(AUDIT_LOG, AUDIT_LOG + ".1")   # sovrascrive il .1 precedente
        except OSError:
            pass                                      # file assente (primo write) o race -> ignora
        ts = datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
        with open(AUDIT_LOG, "a", encoding="utf-8") as f:
            f.write("%s [%s] %s\n" % (ts, tag, msg))
    except Exception:
        pass


# --- anti-evasion: collapse split/concatenated literals before pattern matching ---
# Threat: the adversary is the model itself. After a deny it may split the literal
# ("AK"+"IA...", rm -r""f /). Scanners check BOTH the raw text and this normalized
# form so that trivial concatenation no longer evades the guard. Joins adjacent
# quoted string literals separated by a concat operator or nothing: Python/JS "+",
# PHP/Perl ".", PS/VB "&", C-style adjacency, and empty-quote splits inside a word
# (r""m). Applied repeatedly for "a"+"b"+"c".
# LIMIT (regex): catches adjacent-literal / embedded-split concatenation (the
# "split after a deny" workaround). Does NOT defeat base64/hex/char-code/variable
# indirection or whole-command quote-wrapping ("rm"" -rf /" via full quote-strip
# would false-positive on echo "rm -rf /"). Those are for the server-side
# pre-receive scan (Phase 2) and the SIEM behavioral rule "deny followed by an
# obfuscated retry".
_CONCAT_RE = re.compile(r"""['"]\s*[+.&]?\s*['"]""")


def deobfuscate(text):
    if not text:
        return text
    out = text
    for _ in range(6):
        new = _CONCAT_RE.sub("", out)
        if new == out:
            break
        out = new
    return out


def scan_text(text, compiled):
    """Match `compiled` [(regex,label)] against text AND its de-obfuscated form.
    Returns de-duplicated labels."""
    if not text:
        return []
    blob = text + "\n" + deobfuscate(text)
    return list(dict.fromkeys(lbl for rx, lbl in compiled if rx.search(blob)))


# --- egress allowlist (shared by bash-guard curl/wget + egress-guard WebFetch) ---
def load_egress_allowlist():
    """Returns list of allowed hosts, or None if the file is missing/unparseable."""
    try:
        with open(EGRESS_ALLOWLIST, encoding="utf-8") as f:
            hosts = json.load(f)["egressAllowlist"]["allowedHosts"]
        return hosts or None
    except Exception:
        return None


def load_egress_denylist():
    """Explicitly denied hosts, checked BEFORE the allowlist so a wildcard allow
    (e.g. '*.anthropic.com') cannot re-open a cyber-blocked host (e.g.
    'api.anthropic.com', §3.1 provider pin). Empty list if absent/unparseable."""
    try:
        with open(EGRESS_ALLOWLIST, encoding="utf-8") as f:
            return json.load(f)["egressAllowlist"].get("deniedHosts", []) or []
    except Exception:
        return []


def load_internal_hosts():
    """ISP-internal domain patterns (narrower than allowedHosts). Used only by
    bash-guard.py to allow GET-only curl/wget from Bash to internal sites.
    Empty list if absent/unparseable (fail-closed: no internal exemption)."""
    try:
        with open(EGRESS_ALLOWLIST, encoding="utf-8") as f:
            return json.load(f)["egressAllowlist"].get("internalHosts", []) or []
    except Exception:
        return []


def load_vpn_gate():
    """vpn-guard config (vpnGate block of egress-domains.json). Returns dict or {} if
    absent/unparseable (caller treats missing/disabled as 'feature off')."""
    try:
        with open(EGRESS_ALLOWLIST, encoding="utf-8") as f:
            return json.load(f).get("vpnGate") or {}
    except Exception:
        return {}


def host_matches(hostname, patterns):
    h = (hostname or "").lower()
    for pattern in patterns:
        p = pattern.lower()
        if p.startswith("*."):
            suffix = p[2:]
            if h == suffix or h.endswith("." + suffix):
                return True
        elif h == p:
            return True
    return False


# --- process-tree resolution for binary-integrity (the only OS-specific bit) ---
def _walk_mac(want_pid=False):
    import subprocess
    pid = os.getpid()
    depth = 0
    while pid and depth < 12:
        try:
            out = subprocess.run([system_tool_path("ps"), "-p", str(pid), "-o", "ppid=,comm="],
                                 capture_output=True, text=True,
                                 encoding="utf-8", errors="replace", timeout=5).stdout.strip()
        except Exception:
            return None
        if not out:
            return None
        parts = out.split(None, 1)
        ppid = int(parts[0]) if parts and parts[0].isdigit() else 0
        name = parts[1] if len(parts) > 1 else ""
        if "claude" in os.path.basename(name).lower():
            if want_pid:
                return pid
            try:
                lo = subprocess.run([system_tool_path("lsof"), "-p", str(pid)],
                                    capture_output=True, text=True,
                                    encoding="utf-8", errors="replace", timeout=5).stdout
                for ln in lo.splitlines():
                    f = ln.split()
                    if len(f) >= 4 and f[3] == "txt":
                        return f[-1]
            except Exception:
                return None
            return None
        if not ppid or ppid == pid:
            return None
        pid, depth = ppid, depth + 1
    return None


def _walk_win(want_pid=False):
    import ctypes
    from ctypes import wintypes
    TH32CS_SNAPPROCESS = 0x00000002

    class PROCESSENTRY32(ctypes.Structure):
        _fields_ = [
            ("dwSize", wintypes.DWORD),
            ("cntUsage", wintypes.DWORD),
            ("th32ProcessID", wintypes.DWORD),
            ("th32DefaultHeapID", ctypes.POINTER(ctypes.c_ulong)),
            ("th32ModuleID", wintypes.DWORD),
            ("cntThreads", wintypes.DWORD),
            ("th32ParentProcessID", wintypes.DWORD),
            ("pcPriClassBase", ctypes.c_long),
            ("dwFlags", wintypes.DWORD),
            ("szExeFile", ctypes.c_char * 260),
        ]

    k32 = ctypes.windll.kernel32
    snap = k32.CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0)
    if snap == -1:
        return None
    pmap = {}  # pid -> (ppid, name)
    try:
        entry = PROCESSENTRY32()
        entry.dwSize = ctypes.sizeof(PROCESSENTRY32)
        ok = k32.Process32First(snap, ctypes.byref(entry))
        while ok:
            pmap[entry.th32ProcessID] = (
                entry.th32ParentProcessID,
                entry.szExeFile.decode(errors="ignore"),
            )
            ok = k32.Process32Next(snap, ctypes.byref(entry))
    finally:
        k32.CloseHandle(snap)

    pid = os.getpid()
    depth = 0
    while pid and depth < 12:
        ent = pmap.get(pid)
        if not ent:
            return None
        ppid, name = ent
        if name.lower().startswith("claude"):
            return pid if want_pid else _win_exe_path(pid)
        if not ppid or ppid == pid:
            return None
        pid, depth = ppid, depth + 1
    return None


def _win_exe_path(pid):
    import ctypes
    from ctypes import wintypes
    PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
    k32 = ctypes.windll.kernel32
    h = k32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
    if not h:
        return None
    try:
        buf = ctypes.create_unicode_buffer(32768)
        size = wintypes.DWORD(len(buf))
        if k32.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(size)):
            return buf.value
    finally:
        k32.CloseHandle(h)
    return None


def resolve_claude_binary():
    """Full path of the running claude binary by walking the parent chain, or None."""
    try:
        return _walk_win() if IS_WIN else _walk_mac()
    except Exception:
        return None


def claude_pid():
    """PID of the claude process this hook runs under (parent chain), or None."""
    try:
        return _walk_win(want_pid=True) if IS_WIN else _walk_mac(want_pid=True)
    except Exception:
        return None


def sha256_file(path):
    import hashlib
    try:
        h = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                h.update(chunk)
        return h.hexdigest().lower()
    except Exception:
        return None


def platform_key():
    """manifest.json platform key for this host."""
    if IS_WIN:
        import platform
        machine = platform.machine().lower()
        return "win32-arm64" if ("arm" in machine) else "win32-x64"
    machine = os.uname().machine
    return "darwin-arm64" if machine == "arm64" else "darwin-x64"
