"""SessionStart + UserPromptSubmit hook — keep the per-directory ADC copy in sync with the
global ADC, synchronously and WITHOUT any gcloud/network call (pure file op, milliseconds).

Claude reads the per-directory ADC copy pointed at by GOOGLE_APPLICATION_CREDENTIALS
(settings.local.json), a mirror of the global ADC with quota_project_id forced to the folder's
Vertex project. After `gcloud auth application-default login` refreshes the global ADC (e.g. post
reauth / invalid_rapt), the local copy still holds the old refresh_token until it is re-mirrored.
check-gcp-token also mirrors, but it is async and can lose the race with the Vertex call in the
same turn, so a plain `gcloud login` alone often does not recover. This hook runs SYNC and mirrors
only when the refresh_token differs: `gcloud auth application-default login` is then enough — the
next turn's Vertex call reads a fresh local copy, no restart.

No gcloud, no network: reads/writes two JSON files. Identity is NOT verified here (that needs a
network mint); check-gcp-token (async) still verifies identity and warns on account change — same
as set-vertex-project, which also mirrors without an identity check. Convenience, not a security
control: FAIL-OPEN (any error -> exit 0), so it can never block a turn.
Test seam: CLAUDE_GLOBAL_ADC (global ADC path).
"""
import json
import os
import shutil
import sys
import isp_hooks as h


def _global_adc():
    p = h.test_value("CLAUDE_GLOBAL_ADC")   # test-seam
    if p:
        return p
    base = (os.environ.get("APPDATA", "") if sys.platform == "win32"
            else os.path.join(os.path.expanduser("~"), ".config"))
    return os.path.join(base, "gcloud", "application_default_credentials.json")


def _refresh_token(path):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f).get("refresh_token")
    except Exception:
        return None


def _settings_env(proj):
    try:
        with open(os.path.join(proj, ".claude", "settings.local.json"), encoding="utf-8") as f:
            return json.load(f).get("env") or {}
    except Exception:
        return {}


def main():
    d = h.read_stdin_json()
    proj = os.environ.get("CLAUDE_PROJECT_DIR") or d.get("cwd") or os.getcwd()
    env = _settings_env(proj)
    local_adc = (env.get("GOOGLE_APPLICATION_CREDENTIALS") or "").strip() or None
    project = (env.get("ANTHROPIC_VERTEX_PROJECT_ID") or "").strip() or None
    if not local_adc:
        return                             # no per-directory copy: nothing to mirror

    global_adc = _global_adc()
    g = _refresh_token(global_adc)
    if not g:
        return                             # no/unreadable global: check-gcp-token warns
    if g == _refresh_token(local_adc):
        return                             # already in sync (fresh login not yet done)

    # refresh_token differs (fresh global login) -> re-mirror global->local, quota re-forced.
    dirn = os.path.dirname(local_adc)
    if dirn and not os.path.isdir(dirn):
        os.makedirs(dirn, exist_ok=True)
    shutil.copyfile(global_adc, local_adc)
    with open(local_adc, encoding="utf-8") as f:
        data = json.load(f)
    if project:
        data["quota_project_id"] = project
    with open(local_adc, "w", encoding="utf-8") as f:
        json.dump(data, f)
    try:
        os.chmod(local_adc, 0o600)   # holds the refresh token: owner-only
    except OSError:
        pass


if __name__ == "__main__":
    try:
        main()
    except Exception:
        pass          # FAIL-OPEN: a mirror failure must never block the turn
    sys.exit(0)
