"""SessionStart + UserPromptSubmit hook — verify the GCP login and keep the per-directory ADC
copy current, with ONE gcloud call.

Claude uses a per-directory ADC copy (GOOGLE_APPLICATION_CREDENTIALS in settings.local.json,
written by set-vertex-project) that mirrors the global ADC with quota_project_id set to the
folder's Vertex project. The global ADC (shared refresh_token) is the source of truth, so this
hook makes ONE `gcloud auth application-default print-access-token` call (the global login):
  - if gcloud REFUSES the login (invalid_rapt/invalid_grant/expired, or no ADC file) ->
    systemMessage to log in. A timeout / network / other gcloud error proves nothing about the
    login -> a "not verified" message instead (no false "expired"). Never blocks.
    This hook only warns: the automatic browser re-login is Claude Code's gcpAuthRefresh, run
    by Claude Code itself when ITS credentials fail (not triggered by this hook).
  - if it works -> resolve the identity from that SAME token (OAuth tokeninfo, no extra gcloud
    call) and compare it to the per-dir baseline (.claude/gcp/.identity). If the identity
    changed (login as another account) -> do NOT touch the local copy and warn to log in with
    the right account. Otherwise mirror the fresh global ADC into the local copy (quota
    re-forced) so Claude always uses a current credential.

Async (50-hooks); throttled by the status cache (skips a recent OK). One gcloud call keeps it
well under the watchdog even where gcloud is slow. Writes {ts, ok} to the shared status cache.
The fast global->local mirror (after a plain `gcloud login`) is done SYNC by the adc-mirror
sibling so recovery lands on the next turn; this hook re-mirrors too (idempotent) and owns the
identity guard, which adc-mirror cannot do cheaply.
Test seams (keys of config/test-overrides.json, never env vars): CLAUDE_TEST_GCP=1 (mint ok = file exists & parses; identity = global sidecar
'<file>.email'), CLAUDE_GLOBAL_ADC (global path), CLAUDE_GCP_STATUS_CACHE (cache path).
"""
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import isp_hooks as h

THROTTLE_SEC = 5 * 60
STATUS_CACHE = h.test_value("CLAUDE_GCP_STATUS_CACHE") or \
    os.path.join(tempfile.gettempdir(), "claude-statusline-gcp.json")
_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)  # hide console window on Windows

LOGIN_MSG_LOCAL = h.box("⚠  GCP LOGIN EXPIRED / reauth (invalid_rapt)", [
    "Claude Code (Vertex) and telemetry are not working.",
    "-> Run:  gcloud auth application-default login",
    "The local ADC copy re-syncs itself on the next turn",
    "(adc-mirror hook) - no restart needed."])
LOGIN_MSG_GLOBAL = h.box("⚠  GCP LOGIN EXPIRED or missing", [
    "Claude Code (Vertex) and telemetry are not working.",
    "-> Run:  set-vertex-project  (.cmd Windows / .sh macOS)",
    "   does the GCP login + sets the Vertex project,",
    "   then restart Claude Code."])
UNVERIFIED_MSG = h.box("⚠  GCP login NOT verified (it may still be valid)", [
    "%s",
    "No action needed if Claude keeps answering: checked again",
    "on the next prompt. If it persists: set-vertex-project-doctor"])
NO_GCLOUD_MSG = h.box("⚠  gcloud not found on PATH", [
    "Claude Code (Vertex) needs the Google Cloud CLI for the GCP login.",
    "-> Install Google Cloud CLI, then re-run set-vertex-project."])
ACCOUNT_CHANGED_MSG = h.box("⚠  GCP global identity changed", [
    "Expected: %s",
    "Found:    %s",
    "The local copy was NOT updated (avoids importing the wrong account).",
    "-> gcloud auth application-default login  + pick the right account.",
    "   If the change is intended: re-run set-vertex-project."])


def _global_adc():
    p = h.test_value("CLAUDE_GLOBAL_ADC")   # test-seam
    if p:
        return p
    base = (os.environ.get("APPDATA", "") if sys.platform == "win32"
            else os.path.join(os.path.expanduser("~"), ".config"))
    return os.path.join(base, "gcloud", "application_default_credentials.json")


MINT_TIMEOUT = 20    # + tokeninfo 10s stays within the 30s hook timeout (50-hooks)
# gcloud stderr that means the login itself is gone: same classification as set-vertex-project and
# the doctor (isp_hooks.adc_check), so the three never disagree.
_REFUSED_RE = h.GCLOUD_REFUSED_RE


def _mint(cred_file):
    """(token, why) from cred_file (None -> global ADC). token '' on failure; why = '' (ok),
    'refused' (login expired/missing: a new login is needed), 'timeout', 'nogcloud' or
    'error: <first gcloud stderr line>' (login NOT verified, may still be valid).
    Test-mode (CLAUDE_TEST_GCP=1): 'TESTTOK' if the file exists & parses, else refused;
    CLAUDE_TEST_GCP_FAIL=timeout|nogcloud|error forces that outcome."""
    if h.test_value("CLAUDE_TEST_GCP") == "1":
        fail = h.test_value("CLAUDE_TEST_GCP_FAIL")
        if fail:
            return "", ("error: test failure" if fail == "error" else fail)
        try:
            with open(cred_file or _global_adc(), encoding="utf-8") as f:
                json.load(f)
            return "TESTTOK", ""
        except Exception:
            return "", "refused"
    if not os.path.isfile(cred_file or _global_adc()):
        return "", "refused"
    g = h.find_gcloud()
    if not g:
        return "", "nogcloud"
    env = dict(os.environ)
    if cred_file:
        env["GOOGLE_APPLICATION_CREDENTIALS"] = cred_file
    else:
        env.pop("GOOGLE_APPLICATION_CREDENTIALS", None)
    try:
        p = subprocess.run([g, "auth", "application-default", "print-access-token"],
                           capture_output=True, text=True, timeout=MINT_TIMEOUT,
                           creationflags=_NO_WINDOW, env=env, encoding="utf-8", errors="replace")
    except subprocess.TimeoutExpired:
        return "", "timeout"
    except Exception as e:
        return "", "error: %s" % type(e).__name__
    if p.returncode == 0 and (p.stdout or "").strip():
        return p.stdout.strip(), ""
    return "", h.gcloud_error_why(p.returncode, p.stderr)


def _identity(tok):
    """Email behind an access token via the OAuth tokeninfo endpoint (no extra gcloud call),
    or None if unresolvable (offline/proxy). Test-mode: read the global sidecar '<global>.email'."""
    if h.test_value("CLAUDE_TEST_GCP") == "1":
        try:
            with open(_global_adc() + ".email", encoding="utf-8") as f:
                return (f.read().strip().lower() or None)
        except Exception:
            return None
    return h.tokeninfo_email(tok)


def _settings_env(proj):
    try:
        with open(os.path.join(proj, ".claude", "settings.local.json"), encoding="utf-8") as f:
            return json.load(f).get("env") or {}
    except Exception:
        return {}


def _baseline_path(local_adc):
    return os.path.join(os.path.dirname(local_adc), ".identity")


def _read_baseline(local_adc):
    try:
        with open(_baseline_path(local_adc), encoding="utf-8") as f:
            return (json.load(f).get("email") or "").strip().lower() or None
    except Exception:
        return None


def _write_baseline(local_adc, email):
    try:
        d = os.path.dirname(local_adc)
        if d and not os.path.isdir(d):
            os.makedirs(d, exist_ok=True)
        with open(_baseline_path(local_adc), "w", encoding="utf-8") as f:
            json.dump({"email": email, "ts": time.time()}, f)
    except Exception:
        pass


def _repair_local(local_adc, project):
    """Mirror the global ADC into the per-dir copy and set quota_project_id to the folder's
    Vertex project (same op as set-vertex-project). Returns True on success."""
    try:
        d = os.path.dirname(local_adc)
        if d and not os.path.isdir(d):
            os.makedirs(d, exist_ok=True)
        shutil.copyfile(_global_adc(), local_adc)
        with open(local_adc, encoding="utf-8") as f:
            data = json.load(f)
        if project:
            data["quota_project_id"] = project
        with open(local_adc, "w", encoding="utf-8") as f:
            json.dump(data, f)
        return True
    except Exception:
        return False


def _cache(ok):
    try:
        with open(STATUS_CACHE, "w", encoding="utf-8") as f:
            json.dump({"ts": time.time(), "ok": ok}, f)
    except Exception:
        pass


def main():
    d = h.read_stdin_json()
    proj = os.environ.get("CLAUDE_PROJECT_DIR") or d.get("cwd") or os.getcwd()
    env = _settings_env(proj)
    local_adc = (env.get("GOOGLE_APPLICATION_CREDENTIALS") or "").strip() or None
    project = (env.get("ANTHROPIC_VERTEX_PROJECT_ID") or "").strip() or None

    # Throttle: short-circuit only a recent OK (a failure re-checks each turn -> fast recovery).
    try:
        with open(STATUS_CACHE, encoding="utf-8") as f:
            c = json.load(f)
        if c.get("ok") and (time.time() - c.get("ts", 0) < THROTTLE_SEC):
            sys.exit(0)
    except Exception:
        pass

    # ONE gcloud call: validate the global login (the shared identity/refresh_token).
    tok, why = _mint(None)
    if not tok:
        _cache(False)
        if why == "refused":
            h.system_message(LOGIN_MSG_LOCAL if local_adc else LOGIN_MSG_GLOBAL)
        elif why == "nogcloud":
            h.system_message(NO_GCLOUD_MSG)
        else:                              # timeout / error: login NOT verified, not "expired"
            detail = ("gcloud did not answer within %ds." % MINT_TIMEOUT if why == "timeout"
                      else "gcloud " + why)
            h.system_message(UNVERIFIED_MSG % detail)
        sys.exit(0)

    if not local_adc:                      # no per-directory copy: global validity is enough
        _cache(True)
        sys.exit(0)

    # Identity guard — reuse the token already minted (no extra gcloud call).
    gid = _identity(tok)
    base = _read_baseline(local_adc)
    if base and gid and gid != base:
        _cache(False)
        h.system_message(ACCOUNT_CHANGED_MSG % (base, gid))
        sys.exit(0)

    # Mirror the fresh global ADC into the per-directory copy (quota re-forced to this project).
    if _repair_local(local_adc, project):
        if gid:
            _write_baseline(local_adc, gid)
        _cache(True)
    else:
        _cache(False)
    sys.exit(0)


if __name__ == "__main__":
    h.run_guard(main, "check-gcp-token")
