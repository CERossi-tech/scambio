"""chap0_auth — gateway authentication token for the CHAP0 hook calls (CLAUDECODE-58).

Client-side implementation of the OAuth2-style client-credentials flow (with the gateway's
custom gen_jwt grant, see below) used to authenticate the 2 hook calls to the Microservice
through the API gateway (Apigee/F5):
  - chiamata 0 (lista progetti)   -> set-vertex-project._fetch_projects
  - chiamata 1 (validazione)      -> project-vidima._validate

Minimal re-implementation of the Java "JWT Provisioner" pattern (token type ACCESS,
grant_type=gen_jwt) with only what a short-lived Python CLI hook needs:
mint -> cache-on-file -> reuse -> re-mint on expiry/401. No background refresh, no threads
(the hook starts and dies per SessionStart), no scope/clientId per-call override.

Config resolution (file-first, env override — same spirit as the ISP connector getToken):
  1. env vars CHAP0_HOOK_OAUTH_URL / _CLIENT_ID / _CLIENT_SECRET / _SCOPE (each overrides the file);
  2. file <ClaudeCode>/config/chap0-gateway.json, section chosen by _resolve_env() from
     config/version.json "env" (the per-branch source of truth deployed on every machine; NO
     env-var override, NO default) — with keys oauth_url / client_id / client_secret / scope.
     Override the path with CHAP0_HOOK_GATEWAY_FILE (useful when running from the repo, before deploy).
Feature is OFF (get_token -> None, no Authorization header) when neither source yields a full config.

Token cache: CHAP0_HOOK_TOKEN_CACHE_PATH (default ~/.claude/chap0-token-cache.json), atomic write,
0600. Considered valid until expires_in minus CHAP0_HOOK_TOKEN_EXPIRATION_MARGIN_SECONDS (default 30).
The cache is keyed to the (oauth_url, client_id, scope) triple so a cache from another environment is
never reused.

The client_secret and the access_token are secrets: never logged, never printed, never put on a
command line. Stdlib only.
"""
import base64
import hashlib
import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request

import isp_hooks as h

DEFAULT_MARGIN = 30            # hardcoded — non sovrascrivibile via env (parametro di sicurezza)
DEFAULT_TIMEOUT = 4.0          # hardcoded — non sovrascrivibile via env
MAX_RETRY_401 = 1             # ATE: re-mint + retry the call once on 401


class GatewayAuthError(Exception):
    """Raised by open_with_auth when the MANDATORY Bearer cannot be obtained.
    server_down=True  -> the OAuth token endpoint is a genuine outage (network/timeout/5xx/429)
                         -> the caller may fail-open;
    server_down=False -> the credential was actively rejected (401/403) or is missing/misconfigured
                         -> the caller must fail-closed (block). (CLAUDECODE-58 posture, FIX-1a)"""
    def __init__(self, message, server_down):
        super().__init__(message)
        self.server_down = server_down


def _gateway_file():
    return h.test_value("CHAP0_HOOK_GATEWAY_FILE") or os.path.join(h.CONFIG_DIR, "chap0-gateway.json")


def _resolve_env():
    """Env della sezione gateway (svil/test/collaudo/prod), da config/version.json "env" — la fonte
    per-branch dell'ambiente, deployata su ogni macchina. UNICA fonte a runtime (S-5): NIENTE override
    via env var CHAP0_ENV (una shell var dell'utente non deve poter puntare una macchina PROD al gateway
    SVIL) e NIENTE default 'svil' (in fallback una version.json rotta su prod chiamerebbe l'endpoint svil).
    Un env non risolto -> None -> feature OFF (get_api_base_url ritorna None, con audit). Case-insensitive.
    Nota: il CHAP0_ENV di build-release.sh e' build-time (quale sezione/segreto impacchettare), separato."""
    try:
        with open(os.path.join(h.CONFIG_DIR, "version.json"), encoding="utf-8") as f:
            v = (json.load(f).get("env") or "").strip()
    except Exception:
        v = ""
    return v.lower() or None


def get_api_base_url():
    """CHAP0 microservice base URL for the current env (version.json "env").
    Reads api_base_url from the gateway file section. Returns None (feature OFF) if the gateway file
    is absent, the env is unresolved (misconfig -> audited, S-5), or the URL is a placeholder."""
    v = h.test_value("CHAP0_API_BASE_URL")
    if v:
        return v
    try:
        with open(_gateway_file(), encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        return None                                    # gateway file assente -> feature genuinamente OFF
    env = _resolve_env()
    if env is None:                                    # gateway file presente ma env non risolto = misconfig
        h.audit_log("chap0 env unresolved (version.json missing/invalid) - vidima disabled")
        return None                                    # opzione A: no block, utente su vecchio progetto/OPEX
    section = data.get(env) or {}
    url = section.get("api_base_url") or ""
    if not url or url.startswith("<"):
        return None
    if not url.lower().startswith("https://"):   # I1: Bearer viaggia su api_base_url -> no http
        h.audit_log("chap0 api_base_url non-https - refusing to send Bearer in cleartext")
        return None
    return url


def _load_config():
    """Return {oauth_url, client_id, client_secret, scope} or None if not fully configured.
    Only the gateway file section (plus test overrides, isp_hooks.test_value): NOT environment variables,
    which the user controls (an oauth_url / api_base_url of their own would fake the vidima)."""
    oauth = h.test_value("CHAP0_HOOK_OAUTH_URL")
    cid = h.test_value("CHAP0_HOOK_CLIENT_ID")
    csec = h.test_value("CHAP0_HOOK_CLIENT_SECRET")
    scope = h.test_value("CHAP0_HOOK_SCOPE")
    section = {}
    if not (oauth and cid and csec and scope):
        try:
            with open(_gateway_file(), encoding="utf-8") as f:
                section = json.load(f).get(_resolve_env()) or {}
        except Exception:
            section = {}
    cfg = {
        "oauth_url": oauth or section.get("oauth_url"),
        "client_id": cid or section.get("client_id"),
        "client_secret": csec or section.get("client_secret"),
        "scope": scope or section.get("scope"),
    }
    if not all(cfg.values()):
        return None                                        # config incompleta -> feature OFF
    if not cfg["oauth_url"].lower().startswith("https://"):  # S-6: il client_secret va in Basic al mint;
        h.audit_log("chap0 oauth_url non-https - refusing to send client_secret in cleartext")
        return None                                        # oauth_url non cifrato -> niente mint (caller blocca)
    return cfg


def _margin():
    return DEFAULT_MARGIN   # hardcoded — la env var CHAP0_HOOK_TOKEN_EXPIRATION_MARGIN_SECONDS non è più letta


def _cache_path():
    return h.test_value("CHAP0_HOOK_TOKEN_CACHE_PATH") or \
        os.path.join(os.path.expanduser("~"), ".claude", "chap0-token-cache.json")


def _cache_key(cfg):
    """Stable id of the (oauth_url, client_id, scope) triple — no secret material in it."""
    raw = "\n".join([cfg["oauth_url"], cfg["client_id"], cfg["scope"]]).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()[:16]


def _read_cache():
    try:
        with open(_cache_path(), encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _write_cache(obj):
    """Atomic (temp + rename) + 0600. Best-effort: a cache failure only costs one extra mint."""
    p = _cache_path()
    try:
        d = os.path.dirname(p)
        if d:
            os.makedirs(d, exist_ok=True)
        tmp = "%s.%d.tmp" % (p, os.getpid())
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)   # 0600 atomic (no chmod TOCTOU, no symlink follow)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(obj, f)
        os.replace(tmp, p)
    except Exception:
        pass


def _mint(cfg, timeout):
    """POST the token endpoint (Basic client_id:client_secret, form grant_type=gen_jwt —
    custom grant of the ISP gwad0 gateway, NOT standard OAuth2 client_credentials; see the
    module docstring. Do not "correct" it back to client_credentials or auth breaks).
    Returns (access_token, expires_in_seconds). Raises on network/HTTP error.

    Test seam: key CHAP0_HOOK_TEST_MINT of config/test-overrides.json = JSON of the token response."""
    seam = h.test_value("CHAP0_HOOK_TEST_MINT")
    if seam is not None:
        d = json.loads(seam)
    else:
        basic = base64.b64encode(
            ("%s:%s" % (cfg["client_id"], cfg["client_secret"])).encode("utf-8")).decode("ascii")
        body = urllib.parse.urlencode(
            {"grant_type": "gen_jwt", "scope": cfg["scope"]}).encode("utf-8")
        req = urllib.request.Request(
            cfg["oauth_url"], data=body, method="POST",
            headers={"Authorization": "Basic " + basic,
                     "Content-Type": "application/x-www-form-urlencoded"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            d = json.load(r)
    return d.get("access_token"), float(d.get("expires_in") or 0)


def get_token(force_refresh=False, timeout=None):
    """Valid ACCESS token string, or None if the feature is OFF (no config). RAISES the underlying
    mint error (HTTPError / URLError / timeout) so the caller can tell an outage from a denial.
    Reuses the on-file cache unless force_refresh, expired, or from another (env) triple."""
    cfg = _load_config()
    if not cfg:
        return None
    try:
        timeout = float(timeout or DEFAULT_TIMEOUT)   # hardcoded — CHAP0_API_TIMEOUT non è più letta
    except Exception:
        timeout = DEFAULT_TIMEOUT
    key = _cache_key(cfg)
    if not force_refresh:
        c = _read_cache()
        if c.get("key") == key and c.get("access_token"):
            try:
                if time.time() < float(c.get("expires_at") or 0):
                    return c["access_token"]
            except Exception:
                pass
    try:
        tok, expires_in = _mint(cfg, timeout)
    except Exception as e:
        h.audit_log("chap0 gateway mint failed type=%s code=%s"
                    % (type(e).__name__, getattr(e, "code", "-")))   # class + HTTP code only, never str(e)
        raise                          # propagate so open_with_auth can classify outage vs denial (FIX-1a)
    if not tok:
        return None
    _write_cache({"key": key, "access_token": tok,
                  "expires_at": time.time() + max(0.0, expires_in - _margin())})
    return tok


def open_with_auth(url, timeout, method="GET", data=None, headers=None):
    """urlopen with a MANDATORY 'Authorization: Bearer <token>' from get_token(); on HTTP 401 re-mint
    the token once and retry (ATE: retry=1). The Bearer is ALWAYS required and sent (ATE: "ciascuna
    chiamata deve presentare un token Bearer") — if a token cannot be obtained the request is NOT sent
    unauthenticated: it raises GatewayAuthError with server_down classified (outage -> caller may
    fail-open; active denial/misconfig -> caller must block, FIX-1a). HTTP errors from the request
    itself (e.g. 401/403/404 on /validate) and other exceptions propagate unchanged to the caller."""
    base_headers = dict(headers or {})

    def _do(force):
        try:
            tok = get_token(force_refresh=force, timeout=timeout)
        except urllib.error.HTTPError as e:                     # token endpoint answered with a status
            raise GatewayAuthError("token endpoint HTTP %s" % e.code,
                                   server_down=(e.code >= 500 or e.code == 429))
        except Exception:                                       # network/timeout/TLS on the token endpoint
            raise GatewayAuthError("token endpoint unreachable", server_down=True)
        if not tok:                                             # feature not configured / config incomplete
            raise GatewayAuthError("gateway token unavailable (not configured)", server_down=False)
        hh = dict(base_headers)
        hh["Authorization"] = "Bearer " + tok
        req = urllib.request.Request(url, data=data, headers=hh, method=method)
        return urllib.request.urlopen(req, timeout=timeout)

    try:
        return _do(False)
    except urllib.error.HTTPError as e:
        if e.code == 401 and MAX_RETRY_401:
            return _do(True)
        raise
