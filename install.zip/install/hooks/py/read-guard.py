"""PreToolUse(Read) hook — confine the Read tool to the project root (sandbox emulation).

Compensating control for the pending OS sandbox: Read is limited to the project root
(workspace.project_dir / CLAUDE_PROJECT_DIR, STABLE across cd) + a small allowlist
(~/.gitconfig, ~/.claude). Cyber wants an OS sandbox; until then this hook emulates its
filesystem confinement for the Read tool. PANIC-aware. exit 2 = block.
"""
import os
import sys
import isp_hooks as h


def main():
    d = h.read_stdin_json()
    h.panic_block()

    fp = (d.get("tool_input") or {}).get("file_path") or ""
    if not fp:
        sys.exit(0)  # fail-open on empty input

    root = h.project_root(d)
    if h.path_within(fp, root):
        sys.exit(0)

    home = os.path.expanduser("~")
    for a in (os.path.join(home, ".gitconfig"), os.path.join(home, ".claude")):
        if h.path_within(fp, a):
            sys.exit(0)

    h.block("Read of '%s' is outside the project directory. Reads are confined to the "
            "project root + allowlisted paths (~/.gitconfig, ~/.claude). "
            "(Sandbox emulation - see pending/sandbox/)." % fp)


if __name__ == "__main__":
    h.run_guard(main, "read-guard")
