"""project-vidima hook — validate the chosen ISP capitalization project; block if the API rejects it.

Capitalizzazione token Claude Code (CHAP0), componente "Claude Code (hooks)" — chiamata 1
"validazione" (CLAUDECODE-53).

Registered on TWO events (same pattern as vpn-guard):
  SessionStart     -> validate (POST /v1/projects/validate) and cache the outcome in
                      <proj>/.claude/.vidima-state. A SessionStart exit only warns.
  UserPromptSubmit -> ENFORCE + THROTTLED re-validation. The API is called only when the cached
                      outcome is STALE (older than the TTL), from a new session, or for a changed
                      project_key — NOT on every submit. Otherwise the cached outcome is used.
                      If the API REJECTS the project (invalid = not enabled / no budget, or unknown =
                      404), {continue:false} halts the turn. This gives a real (defense-in-depth) block
                      with a bounded re-validation cadence (default: first time + hourly), coherent with
                      the AFU note "vidima ogni ora".

The chosen project is isp.project_id (set by set-vertex-project in the OTEL var,
<proj>/.claude/settings.local.json). The status line reads .vidima-state to color 'isp.prj'
(green if vidimated, red if blocking) and show the residual budget.

Blocking semantics (vidima ALWAYS from the /validate RESPONSE BODY — server authoritative):
  - ok       (enabled && sufficient_budget; incl. the server's OPEX fallback) -> allow
  - invalid  (API rejects: enabled=false OR sufficient_budget=false)          -> BLOCK
  - unknown  (HTTP 404 not-found, no fallback)                                -> BLOCK
  - unreachable (no verdict: 5xx/timeout/TLS/401/403/429/400)                 -> NO block: the declared project STANDS
  - no project declared (isp empty)                                           -> BLOCK (must select a project from the list)
  - OPEX explicitly set                                                       -> VALIDATED like any project (follow the server;
                                                                                 the updated server returns enabled=false -> BLOCK)
We follow the server verdict for ANY declared project (no client short-circuit). Same policy on
SessionStart, first UserPromptSubmit, and the hourly re-validation.

Client-side defense-in-depth: within the TTL the outcome is a cache file (forgeable by editing it
or via --bare); the hourly re-validation and the server-side telemetry attribution (isp.project_id)
are the real controls. Opt-in: active only when CHAP0_API_BASE_URL is set. Identity via X-User-Id
(matricola, OP-64); gateway Bearer minted/cached/refreshed by chap0_auth (CLAUDECODE-58).
"""
import json
import os
import time
import urllib.request
import urllib.error
import isp_hooks as h
import chap0_auth

BLOCK_STATES = ("invalid", "unknown", "empty", "mismatch", "denied")   # rifiutato / 404 / nessun progetto / progetto diverso da dichiarato / accesso negato -> blocca
DEFAULT_TTL = 3600            # hardcoded — non sovrascrivibile via env (parametro di sicurezza)

REMEDY = ["Fix the ISP project with set-vertex-project (pick a valid project from the list),",
          "then restart Claude Code."]


def _ttl():
    return DEFAULT_TTL   # hardcoded — la env var CHAP0_VIDIMA_TTL_SECONDS non è più letta


def _state_path(proj):
    return os.path.join(proj, ".claude", ".vidima-state")


def _isp_project(proj):
    """isp.project_id from <proj>/.claude/settings.local.json OTEL_RESOURCE_ATTRIBUTES. '' if absent."""
    try:
        with open(os.path.join(proj, ".claude", "settings.local.json"), encoding="utf-8") as f:
            otel = (json.load(f).get("env") or {}).get("OTEL_RESOURCE_ATTRIBUTES") or ""
    except Exception:
        return ""
    for part in otel.split(","):
        k, _, v = part.partition("=")
        if k.strip() == "isp.project_id":
            return v.strip()
    return ""


def _write_state(proj, obj):
    """Persist the vidima outcome per-project (display cache + enforcement source). Atomic + 0600."""
    p = _state_path(proj)
    try:
        os.makedirs(os.path.dirname(p), exist_ok=True)
        tmp = "%s.%d.tmp" % (p, os.getpid())
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)   # 0600 atomic (no chmod TOCTOU, no symlink follow)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(obj, f)
        os.replace(tmp, p)
    except Exception as e:
        # best-effort ma NON silenzioso (S-4): se la persistenza fallisce, _stale() ritorna sempre
        # True -> ri-validazione a ogni prompt (throttle orario perso, gateway martellato). Traccia
        # solo il tipo eccezione (mai str(e)/path), coerente con FIX-6.
        h.audit_log("vidima state write failed type=%s" % type(e).__name__)


def _read_state(proj):
    try:
        with open(_state_path(proj), encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _classify(project_key, data):
    """Vidima state from the /validate RESPONSE BODY — the server is AUTHORITATIVE.
    enabled && sufficient_budget -> ok, else invalid.
    MISMATCH: if the server returns a different project_key than declared (e.g. OPEX fallback
    for an old/unknown key), telemetry attribution would be wrong — block and force
    set-vertex-project to re-align the declared project with what the API accepts."""
    data = data or {}
    returned_key = (data.get("project_key") or "").strip()
    if returned_key and returned_key != project_key:
        return "mismatch"
    if data.get("enabled") is True and data.get("sufficient_budget") is True:   # JSON booleans per Swagger; reject hostile/malformed truthy (e.g. "x", 1)
        return "ok"
    return "invalid"


def _validate(base, project_key, uid, timeout):
    """POST /v1/projects/validate. Returns (state, response_dict|None).
    state: ok|invalid|unknown|denied|unreachable. Posture (FIX-1a): the ONLY fail-open case is a
    genuine outage (server down / 5xx / 429 / network / timeout); an active denial (401/403/other
    4xx, or a rejected/missing credential) -> 'denied' -> block."""
    forced = h.test_value("CHAP0_TEST_VALIDATE")   # deterministic test seam (no network)
    if forced == "ok":
        return "ok", {"project_key": project_key, "enabled": True, "sufficient_budget": True, "residual_budget_eur": 1234.0}
    if forced == "invalid":
        return "invalid", {"project_key": project_key, "enabled": False, "sufficient_budget": False,
                           "residual_budget_eur": 0.0, "reason": "Capienza esaurita"}
    if forced in ("unknown", "unreachable", "denied"):
        return forced, None
    url = base.rstrip("/") + "/v1/projects/validate"
    body = json.dumps({"project_key": project_key}).encode("utf-8")
    headers = {"X-User-Id": uid, "Content-Type": "application/json"}
    try:
        # Bearer + 1 retry on 401 handled by chap0_auth (CLAUDECODE-58 gateway auth)
        with chap0_auth.open_with_auth(url, timeout, method="POST", data=body, headers=headers) as r:
            data = json.load(r)
        return _classify(project_key, data), data        # vidima dal response body (server autoritativo)
    except chap0_auth.GatewayAuthError as e:
        # Bearer non ottenibile: outage del token endpoint -> fail-open; rifiuto/misconfig -> block
        h.audit_log("vidima token unavailable server_down=%s" % e.server_down)
        return ("unreachable" if e.server_down else "denied"), None
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return "unknown", None
        if e.code == 429 or e.code >= 500:
            h.audit_log("vidima validate unreachable code=%s" % e.code)   # HTTP code only, never str(e)/body
            return "unreachable", None                                    # server giu'/busy -> fail-open
        h.audit_log("vidima validate denied code=%s" % e.code)
        return "denied", None                                            # 401/403/altri 4xx -> rifiuto attivo -> block
    except Exception as e:
        h.audit_log("vidima validate unreachable type=%s" % type(e).__name__)
        return "unreachable", None                                       # rete/timeout/TLS -> fail-open


def _validate_and_store(base, proj, pk, sid):
    """Call the API for pk, persist the outcome (+ checked_at/session_id), return the state dict."""
    try:
        uid = h.resolve_userid()
    except Exception:
        uid = "-"
    timeout = 4.0   # hardcoded — CHAP0_API_TIMEOUT non è più letta
    state, resp = _validate(base, pk, uid, timeout)
    # unreachable (nessun verdetto: timeout/5xx/4xx/token KO) -> resp None -> title/budget azzerati:
    # resta il progetto dichiarato ma NON verde e SENZA budget (non calcolabile).
    obj = {"state": state, "project_key": pk,
           "residual_eur": (resp or {}).get("residual_budget_eur"),
           "total_eur": (resp or {}).get("total_budget_eur"),
           "title": (resp or {}).get("release_title") or (resp or {}).get("requirement_title"),
           "reason": (resp or {}).get("reason"),
           "checked_at": time.time(), "session_id": sid}
    _write_state(proj, obj)
    return obj


def _empty_state(proj, sid):
    """Nessun progetto dichiarato (isp.project_id vuoto) -> stato bloccante: va selezionato un progetto."""
    obj = {"state": "empty", "project_key": "", "residual_eur": None,
           "reason": None, "checked_at": time.time(), "session_id": sid}
    _write_state(proj, obj)
    return obj


def _stale(st, pk, sid):
    """True if the cached outcome must be refreshed via the API: missing, different project_key,
    different session, or older than the TTL."""
    if not st or st.get("state") is None:
        return True
    if st.get("project_key") != pk or st.get("session_id") != sid:
        return True
    try:
        return (time.time() - float(st.get("checked_at") or 0)) >= _ttl()
    except Exception:
        return True


def _warn_for(st):
    state = st.get("state")
    pk = st.get("project_key") or "?"
    if state == "empty":
        h.system_message(h.box("No ISP project selected",
                               ["Pick a valid project from the list (set-vertex-project).",
                                "Claude will be BLOCKED until you select one."]))
    elif state == "mismatch":
        h.system_message(h.box("ISP project not recognized: %s" % pk,
                               ["The server returned a project different from the declared one.",
                                "Telemetry would be wrong — Claude BLOCKED on every request."] + REMEDY))
    elif state == "unknown":
        h.system_message(h.box("ISP project does not exist: %s" % pk,
                               ["Claude will be BLOCKED on every request."] + REMEDY))
    elif state == "invalid":
        h.system_message(h.box("ISP project rejected by the API: %s" % pk,
                               [(st.get("reason") or "Project not enabled / budget exhausted") +
                                " — Claude BLOCKED on every request."] + REMEDY))
    elif state == "denied":
        h.system_message(h.box("Access to the project API denied",
                               ["Authorization denied (user or project not enabled).",
                                "Claude will be BLOCKED on every request."] + REMEDY))
    elif state == "unreachable":
        h.system_message(h.box("Cannot verify the declared ISP project",
                               ["Service not reachable — the declared project is kept (session allowed, warning).",
                                "Project: %s" % pk]))


def main():
    d = h.read_stdin_json()
    base = chap0_auth.get_api_base_url()   # CHAP0_API_BASE_URL > gateway file[version.json env] > None
    if not base:
        return                                   # feature off (not yet wired) -> no-op
    proj = h.project_root(d)
    sid = d.get("session_id") or ""
    event = d.get("hook_event_name") or "SessionStart"
    pk = _isp_project(proj)

    if not pk:
        st = _empty_state(proj, sid)                    # nessun progetto dichiarato -> stato bloccante
    elif event == "SessionStart":
        st = _validate_and_store(base, proj, pk, sid)   # validazione iniziale (feedback immediato in status line)
    else:                                               # UserPromptSubmit
        st = _read_state(proj)
        if _stale(st, pk, sid):
            st = _validate_and_store(base, proj, pk, sid)   # ri-validazione throttled (prima volta / oraria / cambiato)

    if event == "SessionStart":
        _warn_for(st)                                   # SessionStart puo' solo avvisare
    elif st.get("state") in BLOCK_STATES:               # UserPromptSubmit -> enforce
        if st.get("state") == "empty":
            h.halt_turn(h.box("No ISP project selected — Claude blocked",
                              ["Pick a valid project from the list with set-vertex-project,",
                               "then restart Claude Code."]))
        elif st.get("state") == "mismatch":
            h.halt_turn(h.box("ISP project not recognized: %s — Claude blocked" % (st.get("project_key") or "?"),
                              ["The server returned a project different from the declared one.",
                               "Telemetry would be wrong."] + REMEDY))
        elif st.get("state") == "denied":
            h.halt_turn(h.box("Access to the project API denied — Claude blocked",
                              ["Authorization denied (user or project not enabled)."] + REMEDY))
        else:
            why = "does not exist" if st.get("state") == "unknown" else "rejected by the API (not enabled / budget)"
            h.halt_turn(h.box("ISP project %s: %s — Claude blocked" % (why, st.get("project_key") or "?"),
                              REMEDY))


if __name__ == "__main__":
    h.run_guard(main, "project-vidima")
