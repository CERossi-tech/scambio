"""vpn-guard hook — detect the ISP 'VPN ISPers' (Ivanti/Pulse Secure) tunnel; report + halt.

Registered on TWO events:
  SessionStart     -> detect + report SIEM/audit; if off-VPN, WARN (cannot hard-block:
                      a SessionStart exit 2 only warns, the session still starts).
  UserPromptSubmit -> ENFORCE: if off-VPN, {continue:false} halts the turn BEFORE the model
                      runs (no egress). This is the real block: every prompt is halted off-VPN.

Detection combines TWO independent signals, OR'd together (either one finding a match is enough):
  ip   -> config-driven (vpnGate.tunnelSubnets/dnsSuffix in egress-domains.json): runs
          `ipconfig /all` (Windows) / `ifconfig` (macOS) and looks for ANY IPv4 in tunnelSubnets,
          or the dnsSuffix string anywhere in the output. Matching raw text (not localized labels)
          survives non-English Windows.
  ivnt -> native OS signal from the Ivanti/Pulse client itself: `scutil --nc list` '(Connected)'
          profile (macOS) / `Get-NetAdapter` Juniper adapter Status=Up (Windows). The client
          process (ps -ax / Get-Process: pulse|ivanti|dsAccess) is checked only as accessory
          context for audit - a running process alone, without the adapter/profile reporting
          connected, is NEVER sufficient to report 'up'.
'down' only if NEITHER signal finds a match. ~/.claude/.vpn-state (display-only cache for the
status line) stores both signals plus the combined result as JSON: {"ip":, "ivnt":, "state":}.

States (per signal and combined): up (match) | down (enumerated, no match) | inconclusive
(command missing/error/timeout). fail-mode (vpnGate.failMode): 'open' (default) -> inconclusive
allows (+audit); 'closed' -> inconclusive treated as down. Unhandled hook-internal errors stay
fail-CLOSED via run_guard.

DEFENSE-IN-DEPTH, not enforcement: no signal here is bypass-proof. Bypassable with --bare where
it skips the managed hooks (seen on Windows 2.1.197; on macOS 2.1.285 they still fired), by an
admin spoofing the tunnel IP, or by an admin faking the native client status. Hard enforcement =
egress proxy / OS app-control.
Test seams (never env vars, config/test-overrides.json only): CLAUDE_TEST_VPN=up|down|inconclusive
(forces the combined result, both signals skipped) and CLAUDE_TEST_IVNT=up|down|inconclusive
(forces only the native signal; the ip signal still runs).
"""
import ipaddress
import json
import os
import re
import subprocess
import sys
import isp_hooks as h

REMEDY_LINES = ["Connect to the VPN ISPers (Ivanti/Pulse Secure) and restart Claude Code.",
                "No 10.244.x tunnel address nor sede.corp.sanpaoloimi.com DNS suffix detected."]

_IPV4_RE = re.compile(r"\b\d{1,3}(?:\.\d{1,3}){3}\b")


def _net_output():
    """Raw ipconfig/ifconfig output. Raises on failure (-> inconclusive)."""
    # absolute paths: never resolved on PATH / cwd (a fake ifconfig would fake "VPN up")
    cmd = [h.system_tool_path("ipconfig"), "/all"] if h.IS_WIN else [h.system_tool_path("ifconfig")]
    out = subprocess.run(cmd, capture_output=True, text=True,
                         encoding="utf-8", errors="replace", timeout=4)
    if out.returncode != 0 or not (out.stdout or "").strip():
        raise RuntimeError("%s returned nothing (rc=%d)" % (cmd[0], out.returncode))
    return out.stdout


def _detect_ip_state(cfg):
    """IP/DNS tunnel-match signal (ipconfig/ifconfig): 'up' | 'down' | 'inconclusive'."""
    nets = []
    for s in cfg.get("tunnelSubnets") or []:
        try:
            nets.append(ipaddress.ip_network(s, strict=False))
        except ValueError:
            pass
    suffix = (cfg.get("dnsSuffix") or "").strip().lower()
    if not nets and not suffix:
        return "inconclusive"          # misconfigured gate: nothing to match on

    try:
        text = _net_output()
    except Exception:
        return "inconclusive"

    for ipstr in _IPV4_RE.findall(text):
        try:
            ip = ipaddress.ip_address(ipstr)
        except ValueError:
            continue
        if any(ip in n for n in nets):
            return "up"
    if suffix and suffix in text.lower():
        return "up"
    return "down"


# --- native Ivanti/Pulse client signal (second, independent corroboration of the tunnel; OR-combined
# with the IP/DNS match above). Primary: an OS-reported connected VPN adapter/profile. Accessory: the
# client process (ps -ax / Get-Process) - checked only for audit context, NEVER sufficient by itself
# to report 'up' (a running process without the adapter/profile reporting connected still reports
# 'down'). Defense-in-depth like every other signal here: not bypass-proof.
_IVNT_PROFILE_RE = re.compile(r"vpn\s*ispers|pulse|ivanti", re.I)
_IVNT_PROCESS_RE = re.compile(r"pulse|ivanti|dsaccess", re.I)


def _parse_ivnt_mac(nc_text):
    """'up' if `scutil --nc list` shows an Ivanti/Pulse profile '(Connected)', else 'down'."""
    for line in (nc_text or "").splitlines():
        if "(Connected)" in line and _IVNT_PROFILE_RE.search(line):
            return "up"
    return "down"


def _parse_ivnt_win(adapter_text):
    """'up' if a Juniper adapter is reported Status=Up by Get-NetAdapter, else 'down'.
    `adapter_text` lines are 'InterfaceDescription|Status' (see _ivnt_native_state)."""
    for line in (adapter_text or "").splitlines():
        desc, _, status = line.partition("|")
        if "juniper" in desc.lower() and status.strip().lower() == "up":
            return "up"
    return "down"


def _ivnt_process_present(ps_text):
    """True if a pulse/ivanti/dsAccess process name is found in `ps_text` (ps -ax / Get-Process
    output). Accessory corroboration only - see module note above."""
    return bool(_IVNT_PROCESS_RE.search(ps_text or ""))


def _ivnt_native_state():
    """Native signal from the OS VPN adapter/profile: 'up' | 'down' | 'inconclusive'."""
    try:
        if h.IS_WIN:
            ps = "Get-NetAdapter | ForEach-Object { '{0}|{1}' -f $_.InterfaceDescription, $_.Status }"
            out = subprocess.run([h.system_tool_path("powershell"), "-NoProfile", "-NonInteractive",
                                  "-Command", ps], capture_output=True, text=True, timeout=4,
                                 encoding="utf-8", errors="replace", creationflags=0x08000000)
        else:
            out = subprocess.run([h.system_tool_path("scutil"), "--nc", "list"], capture_output=True,
                                 text=True, encoding="utf-8", errors="replace", timeout=4)
    except Exception:
        return "inconclusive"
    if out.returncode != 0:
        return "inconclusive"
    text = out.stdout or ""
    return _parse_ivnt_win(text) if h.IS_WIN else _parse_ivnt_mac(text)


def detect_ivnt_state():
    """Native Ivanti/Pulse client signal: 'up' | 'down' | 'inconclusive'.
    Test seam: key CLAUDE_TEST_IVNT=up|down|inconclusive in config/test-overrides.json (never real)."""
    forced = h.test_value("CLAUDE_TEST_IVNT")
    if forced in ("up", "down", "inconclusive"):
        return forced
    return _ivnt_native_state()


def _ivnt_process_hint():
    """Accessory-only process corroboration for audit context (never used to decide the state)."""
    try:
        if h.IS_WIN:
            out = subprocess.run([h.system_tool_path("powershell"), "-NoProfile", "-NonInteractive",
                                  "-Command", "Get-Process | Select-Object -ExpandProperty ProcessName"],
                                 capture_output=True, text=True, timeout=4, encoding="utf-8",
                                 errors="replace", creationflags=0x08000000)
        else:
            out = subprocess.run([h.system_tool_path("ps"), "-ax"], capture_output=True, text=True,
                                 timeout=4, encoding="utf-8", errors="replace")
    except Exception:
        return None
    if out.returncode != 0:
        return None
    return _ivnt_process_present(out.stdout or "")


def _combine_vpn_states(ip_state, ivnt_state):
    """OR for 'up' (either signal up); 'down' only if BOTH found no match; else 'inconclusive'."""
    if "up" in (ip_state, ivnt_state):
        return "up"
    if ip_state == "down" and ivnt_state == "down":
        return "down"
    return "inconclusive"


def _detect_breakdown(cfg):
    """(ip_state, ivnt_state, combined_state). CLAUDE_TEST_VPN, when forced, short-circuits all
    three to the same value (kept for backward compatibility: both signals are skipped)."""
    forced = h.test_value("CLAUDE_TEST_VPN")
    if forced in ("up", "down", "inconclusive"):
        return forced, forced, forced
    ip_state = _detect_ip_state(cfg)
    ivnt_state = detect_ivnt_state()
    return ip_state, ivnt_state, _combine_vpn_states(ip_state, ivnt_state)


def detect_state(cfg):
    """Return 'up' | 'down' | 'inconclusive': OR of the IP/DNS tunnel match and the native
    Ivanti/Pulse client signal (detect_ivnt_state) - 'up' if either finds a match, 'down' only if
    neither does."""
    return _detect_breakdown(cfg)[2]


def _write_state(d):
    """Persist the detected state to ~/.claude/.vpn-state (JSON: ip/ivnt/state) so the status line
    can show it cheaply (no native call per refresh). Display-only cache — the gate logic is
    unchanged."""
    p = os.path.join(os.path.expanduser("~"), ".claude", ".vpn-state")
    with open(p, "w", encoding="utf-8") as f:
        json.dump(d, f)


def _report(event, state, ip_state=None, ivnt_state=None):
    """SIEM + local audit (fail-safe). SessionStart: always; UserPromptSubmit: only when
    not 'up' (the interesting event) to avoid per-prompt spam when connected."""
    if event != "SessionStart" and state == "up":
        return
    try:
        uid = h.resolve_userid()
    except Exception:
        uid = "-"
    proc = _ivnt_process_hint()   # accessory-only; never affects `state`, just audit context
    payload = {"event": "vpn_state", "state": state, "ip": ip_state, "ivnt": ivnt_state,
               "user": uid, "hook_event": event}
    if proc is not None:
        payload["ivnt_process"] = proc
    h.log_siem(payload)
    h.audit_log("vpn_state=%s ip=%s ivnt=%s%s user=%s event=%s" % (
        state, ip_state, ivnt_state, ("" if proc is None else " ivnt_process=%s" % proc), uid, event))


def _override_active(proj):
    """True if the launch folder's settings.local.json OTEL carries the tracked override flag
    'vpn-ispers=off'. This is a LOGGED, telemetry-tagged, MANUAL bypass for the experimental phase
    (support hands it out): the same attribute both tags all telemetry and tells this hook to warn
    instead of halt. Removal is manual (driven by the telemetry dashboard). Real egress enforcement
    stays at the proxy (§3.1), so this only relaxes the client-side nag."""
    try:
        path = os.path.join(proj or os.getcwd(), ".claude", "settings.local.json")
        with open(path, encoding="utf-8") as f:
            otel = (json.load(f).get("env") or {}).get("OTEL_RESOURCE_ATTRIBUTES") or ""
    except Exception:
        return False
    for part in otel.split(","):
        k, _, v = part.partition("=")
        if k.strip() == "vpn-ispers" and v.strip().lower() == "off":
            return True
    return False


_PRE = []   # SessionStart: system-command warnings, merged into the (single) systemMessage


def _say(msg):
    h.system_message("\n".join(_PRE + [msg]))
    del _PRE[:]


def main():
    try:
        _main()
    finally:
        if _PRE:                        # nothing else was shown at SessionStart: show the warnings alone
            h.system_message("\n".join(_PRE))


def _main():
    d = h.read_stdin_json()
    event = d.get("hook_event_name") or "SessionStart"
    proj = os.environ.get("CLAUDE_PROJECT_DIR") or d.get("cwd") or os.getcwd()
    # Package upgraded under this running session (isp_hooks.session_pkg_check). Here because vpn-guard
    # runs on every prompt in every package version: an old session keeps the hook list it started with,
    # but runs the CURRENT script from disk. Independent of the VPN gate being enabled.
    stale = h.session_pkg_check(d)
    if stale and event == "UserPromptSubmit":
        h.audit_log("session_pkg_stale user_event=%s" % event)
        h.halt_turn(h.box("⚠  Claude Code package updated - restart Claude", [stale]))   # {continue:false}
    # System commands the controls need (h.system_tool): missing = every prompt blocked; a non-standard
    # root-owned location = warning only. Independent of the VPN gate being enabled.
    tools = h.system_tools_check()
    missing = [m for lv, m in tools if lv == "err"]
    if tools and event == "SessionStart":
        _PRE.append(h.box("⚠  System commands", [m for _lv, m in tools] +
                          (["Claude BLOCKED at the first prompt: the macOS/Windows system install is "
                            "incomplete (contact IT)."] if missing else [])))
    if missing and event == "UserPromptSubmit":
        h.audit_log("system_tools_missing %s" % "; ".join(missing))
        h.halt_turn(h.box("⚠  Required system command missing - turn halted",
                          missing + ["The macOS/Windows system install is incomplete (contact IT)."]))
    cfg = h.load_vpn_gate()
    if not cfg.get("enabled", False):
        sys.exit(0)                    # feature off (or config missing)

    ip_state, ivnt_state, state = _detect_breakdown(cfg)
    try:
        _write_state({"ip": ip_state, "ivnt": ivnt_state, "state": state})   # display-only cache
    except Exception:
        pass
    fail_mode = (cfg.get("failMode") or "open").strip().lower()
    blocked = (fail_mode == "closed") if state == "inconclusive" else (state == "down")

    _report(event, state, ip_state, ivnt_state)

    # Tracked override: if we WOULD block but the launch folder carries 'vpn-ispers=off' in OTEL,
    # WARN instead of halt — and log it loudly (SIEM + audit). The attribute also tags telemetry.
    if blocked and _override_active(proj):
        try:
            uid = h.resolve_userid()
        except Exception:
            uid = "-"
        h.log_siem({"event": "vpn_override", "state": state, "user": uid, "hook_event": event})
        h.audit_log("vpn_override state=%s user=%s event=%s" % (state, uid, event))
        _say(h.box(
            "⚠  VPN ISPers override active (vpn-ispers=off)",
            ["Running WITHOUT VPN enforcement — logged to audit and tagged in telemetry.",
             "Temporary workaround: remove 'vpn-ispers=off' from settings.local.json once the "
             "network/config is fixed."]))
        sys.exit(0)

    if event == "SessionStart":
        # A SessionStart exit 2 does NOT hard-block the session (it only warns); the real
        # enforcement is UserPromptSubmit. Show guidance if off-VPN.
        if blocked:
            _say(h.box("⚠  VPN ISPers not active (state=%s)" % state, REMEDY_LINES))
        sys.exit(0)

    if event == "UserPromptSubmit":
        if blocked:
            h.halt_turn(h.box("⚠  VPN ISPers not active - turn halted (state=%s)" % state, REMEDY_LINES))   # {continue:false}
        sys.exit(0)

    # any other event (e.g. a future PreToolUse registration): exit 2 blocks
    if blocked:
        h.block(h.box("⚠  VPN ISPers not active - tool blocked (state=%s)" % state, REMEDY_LINES))
    sys.exit(0)


if __name__ == "__main__":
    h.run_guard(main, "vpn-guard")
