# Hook scripts — Claude Code Intesa Sanpaolo

Reference implementation of the scripts invoked by `managed-settings.d/50-hooks-{MAC,WINDOWS}.json`. **These are a starting point, not production-hardened code** — they must be reviewed by the Security team, signed and packaged into the install script before fleet deployment.

## Structure — single cross-platform Python set

```
hooks/
├── deps-guard.cmd        NON-Python first gate (Windows, cmd.exe) — python/git/gcloud presence
├── deps-guard.sh         NON-Python first gate (macOS, /bin/sh) — python/git/gcloud presence
├── run-hook.cmd          hook launcher (Windows): interpreter from find-python.cmd, then the hook
├── run-hook.sh           hook launcher (macOS): interpreter from find-python.sh, then the hook
├── find-python.cmd       trusted python/git rule (Windows: under the system roots; ACLs checked in Python)
├── find-python.sh        trusted python3/git rule (macOS: system roots, file + parents root-owned)
└── py/                   ONE Python 3 implementation for macOS AND Windows
    ├── isp_hooks.py      shared module (paths per-OS, decisions, SIEM, PANIC,
    │                     egress allowlist, process-tree for binary-integrity)
    ├── bash-guard.py
    ├── secret-scan.py
    ├── egress-guard.py
    ├── config-integrity.py
    ├── read-guard.py
    ├── write-guard.py
    ├── session-audit.py
    ├── binary-integrity.py
    ├── settings-consistency.py
    ├── check-gcp-token.py
    ├── adc-mirror.py
    ├── vertex-guard.py
    ├── vpn-guard.py
    ├── project-vidima.py
    ├── chap0_auth.py
    ├── prompt-guard.py
    └── audit-log.py
```

**One codebase, both OS.** Same logic, same hook interface (JSON on stdin, exit code +
optional JSON on stdout). OS-specific bits (base paths, PANIC marker, manifest,
process-tree) are isolated in `isp_hooks.py` and selected by `sys.platform`.

Runtime: every Python hook runs through a **launcher** at a fixed path in the package folder —
`run-hook.cmd` (Windows, via `C:\Windows\System32\cmd.exe` by absolute path) / `run-hook.sh`
(macOS, via `/bin/sh`). The launcher picks the interpreter with a **rule, not a list of paths**
(`find-python.cmd` / `find-python.sh`) and runs the hook with **that** interpreter and flags
**`-E -S -B`**: the interpreter that is checked is the one that runs. The hook then re-checks its own
interpreter before any logic (`isp_hooks.interpreter_trusted`, exit 2 if untrusted). **No bash, no jq, no PowerShell.** JSON is parsed natively; output is built with
`json.dumps` (prevents the JSON-injection class of bug).

| Rule (python, git) | Windows | macOS |
|---|---|---|
| System roots | `C:\Program Files\`, `C:\Program Files (x86)\`, `C:\Windows\` | `/usr/`, `/bin/`, `/sbin/`, `/System/`, `/Library/`, `/Applications/` |
| Not modifiable by the user | file + **every parent folder** (AccessCheck on the DACL, nothing written): no write/delete/ACL on the file, no add/delete in its folder, no rename/re-ACL of any parent | file + **every parent folder**: owner root, not other-writable, group-writable only wheel/admin |
| Where it is checked | `find-python.cmd`: location only (cmd cannot evaluate ACLs); full check in Python as soon as the interpreter starts (`interpreter_trusted`; git: `trusted_git`) | `find-python.sh` (`/usr/bin/stat` by absolute path) and again in Python |
| Shims | — | a `/usr/bin` tool may be an xcode-select shim: `DEVELOPER_DIR`/`TOOLCHAINS`/`SDKROOT` are unset first (launchers + `isp_hooks`), and the `xcode-select -p` folder must pass the same rule |
| Version | python >= 3.11 (`deps-guard`) | python >= 3.9 (`deps-guard`) |
| gcloud | presence only (`where.exe` by absolute path) — it runs no guard | presence only (`command -v`) |

Candidates: the usual locations first (discovery hints — `C:\Program Files\Python31x`, Git for Windows;
Xcode CLT / Xcode / `ClaudeCode/python`), then the tool on PATH (absolute entries only); the first one
that passes the rule wins, wherever it sits under the roots. A candidate that fails (user folder, current
directory, WindowsApps alias, Homebrew, an app dragged into `/Applications` by a user) is skipped, never
run. The git hints are mirrored in `isp_hooks._TRUSTED_GIT`; a test keeps them equal. Assumption: the
user is not a local admin (an admin can modify the system folders anyway).

**Why (verified).** Hooks inherit the PATH of the shell that launched Claude Code, and user-writable
dirs come first (on a Windows ISP machine the first PATH entry is `C:\Users\<user>\bin`, which the
user can create; on macOS npm/nvm global bin, `~/.local/bin`, a personal `~/Applications/.../python3`).
A `python3`/`python.exe` placed there would run every hook; an impostor that just exits 0 turns every
guard into a silent allow. On macOS the `/usr/bin/python3` shim follows `DEVELOPER_DIR` and ran a fake
`xcrun` (1.5.2). A real case also showed a personal Python first on PATH with its own `cert.pem` (no ISP
CA): not an attack, but it is the interpreter the 1.5.1 hooks run on. The launcher closes all of these
on both OS, and `deps-guard` applies the same rule (fail-closed).

**Hook name, not path, on Windows.** `run-hook.cmd` receives the hook **name** (`bash-guard`), without
spaces: with `cmd /c`, a second quoted argument makes cmd strip the first and last quote of the line and
the command breaks. The launcher rejects names containing `\`, `/` or `..` and missing hook files
(exit 2). `cmd.exe` is written with backslashes: with forward slashes cmd parses `/Windows`,
`/System32` in its own path as switches (verified: "syntax error").

Interpreter isolation flags (neutralize the Python-specific attack surface):
- **`-E`** — ignore `PYTHON*` env vars (`PYTHONPATH`/`PYTHONSTARTUP`/…) → no module injection via env.
- **`-S`** — don't import `site` → no `.pth`/`sitecustomize` auto-execution and no user-site
  on `sys.path` (the user-writable `%APPDATA%\Python\...` / `~/.local` vector).
- **`-B`** — no `.pyc` writes (no artifacts dropped in the tree; matters on the read-only endpoint).
- **`-I` not used on purpose:** it also strips the script's own directory from `sys.path`, which is
  the (admin-owned) hooks dir we import the shared `isp_hooks` module from. With an **absolute**
  script path `sys.path[0]` is that trusted dir (not the CWD), so `-E -S -B` gives the same
  protection without breaking the sibling import. Script path is absolute (interpreter: by the find-python rule, via the launcher); stdlib only; no
  `subprocess(..., shell=True)`.

## Mapping script → hook (50-hooks-{MAC,WINDOWS}.json)

| Event + matcher | Script invoked | What it does |
|---|---|---|
| `SessionStart` / `UserPromptSubmit` / `PreToolUse(.*)` | `deps-guard.cmd` (win) / `deps-guard.sh` (mac) | **NON-Python first gate.** Runs on `cmd.exe`/`/bin/sh` (always present, so it fires even if Python is gone) and verifies the prerequisite tooling: the hooks' interpreter and `git` with the **same rule** as the launcher (`find-python.{cmd,sh}`: system roots, never the current directory or a user folder on PATH) — python **>= 3.11** on win, **>= 3.9** on mac, checked under `-E -S` — plus `gcloud` presence. **Fail-closed:** any missing → exit 2 blocks ALL tool use (message-only on SessionStart). Guarantees the whole ISP Python safety layer can run |
| `PreToolUse(Read)` | `read-guard.py` | **Confines the `Read` tool to the project root** (sandbox emulation, anchored to `workspace.project_dir`/`CLAUDE_PROJECT_DIR`, stable across `cd`) + a small allowlist (`~/.gitconfig`, `~/.claude`). exit 2 = block |
| `PreToolUse(Bash)` | `bash-guard.py` | Blocks destructive/escape patterns (rm -rf, pipe-to-shell, netcat, fork bomb, etc.), the curl/wget egress allowlist, and `cd`/`pushd` escape outside the project root |
| `PreToolUse(Bash)` | `secret-scan.py` | Only on `git commit`: scans the staged diff, blocks on detected secrets/PII. `Bash(git push:*)` is a total deny in `30-permissions.json` → the hook does not fire on push (the regex matches only `git commit`) |
| `PreToolUse(mcp__.*\|WebFetch)` | `egress-guard.py` | Fourth line of anti-MCP defense (defense-in-depth on top of managed lockdown) + WebFetch domain allowlist: parses `tool_input.url`, checks hostname against `config/egress-domains.json` (same 16-host list as bash-guard); non-allowlisted hosts denied. WebSearch has no URL to filter → passes through; `permissions.ask` prompt still fires. WebFetch/WebSearch are in `permissions.ask` of `30-permissions.json` |
| `PreToolUse(Edit\|Write)` | `write-guard.py` | **Confines writes to the project root** (sandbox emulation): any `tool_input.file_path` escaping `workspace.project_dir`/`CLAUDE_PROJECT_DIR` → exit 2 block. Runs before `config-integrity` |
| `PreToolUse(Edit\|Write)` | `config-integrity.py` | Gate on protected file classes (CI/CD, IaC, lockfile, security, etc.). Decision by repo risk class |
| `PostToolUse(Write\|Edit)` | `secret-scan.py` | Double scan of the freshly written file: (a) secret/credential patterns (AWS/JWT/PEM/PAN-Luhn/GCP/token prefixes) → warn "remove before committing"; (b) destructive-intent patterns in script content (defense-in-depth: `os.system("rm -rf")`, `subprocess.run(["chmod 777"])`, `eval(base64.b64decode(...))`, `IEX` of a base64-decoded blob, fork bomb, pipe-to-shell, archive piped to outbound, etc.) → warn "script contains literal destructive/exfil commands; review required before execution". Both scans: WARN only (no block), with separate SIEM logs typed `secret_in_write` / `destructive_intent_in_write` |
| `SessionStart(startup\|resume)` / `UserPromptSubmit` | `binary-integrity.py` | Verifies the running `claude` binary against the admin-owned `manifest.json` (path + SHA256). Path or SHA mismatch = exit 2. SessionStart: manifest missing / binary not resolvable = warning only. UserPromptSubmit: re-check throttled to 60 s (`.claude/.binary-integrity-state`, own file: hooks run in parallel); a failed check blocks the prompt; a `checked_at` in the future or malformed forces a re-check. Partially compensates the OS-level enforcement (WDAC/AppLocker/Gatekeeper). |
| `SessionStart(startup\|resume)` / `UserPromptSubmit` | `settings-consistency.py` | **Fail-closed** check of `OTEL_RESOURCE_ATTRIBUTES` in `.claude/settings.local.json` against this machine: `developer.id` = matricola (`resolve_userid`), `host.name` = OS hostname, `os.type` = `windows` / `darwin` (or `macos`), `gcp.project_id` = `ANTHROPIC_VERTEX_PROJECT_ID`. Missing/invalid file, missing keys or an unresolvable matricola = violation. SessionStart: warning; UserPromptSubmit: blocks the prompt (vertex-guard does not run there). Throttled to 60 s (`.claude/.settings-consistency-state`). |
| `SessionStart(startup\|resume)` | `session-audit.py` | Session identity log + AUP banner |
| `SessionStart(startup\|resume)` / `UserPromptSubmit` | `check-gcp-token.py` | **Async**, throttled via a status cache (short-circuits only a previous OK → a failure re-checks each turn for fast self-heal). Validates the credential **Claude actually uses**: the per-directory ADC copy in `GOOGLE_APPLICATION_CREDENTIALS` (from `settings.local.json`) if set — via `gcloud auth application-default print-access-token` with GAC pointed at it (gcloud honours GAC, verified) — else the global ADC (legacy). **Self-heal:** if the local copy is invalid but the GLOBAL login is valid (e.g. after a bare `gcloud auth application-default login`), it **re-copies** the fresh global ADC into the local copy and re-sets `quota_project_id` = `ANTHROPIC_VERTEX_PROJECT_ID` (same op as set-vertex-project) → the next turn works without a full re-setup. **Identity guard:** the per-dir copy isolates quota/project but NOT the identity (refresh_token is global/shared), so before self-healing it resolves the global ADC identity (email, via the OAuth `tokeninfo` endpoint — the ADC file `account` is empty on current gcloud) and compares it to a baseline (`.claude/gcp/.identity`, learned from the local copy, refreshed ≤6h). If the global identity **differs** → does NOT copy, warns to log in with the right account (blocks importing a wrong identity → silent 403). **Network:** if `tokeninfo` is unreachable the identity is unverifiable → the self-heal still proceeds (fail-open, never strands the dev) with a caveat in the message. If both invalid → `systemMessage` (invalid_rapt: run the login, then it self-heals; or `set-vertex-project`). Never blocks. Writes `{ts, ok}` to the shared status cache. Compensates for `gcpAuthRefresh` removed from managed |
| `SessionStart(startup\|resume)` / `UserPromptSubmit` | `adc-mirror.py` | **Sync**, sola operazione su file (no gcloud/rete, millisecondi). Rispecchia il global ADC nella copia per-directory (`GOOGLE_APPLICATION_CREDENTIALS`) **solo quando il `refresh_token` differisce**, ri-forzando `quota_project_id` = `ANTHROPIC_VERTEX_PROJECT_ID`. Rende sufficiente un semplice `gcloud auth application-default login` per recuperare una login scaduta: il mirror sync atterra **prima** della chiamata Vertex dello stesso turno (l'async `check-gcp-token` perde quella corsa), senza riavvio. L'identità NON è verificata qui (richiederebbe una mint di rete) → l'identity guard resta in `check-gcp-token`. Convenience, non un controllo di sicurezza → **fail-open** (qualsiasi errore → exit 0, non blocca mai). Gira in parallelo agli altri hook del turno → costo wall-clock ~nullo. |
| `SessionStart` / `PreToolUse(.*)` | `vertex-guard.py` | **Gate bloccante** della config Vertex/telemetria **per-directory**. Valida in `<cwd>/.claude/settings.local.json` (file personale, non committato; `cwd` preso dallo stdin dell'hook — OTEL è scrubbed dall'env → si legge il file) **esistenza + formato + coerenza**: `ANTHROPIC_VERTEX_PROJECT_ID` presente; `OTEL_RESOURCE_ATTRIBUTES` con `gcp.project_id` **==** project, `developer.id` **==** utente che avvia Claude (non letterale `${USER}`), e **`isp.project_id`** presente e con formato valido (`PRG#######`, `STRE#######`, `RELE#######`, `OPEX`). **PreToolUse → exit 2** (blocca ogni tool, motivo specifico); **SessionStart** → messaggio. Rimedio: `scripts/set-vertex-project.{cmd,sh}` nella cartella da cui si avvia Claude + riavvio. Nasce dalla rimozione di project/OTEL dal managed (`10-vertex`, `20-telemetry-*`) → config per-directory in `settings.local.json` (il `.gitignore` è responsabilità dell'utente). |
| `SessionStart(startup\|resume\|clear\|compact)` / `UserPromptSubmit` | `vpn-guard.py` | **Package upgraded under a running session** (`isp_hooks.session_pkg_check`, independent of the VPN gate): SessionStart records `session_id → installed version` in `~/.claude/.session-pkg/`; on UserPromptSubmit a session started with another version, or never recorded (started before this check), gets `{continue:false}` with "package updated, restart Claude". Here because vpn-guard runs on every prompt in every package version: an old session keeps the hook list it started with but runs the current script from disk. `clear\|compact` only records the new session after `/clear`. **VPN ISPers gate** (Ivanti/Pulse Secure). Detects the corporate tunnel via TWO independent signals, OR'd together: **ip** — `ipconfig`/`ifconfig` (any IPv4 in `vpnGate.tunnelSubnets` — the official VPN ISPers + Fiders subnets per Confluence 589956840, or the `vpnGate.dnsSuffix` `sede.corp.sanpaoloimi.com` — locale-independent, no admin/sudo; config in `config/egress-domains.json` → `vpnGate`); **ivnt** — native OS signal from the Ivanti/Pulse client itself (`scutil --nc list` `(Connected)` profile on macOS, `Get-NetAdapter` Juniper adapter `Up` on Windows; the client process via `ps -ax`/`Get-Process` is checked only as accessory audit context, never sufficient alone). `down` only if neither signal matches. `~/.claude/.vpn-state` (status-line cache) stores both signals plus the combined result as JSON (`{"ip":, "ivnt":, "state":}`). States (per signal and combined) `up`/`down`/`inconclusive`. **SessionStart** = report SIEM/audit + WARN if off-VPN (cannot hard-block). **UserPromptSubmit** = if off-VPN, `{continue:false}` **halts the turn** before the model runs. `failMode` (`open` default → inconclusive allows + audit; `closed` → treated as down). **Defense-in-depth**, client-side: bypassable with `--bare` where it skips the managed hooks (Windows 2.1.197; on macOS 2.1.285 bash-guard still fired under `--bare`), admin IP-spoof, or admin faking the native client status; hard enforcement = egress proxy (§3.1) / OS app-control. `enabled:false` disables it. **Tracked override (support-only, experimental phase):** an OTEL attribute `vpn-ispers=off` in the launch folder's `settings.local.json` `OTEL_RESOURCE_ATTRIBUTES` downgrades block→warn (the dev keeps working) and is **logged** (SIEM/audit `vpn_override`) **and tagged in telemetry** (Claude reads `OTEL_RESOURCE_ATTRIBUTES` at startup) → dashboards show who is bypassing. `set-vertex-project` preserves the attribute; removal is manual, driven by the dashboard. Not documented dev-facing. |
| `SessionStart` / `UserPromptSubmit` | `project-vidima.py` | **Capitalizzazione token (CHAP0)** — valida il progetto ISP scelto (`isp.project_id`, scritto da `set-vertex-project` nell'OTEL var) contro il microservizio (`POST /v1/projects/validate`, header `X-User-Id`). **SessionStart** valida 1 volta e scrive l'esito in `<proj>/.claude/.vidima-state`; **UserPromptSubmit** ri-valida **solo se stale** (prima volta + ogni ora, valore fisso) e con `{continue:false}` **blocca** negli stati `BLOCK_STATES`: `invalid` (non abilitato / budget esaurito), `unknown` (progetto inesistente, 404), `empty` (nessun progetto), `mismatch` (il server risponde per un progetto diverso da quello dichiarato), `denied` (401/403/altri 4xx o credenziale rifiutata). Solo `unreachable` (servizio giù, 5xx/429, rete, timeout) → **warning, nessun blocco** (fail-open). La status line legge `.vidima-state` e colora `isp.prj` verde (vidimato) / rosso (unknown) + residuo €. **Opt-in** via `api_base_url` di `chap0-gateway.json` (no-op se assente). Il **Bearer è sempre richiesto e inviato** (coniato/cachato/rinnovato da `chap0_auth`, OAuth2 client_credentials, CLAUDECODE-58); se il token non si ottiene la chiamata **non parte** → `unreachable` → resta il progetto dichiarato. Client-side defense-in-depth: dentro il TTL lo stato è cache-file (falsificabile) — il controllo vero è server-side (attribuzione `isp.project_id` in telemetria). |
| `UserPromptSubmit` | `prompt-guard.py` | Blocks prompts containing pasted credentials |
| `ConfigChange` | `audit-log.py` | Async audit of every live settings change: syslog on macOS via `logger`, file fallback on Windows/no-logger (`CLAUDE_AUDIT_LOG` or `%ProgramData%\ClaudeCode\audit.log`, collected by the SIEM agent). Wired into both `50-hooks` variants |

## Deploy paths on the endpoint

The install script (deploy tool) must copy the scripts to the paths expected by `50-hooks-{MAC,WINDOWS}.json`:

| OS | Deploy path | Owner | Permissions |
|---|---|---|---|
| macOS | `/Library/Application Support/ClaudeCode/hooks/py/<script>.py` | `root:wheel` | `0644` files / `0755` dir (read+execute for Users, write only root — developer CANNOT modify them) |
| Windows | `C:\Program Files\ClaudeCode\hooks\py\<script>.py` | `SYSTEM\|Administrators` | NTFS read+execute for Users; write only SYSTEM/Admins (developer CANNOT modify them). Inheritance disabled to prevent overrides from parent ACL |

**Two-file + rename-at-deploy convention.** The repo keeps two variants of the hooks file to avoid the array concatenation behavior of the drop-in directory (which does not allow a clean override of the `command` paths between files):

- `managed-settings.d/50-hooks-MAC.json` — macOS: exec form `/bin/sh` + args `["/Library/Application Support/ClaudeCode/hooks/run-hook.sh", "<hook>"]`
- `managed-settings.d/50-hooks-WINDOWS.json` — Windows: exec form `C:\Windows\System32\cmd.exe` + args `["/d", "/c", "C:/Program Files/ClaudeCode/hooks/run-hook.cmd", "<hook>"]` (`/d` = skip the user-writable `AutoRun` of `cmd.exe`)

  The two files differ in the launcher (`run-hook.sh` via `/bin/sh` vs `run-hook.cmd` via `cmd.exe`),
  the absolute path prefix (Application Support vs Program Files) and the deps-guard shell
  (`/bin/sh` + `.sh` vs `cmd.exe` + `.cmd`). No interpreter is named in either file.

Both use **exec form** (interpreter + args array), so the space in "Application
Support"/"Program Files" needs no quoting.

The install script **deploys a single file**, renaming it to `50-hooks.json` on the endpoint:

```
On macOS:   cp 50-hooks-MAC.json     → <managed-settings.d>/50-hooks.json
On Windows: cp 50-hooks-WINDOWS.json → <managed-settings.d>\50-hooks.json
```

The two variants must be kept in logical sync (same event list, same matchers, same timeouts, same async flags) on every modification.

## Runtime dependencies — a single one: Python

All hooks run on one interpreter, picked by the launcher with the find-python rule (macOS: Xcode CLT /
Xcode `python3`; Windows: `C:\Program Files\Python31x`) — **stdlib only** (Python 3.9+ on macOS,
3.11+ on Windows, enforced by deps-guard). No
third-party packages, **no jq, no bash, no PowerShell**. External tools invoked
via `subprocess` only where unavoidable:

| Tool | Used by | Notes |
|---|---|---|
| `git` | `secret-scan` (commit gate) | `isp_hooks.trusted_git()`: same rule as the interpreter (system root, file + parents not user-modifiable); none trusted → the commit is blocked |
| `gcloud` | `check-gcp-token` (ADC verify) | Vertex/OTLP auth prerequisite |
| `ps` / `lsof` (mac) · Win32 API via `ctypes` (win) | `binary-integrity` (process-tree walk) | OS built-ins; no external dep |
| `logger` (mac) | `audit-log` | best-effort; file fallback otherwise |

SHA256 uses `hashlib`; SIEM POST uses `urllib`; JSON is native — no `jq` or
PowerShell cmdlet dependency.

## Environment variables and test overrides

The hooks inherit the environment of `claude`, so **any variable they read can be set by the user**
(`CLAUDE_TEST_VPN=up claude`) and must not steer a control. The hooks read **only** these:

| Var | Read by | Purpose |
|---|---|---|
| `CLAUDE_PROJECT_DIR` | several | Set by Claude Code: the launch folder. |
| `APPDATA` / `ProgramData` / `CLOUDSDK_CONFIG` | GCP helpers, audit default | OS / gcloud locations. |

Fixed values (no longer read from env vars, see SWE-2596): audit log path (`%ProgramData%\ClaudeCode\audit.log` /
`/var/log/claude-code-audit.log`) and 5 MB cap, CHAP0 gateway file (`config/chap0-gateway.json`) and token cache
(`~/.claude/chap0-token-cache.json`), CHAP0 service URL and OAuth config (only from the `chap0-gateway.json` section
chosen by `version.json "env"`), SIEM webhook (`config/siem.json` `{"hook_url": "https://..."}`, admin-owned; missing file = SIEM off; never from `BANK_SIEM_HOOK_URL`), vidima TTL 1 h, CHAP0 timeout 4 s, token margin 30 s, egress allowlist
(`config/egress-domains.json`), `version.json`, ADC paths.

**Test overrides** (`CLAUDE_TEST_VPN`, `CLAUDE_TEST_IVNT`, `CHAP0_TEST_VALIDATE`, `CHAP0_HOOK_TEST_MINT`, `CHAP0_API_BASE_URL`,
`CHAP0_HOOK_GATEWAY_FILE`, `CHAP0_HOOK_OAUTH_URL`/`_CLIENT_ID`/`_CLIENT_SECRET`/`_SCOPE`, `CHAP0_HOOK_TOKEN_CACHE_PATH`,
`CLAUDE_EGRESS_ALLOWLIST`, `CLAUDE_AUDIT_LOG`, `CLAUDE_VERSION_FILE`, `CLAUDE_ADC_FILE`, `CLAUDE_GLOBAL_ADC`,
`CLAUDE_GCP_STATUS_CACHE`, `CLAUDE_TEST_GCP[_FAIL]`, `CLAUDE_TEST_PANIC_FILE`, `CLAUDE_TEST_STALE_SESSIONS`,
`CLAUDE_TEST_SESSION_PKG_DIR`) are keys of
**`config/test-overrides.json`** of the package itself (`isp_hooks.test_value`), never env vars. Installed, that folder
is admin/root-only, so a user cannot create the file; in the repo `tests/py/run_all.py` writes
`install/config/test-overrides.json` (gitignored, deleted at the end, never copied by `build-release.sh`).
**System commands** (`isp_hooks.system_tool`: `ifconfig`/`ipconfig`, `ps`, `lsof`, `app-sso`, `klist`, `logger`,
`powershell`, `scutil`, `security`, `tasklist`) are never run by name and no path is hardcoded: looked up on PATH
(absolute entries only, never the current directory), the first match runs by its absolute path, and only if it
is admin-owned (`is_system_path`, same rule as python/git): under a system root (`C:\Program Files[ (x86)]`,
`C:\Windows`; `/usr`, `/bin`, `/sbin`, `/System`, `/Library`, `/Applications`) AND not modifiable by the user
(Windows: AccessCheck of the user's token on the file and its folder, nothing written; macOS: root-owned file and
parent folders, group-writable only for wheel/admin). Not found / not admin-owned: vpn-guard halts every prompt for
`ifconfig`/`ps`/`lsof` (Windows `ipconfig`), with a warning at SessionStart; the others make their feature behave
as if the command failed. The doctor (section 2) and `set-vertex-project` list them.

`set-vertex-project-doctor` reports an error if it finds the file on an installed machine, and the hooks never read it
when they run from the installed package (`BASE_DIR`), whatever the folder permissions. With the file present (test
runs) the SIEM is always off. `deps-guard.{cmd,sh}` read no environment variable at all.
`CHAP0_HOOK_CLIENT_SECRET` and `CHAP0_ENV` are **build-time** only (`tools/build-release.sh`).

## Patterns covered

`secret-scan.py` runs **2 distinct scans** on the file content (PostToolUse Write/Edit) and on the staged diff (PreToolUse Bash git commit):

**Scan 1 — secrets/credentials + PAN** (unique high-signal patterns): AWS, JWT, PEM, Luhn-checked PAN, Google API/OAuth, GitHub/GitLab/Slack tokens, etc., plus three GCP patterns common in the ISP Vertex environment:

- `"type": "service_account"` (inline JSON marker of an SA key file)
- `*@*.iam.gserviceaccount.com` (GCP service account email — catches even without the full JSON)
- `1//0...` (GCP OAuth refresh token, distinct format from the `ya29.*` access token)

**Scan 2 — destructive-intent in script content** (defense-in-depth for the gap "interpreted-language content not inspected by bash-guard"). Catches the commodity case (Claude/attacker writes a script with a literal destructive command). It does NOT catch sophisticated encoded/obfuscated payloads — those are delegated to the ISP sandbox/proxy/SIEM. **WARN only** (PostToolUse cannot block, it runs after the fact). 17 patterns covered:

- **Python** (6): `os.system(...rm -rf|chmod 777|/etc/passwd|/dev/tcp|mkfs|dd if=...)`, `subprocess.{run,Popen,call,...}(...rm|chmod 777|mkfs|dd|nc|ncat...)`, `eval(base64.b64decode(...))`, `__import__('os').system`, `pty.spawn('/bin/{sh,bash}')`, `exec(open(...))`
- **Node.js** (3): `child_process.{exec,execSync,spawn,spawnSync}(...rm|chmod 777|nc|sh -c|bash -c...)`, `eval(atob(...))`, `Buffer.from(..., 'base64').toString() + eval` (obfuscation chain)
- **PowerShell** (3): `Remove-Item -Recurse -Force (C:\|$env:USERPROFILE|/|~)`, Invoke-Expression of a base64-decoded blob, disable AV real-time monitoring / Stop-Service Defender / turn off the host firewall
- **Bash script content** (5): `^rm -rf (/|~|/*|$HOME)`, fork bomb pattern, `(curl|wget) | (sh|bash)`, `(tar|zip|gzip|base64) | (curl|wget|nc|ncat)` (archive exfil), `>/dev/tcp/.../`

Limit: regex match on literal strings. An attacker who encodes/obfuscates bypasses the scan. Cyber-aligned: §5.2 "Sandbox != containment of intent" — this is cheap defense-in-depth (reuses the existing hook, zero deployment cost), not a boundary against sophisticated malicious intent. The real boundary is network egress (#40 ISP proxy) + OS-level sandbox + SIEM behavioral telemetry.

`bash-guard.py` — on top of the baseline patterns (rm -rf, fork bomb, pipe-to-shell, netcat exfil, history tampering, archive piped to outbound, etc.) decode-and-execute patterns have been added to reduce the surface for payload obfuscation:

- mac: `base64 -d|-D|--decode` piped into `sh`/`bash`/`eval` (BSD/GNU coreutils)
- win: base64-decoded blob piped to `iex` + `iex (iwr ...)` + .NET web-client download piped to `iex` (classic PowerShell download-and-execute patterns)

**Shell-write into guardrail config → ask.** `config-integrity` only fires on the Edit/Write tools; a shell redirect / in-place edit bypasses it (`echo '{"risk":"low"}' > .claude/risk-class.json`, `sed -i CLAUDE.md`, `tee .github/workflows/x`, `Set-Content` on Windows). `bash-guard` detects these when the **target** is one of the guardrail-config classes (`.claude/`, `CLAUDE.md`, `.mcp.json`, `.github/workflows/`, `.git/hooks/`, `.husky/`, `risk-class.json`) and emits `permissionDecision: ask` (human confirms — symmetrical with config-integrity at medium risk). Scoped to that set to stay low-FP (writing `pom.xml`, `requirements.txt`, `*.sql` via shell is NOT flagged); target must be in the same command segment as the operator, so `cat .claude/x > /tmp/y` (reads, writes elsewhere) is not flagged. Imperfect by design (cannot resolve `$VARS`/encodings) — defense in depth.

**curl/wget block, with a GET-only internal exception (cyber baseline §5 + §6.1).** `bash-guard.py` blocks `curl`/`wget` from Bash unconditionally — they cannot authenticate to the corporate proxy from Bash, unlike WebFetch (`webfetch-proxy.py` handles that) — **except** a plain `GET` request whose every `http(s)://` URL resolves to an ISP-internal host:

1. **Word-boundary detection** of the `curl` or `wget` command (no false positives on `curlfile.txt`)
2. **Extract every `http(s)://` URL** on the command line and its hostname (`urlparse`, case-insensitive match)
3. **Match hostname** against `egressAllowlist.internalHosts` in `egress-domains.json` (mac: `/Library/Application Support/ClaudeCode/config/`, win: `C:\Program Files\ClaudeCode\config\`; NOT `managed-settings.d/` — kept out of the settings dir so its non-schema keys raise no startup warning) — a narrower list than `allowedHosts` (WebFetch's list), currently the same ISP-internal domain patterns (`*.intesasanpaolo.com`, `*.sanpaolo.com`, `*.sanpaoloimi.com`, `*.ubibanca.com`, `*.previmedical.priv`)
4. **Non-GET / body / upload detection disqualifies the exception regardless of destination**: curl `-X`/`--request` **or** wget `--method` = POST/PUT/PATCH/DELETE; inline body `-d`/`--data*`/`--body-data`/`--post-data`; file upload `-T`/`--upload-file`/`--post-file`/`--body-file`; any `-F`/`--form`
5. **Fail-closed**: no URL extractable (e.g. a shell variable), any URL resolving outside `internalHosts`, or a non-GET indicator anywhere on the line → `exit 2` block, same message as the unconditional case

This is a defense-in-depth layer (NOT hard containment — the real egress boundary is the corporate proxy #40 + OS sandbox #45), narrower in scope than WebFetch's `allowedHosts`/`deniedHosts` path (`egress-guard.py`, unaffected by this exception).

**Procedure to add a new approved domain**:
1. PR on the file `install/config/egress-domains.json`: add the host to `egressAllowlist.allowedHosts` with a comment on the use case
2. Cyber review (verify: no fronting risk, minimum required scope, alternative if any)
3. Merge + commit
4. The install script redistributes the updated file on the next fleet deploy
5. The hook reloads on the next invocation (no Claude restart required, every Bash invocation re-reads the file)

**Accepted and documented limit**: payloads encoded with alternative encodings (hex, gzip, custom) still bypass static analysis — consistent with `cyber_docs/claude-code-enterprise-hardening-eu-bank.md` §5.2 *"Sandbox != containment of intent"*. Behavioral detection is delegated to the SIEM. Plus domain fronting on allowlisted hosts (e.g. `github.com` as C2) is accepted by the cyber baseline itself — long-term mitigation = MITM proxy with ISP CA (out of scope for managed).

**Signature verification of hooks at SessionStart**: **discarded** after threat-model evaluation — the ACL on `C:\Program Files\ClaudeCode\` (Win) / `/Library/Application Support/ClaudeCode/` (mac) + admin segregation (Workspace IT as sole installer) already closes the main vector. To be reconsidered if the admin/developer model changes.

**Binary integrity verification at SessionStart** (hook `binary-integrity.py`): **detect + alert** (SessionStart cannot block - Anthropic docs; the SIEM event is the product) of the running `claude` binary against the `manifest.json` distributed by Anthropic (admin path + SHA256). Addresses the risk "developer runs `npm install -g @anthropic-ai/claude-code` or `brew install claude-code` and creates an alternative user-space binary that still inherits managed-settings but may be a different/older/CVE-affected version or a modified build that skips hooks". Accepted limit: the hook runs INSIDE the claude process — a genuinely malicious custom build can ignore hooks, so this is detection + deterrent, not true OS-level enforcement. True enforcement = OS-level app control (WDAC/AppLocker on Win, Gatekeeper + code signing on mac), to be deployed by Endpoint Eng. The hook fails-open on its internal errors (manifest missing, parent process not resolvable) to avoid fleet-wide block if buggy.

## Behavior conventions

| Hook event | Exit code | Effect |
|---|---|---|
| `PreToolUse` | `0` | Lets it proceed (optionally with `permissionDecision: "ask"` on stdout) |
| `PreToolUse` | `2` | **Blocks** the tool execution. stderr reaches the model as the reason |
| `PostToolUse` | any | The action has already happened — use for warn/log, never expect to block |
| `SessionStart` | `0` | stdout = additional context injected as a system message to the model |
| `UserPromptSubmit` | `2` | **Blocks** the prompt submission. stderr to the developer |
| `ConfigChange` | `0` (async) | Log only, never blocks |

## PANIC marker file (emergency containment)

The `bash-guard.py` and `config-integrity.py` hooks check on startup whether a marker file exists. If so, immediate exit 2 → Claude blocks the tool call. Hooks are spawned on every invocation → this bites even live sessions without a restart.

| OS | PANIC path | Created by | How |
|---|---|---|---|
| macOS | `/Library/Application Support/ClaudeCode/hooks/PANIC` | Workplace IT with admin rights | install script: `touch "/Library/Application Support/ClaudeCode/hooks/PANIC"` |
| Windows | `C:\Program Files\ClaudeCode\hooks\PANIC` | Workplace IT with admin rights | install script: `New-Item -ItemType File "C:\Program Files\ClaudeCode\hooks\PANIC"` |

**Disable:** remove the file (`rm` on mac / `Remove-Item` on win) via the same install tool mechanism. No session restart required, the next tool call passes normally.

**Full procedure** (T+0 → T+60 sequence, authorizations, quarterly tabletop test): see `readme.md` §5.6 "Operational kill-switch procedure (PANIC marker file)".

## File `.claude/risk-class.json` (for `config-integrity`)

The `config-integrity.py` script reads the repo risk class to decide whether to block (`high`) or just ask (`medium`/`low`) on protected file classes. Expected schema in the repo:

```json
{
  "risk": "high"
}
```

Allowed values: `"high"`, `"medium"` (default), `"low"`. If the file does not exist, the hook assumes `medium`. Authoring this file is the responsibility of the repo owner team (part of the AI-BOM, see readme §5.2).

## Local testing

Each script can be invoked manually for testing (bare `python3` on macOS, `python` on Windows, resolved on PATH — fine for a manual run; the managed hooks go through `run-hook.{cmd,sh}`, which takes the interpreter from the allowlist and passes `-E -S -B`). Examples (macOS):

```bash
# Bash guard — must block rm -rf /
echo '{"tool_input":{"command":"rm -rf /"}}' | python3 ./hooks/py/bash-guard.py
echo "exit: $?"  # expected: 2

# Secret scan — PostToolUse warn on AWS key
echo '{"hook_event_name":"PostToolUse","tool_name":"Write","tool_input":{"file_path":"/tmp/x","content":"AKIAIOSFODNN7EXAMPLE"}}' | python ./hooks/py/secret-scan.py
# expected: stdout = JSON with additionalContext warning

# Egress guard — must block WebFetch on an external domain
echo '{"tool_name":"WebFetch","tool_input":{"url":"https://example.com/data"}}' | python3 ./hooks/py/egress-guard.py
# expected: stdout = JSON permissionDecision=deny
```

On Windows use `python` instead of `python3` (resolved on PATH under Git Bash / `cmd.exe`); the deps-guard first gate is the only shell script (`deps-guard.cmd`).

## TODO before deployment

- [ ] Code review by Security: regex coverage, edge cases, output sanitization
- [x] **Hook interpreter from an allowlist on both OS** — `run-hook.{cmd,sh}` + `find-python.{cmd,sh}`; `deps-guard` and `secret-scan` (git) use the same allowlist. Verified on Windows (run_all + exec-form spawn from Node in a path with spaces); **to verify on a real Mac** and in a real Claude Code session after deploy.
- [ ] **Confirm the Windows Python install path with Endpoint Eng** (`C:\Program Files\Python31x` today): a different MDM path = one more line in `find-python.cmd`.
- [x] **Other launchers on the same allowlist** (`set-vertex-project`, its doctor, `gcloud-reauth`, `statusline`, `get`/`get.cmd`): no package script runs python/python3 from PATH any more (real case that triggered it: a personal Python with its own `cert.pem` without the ISP CA → "service not reachable"). The doctor alone falls back to PATH with a warning, to stay diagnosable.
- [x] **PII scoping decided**: the hooks scan **secrets/credentials** (unique high-signal prefixes → near-zero FP) **+ PAN** (Luhn-validated, PCI-DSS driven). General personal/sensitive data (IBAN, codice fiscale, names, addresses, customer IDs, … dozens of types) is **intentionally NOT** enumerated: a regex hook can never cover them all and a handful gives false DLP confidence. Customer-data protection = **data-minimization governance** (no real customer data on dev machines / in prompts) + a **DLP engine** at the egress/telemetry layer.
- [ ] Decide on an ignore mechanism for false positives (e.g. `.gitleaksignore` recognized by `secret-scan`)
- [ ] Define the actual SIEM webhook URL with the SOC (`config/siem.json`, deployed by the install script)
- [ ] Define the SIEM payload (currently an ad-hoc schema — align to CEF/LEEF/JSON if the SOC has a standard)
- [ ] AUP banner in `session-audit.*`: final text from Legal + Communications
- [ ] Install packaging (OS-specific package (.pkg macOS + MSI/Win32 Windows))
- [ ] Script signing (Sigstore cosign or GPG for the `.py` hooks + `deps-guard.{cmd,sh}`)
- [ ] Create a dedicated `claude-code-hooks` repository on Bitbucket for versioning + reviews separate from the policy
