rem ==== ISP trusted-tool rule (Windows) - called by run-hook.cmd and deps-guard.cmd ====
rem Sets PY (Python interpreter for the hooks) and GIT to the FIRST candidate that sits under a
rem system root: C:\Program Files\, C:\Program Files (x86)\ or C:\Windows\ (folders a standard user
rem cannot write to). Candidates: the usual locations below first (discovery hints, highest version
rem first), then python.exe/git.exe as found by where.exe; a candidate outside the roots (user folder,
rem current directory, WindowsApps alias) is skipped, never run. This is the location check only:
rem cmd cannot evaluate ACLs, so the full check (file + every parent folder not modifiable by the
rem user) is done in Python as soon as the interpreter starts (isp_hooks.interpreter_trusted; for git
rem isp_hooks.trusted_git). Keep the hints in sync with isp_hooks._TRUSTED_GIT and scripts/get.
rem No setlocal: PY/GIT are set for the caller (`call`).
set "PY="
set "GIT="
for %%P in (
  "C:\Program Files\ClaudeCode\python\python.exe"
  "C:\Program Files\Python314\python.exe"
  "C:\Program Files\Python313\python.exe"
  "C:\Program Files\Python312\python.exe"
  "C:\Program Files\Python311\python.exe"
) do if not defined PY call :fp_try PY "%%~P"
if not defined PY for /f "delims=" %%P in ('C:\Windows\System32\where.exe python.exe 2^>nul') do if not defined PY call :fp_try PY "%%~P"
for %%G in (
  "C:\Program Files\Git\cmd\git.exe"
  "C:\Program Files (x86)\Git\cmd\git.exe"
) do if not defined GIT call :fp_try GIT "%%~G"
if not defined GIT for /f "delims=" %%G in ('C:\Windows\System32\where.exe git.exe 2^>nul') do if not defined GIT call :fp_try GIT "%%~G"
set "_FP="
set "_FR="
exit /b 0

:fp_try
rem %1 = variable to set, %2 = candidate. Set only if the file exists under a system root
rem (%~f2 = full path, ".." resolved: "C:\Program Files\..\Users\x" does not pass).
if not exist "%~2" exit /b 0
set "_FP=%~f2"
call set "_FR=%%_FP:~0,17%%"
if /i "%_FR%"=="C:\Program Files\" set "%~1=%_FP%"& exit /b 0
call set "_FR=%%_FP:~0,23%%"
if /i "%_FR%"=="C:\Program Files (x86)\" set "%~1=%_FP%"& exit /b 0
call set "_FR=%%_FP:~0,11%%"
if /i "%_FR%"=="C:\Windows\" set "%~1=%_FP%"& exit /b 0
exit /b 0
