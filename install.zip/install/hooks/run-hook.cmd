@echo off
setlocal
rem ==== ISP hook launcher (Windows) ====
rem Every Python hook in 50-hooks-WINDOWS.json runs through this script:
rem   C:/Windows/System32/cmd.exe /c "C:/Program Files/ClaudeCode/hooks/run-hook.cmd" <hook-name>
rem It picks the interpreter with the rule in find-python.cmd (under C:\Program Files, C:\Program
rem Files (x86) or C:\Windows; never the current directory or a user folder on PATH) and runs the
rem hook with THAT interpreter in this same process: the interpreter that is checked is the one that
rem runs. The hook then re-checks its own interpreter (file + every parent folder not modifiable by
rem the user, isp_hooks.interpreter_trusted) before doing anything.
rem The hook is passed by NAME, without spaces: with `cmd /c`, a second quoted argument makes
rem cmd strip the first and last quote of the line and the command breaks.
rem FAIL-CLOSED: no trusted interpreter, no/invalid name or missing hook file -> exit 2 (block).
call "%~dp0find-python.cmd"
if not defined PY goto :nopy
set "HOOK=%~1"
if "%HOOK%"=="" goto :badhook
if not "%HOOK:\=%"=="%HOOK%" goto :badhook
if not "%HOOK:/=%"=="%HOOK%" goto :badhook
if not "%HOOK:..=%"=="%HOOK%" goto :badhook
if not exist "%~dp0py\%HOOK%.py" goto :badhook
"%PY%" -E -S -B "%~dp0py\%HOOK%.py"
exit /b %errorlevel%

:nopy
echo BLOCKED by ISP policy [FIRST GATE]: no trusted Python interpreter found (find-python.cmd: python.exe under C:\Program Files, C:\Program Files (x86) or C:\Windows). The ISP safety layer cannot run without it. Install Python (MDM), then restart Claude Code.>&2
exit /b 2

:badhook
echo BLOCKED by ISP policy: run-hook.cmd - hook "%~1" not found in %~dp0py.>&2
exit /b 2
