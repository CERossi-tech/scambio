#!/bin/sh
# ==== ISP hook launcher (macOS) ====
# Every Python hook in 50-hooks-MAC.json runs through this script:
#   /bin/sh "/Library/Application Support/ClaudeCode/hooks/run-hook.sh" <hook-name>
# It picks the interpreter with the rule in find-python.sh (system root, file + every parent folder
# root-owned; DEVELOPER_DIR/TOOLCHAINS/SDKROOT dropped) and execs the hook with THAT interpreter: the
# interpreter that is checked is the one that runs. Only shell builtins here.
# FAIL-CLOSED: no trusted interpreter, invalid name or missing hook file -> exit 2 (block).
here=${0%/*}
. "$here/find-python.sh"
if [ -z "$PY" ]; then
  echo "BLOCKED by ISP policy [FIRST GATE]: no trusted Python interpreter found (find-python.sh: python3 in a root-owned system folder). The ISP safety layer cannot run without it. Install the Xcode Command Line Tools, then restart Claude Code." >&2
  exit 2
fi
case "$1" in
  ""|*/*|*..*) echo "BLOCKED by ISP policy: run-hook.sh - invalid hook name '$1'." >&2; exit 2 ;;
esac
if [ ! -f "$here/py/$1.py" ]; then
  echo "BLOCKED by ISP policy: run-hook.sh - hook '$1' not found in $here/py." >&2
  exit 2
fi
exec "$PY" -E -S -B "$here/py/$1.py"
