@echo off
setlocal
rem ==== ISP FIRST GATE - prerequisite tooling: python + git + gcloud ====
rem cmd (NOT Python) on purpose: cmd.exe is ALWAYS present, so this gate runs even if
rem python/git/gcloud are missing and can detect them - a Python hook cannot (if Python is
rem gone, no Python hook runs). If ANY of the three is missing the whole ISP safety layer
rem is compromised -> BLOCK everything.
rem FAIL-CLOSED: default is to block; "exit /b 0" is reached ONLY on the explicit all-clear
rem path. Wired on UserPromptSubmit + PreToolUse (exit 2 = block) and SessionStart (message).
rem python + git come from the rule in find-python.cmd (under the system roots, never the current
rem directory or a user folder on PATH) - the SAME interpreter run-hook.cmd uses for every hook;
rem python is also checked for version >= 3.11 under -E -S, as the hooks run it.
rem gcloud: presence only (it runs no guard), via where.exe by absolute path.
rem No environment variable is read (no test seam): the user controls the environment.
set "MISS="
call "%~dp0find-python.cmd"
if not defined PY set "MISS=%MISS% python"
if defined PY ( "%PY%" -E -S -c "import sys;sys.exit(0 if sys.version_info>=(3,11) else 1)" >nul 2>&1 || set "MISS=%MISS% python(>=3.11)" )
if not defined GIT set "MISS=%MISS% git"
"C:\Windows\System32\where.exe" gcloud >nul 2>&1 || set "MISS=%MISS% gcloud"
if defined MISS goto :block
exit /b 0

:block
echo BLOCKED by ISP policy [FIRST GATE]: required tooling missing:%MISS%. The ISP safety layer cannot run without it. Install python ^(MDM, C:\Program Files\Python31x^) / git ^(Git for Windows, C:\Program Files^) / gcloud ^(Google Cloud CLI^), then restart Claude Code.>&2
exit /b 2
