# ==== ISP trusted-tool rule (macOS) - sourced by run-hook.sh, deps-guard.sh and the package launchers ====
# Sets PY (Python interpreter for the hooks) and GIT to the FIRST candidate that is trusted:
#  - under a system root: /usr/ /bin/ /sbin/ /System/ /Library/ /Applications/;
#  - the file and EVERY parent folder (symlinks followed) owned by root, not writable by others,
#    group-writable only for wheel/admin: nobody but an admin can replace it, rename a parent or
#    plant a stdlib/dylib next to it (Homebrew's /usr/local, apps dragged by a user: rejected);
#  - a /usr/bin tool may be an xcode-select shim (python3, git): it then also needs the developer
#    folder of `xcode-select -p` to pass the same check.
# Candidates: the usual locations below first (discovery hints), then python3/git on PATH (absolute
# entries only); a candidate that fails the rule is skipped, never run.
# DEVELOPER_DIR / TOOLCHAINS / SDKROOT are dropped first: with them a root-owned shim would run a
# user's copy. Unset in the sourcing launcher and in what it runs (the hooks, git); the user's shell
# and the commands Claude runs for the user are not touched. Same rule in Python: isp_hooks.trusted_exe.
# Only shell builtins + /usr/bin/stat and /usr/bin/xcode-select by absolute path (system, SIP).
unset DEVELOPER_DIR TOOLCHAINS SDKROOT

_fp_owned() {   # $1: it and every parent folder root-owned, not other-writable, group-writable only wheel/admin
  _fp_p=$1
  while :; do
    set -- $(/usr/bin/stat -L -f '%u %g %Lp' "$_fp_p" 2>/dev/null)
    [ "$#" -eq 3 ] && [ "$1" = 0 ] || return 1
    case $3 in *[2367]) return 1 ;; esac
    case $3 in *[2367]?) [ "$2" = 0 ] || [ "$2" = 80 ] || return 1 ;; esac
    [ "$_fp_p" = / ] && return 0
    _fp_p=${_fp_p%/*}
    [ -n "$_fp_p" ] || _fp_p=/
  done
}

_fp_trusted() {   # $1: candidate executable
  [ -f "$1" ] && [ -x "$1" ] || return 1
  case $1 in /usr/*|/bin/*|/sbin/*|/System/*|/Library/*|/Applications/*) ;; *) return 1 ;; esac
  _fp_owned "$1" || return 1
  case $1 in
    /usr/bin/*)
      _fp_d=$(/usr/bin/xcode-select -p 2>/dev/null) || return 1
      case $_fp_d in /usr/*|/Library/*|/Applications/*) ;; *) return 1 ;; esac
      _fp_owned "$_fp_d" || return 1 ;;
  esac
  return 0
}

_fp_find() {   # $1: name on PATH, then hints in $2...; prints the first trusted candidate
  _fp_n=$1; shift
  for _fp_c in "$@"; do
    if _fp_trusted "$_fp_c"; then printf '%s\n' "$_fp_c"; return 0; fi
  done
  _fp_ifs=$IFS; IFS=:
  set -f
  for _fp_dir in $PATH; do
    case $_fp_dir in /*) ;; *) continue ;; esac
    if _fp_trusted "$_fp_dir/$_fp_n"; then set +f; IFS=$_fp_ifs; printf '%s\n' "$_fp_dir/$_fp_n"; return 0; fi
  done
  set +f; IFS=$_fp_ifs
  return 1
}

PY=$(_fp_find python3 "/Library/Application Support/ClaudeCode/python/bin/python3" \
                      "/Library/Developer/CommandLineTools/usr/bin/python3" \
                      "/Applications/Xcode.app/Contents/Developer/usr/bin/python3")
GIT=$(_fp_find git "/Library/Developer/CommandLineTools/usr/bin/git" \
                   "/Applications/Xcode.app/Contents/Developer/usr/bin/git")
unset _fp_p _fp_d _fp_n _fp_c _fp_ifs _fp_dir
