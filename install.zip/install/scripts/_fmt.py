"""Terminal formatting helper for the ISP scripts (color + ASCII box), TTY-aware.

ANSI is emitted ONLY when the target stream is a real terminal and NO_COLOR is unset, so output
CAPTURED by Claude Code / gcpAuthRefresh / pipes (tests) stays plain: no escape junk in the box
Claude draws for gcpAuthRefresh, and substring-based test assertions are unaffected. On Windows the
console VT processing is enabled on first use. Stdlib only. Do NOT use for machine-consumed output
(gcp-token JSON, get.py stdout).
"""
import os
import sys

_RESET = "\033[0m"
_COL = {"info": "\033[36m", "ok": "\033[32m", "warn": "\033[33m", "err": "\033[31m"}
_vt_done = False


def _enable_vt_windows():
    global _vt_done
    if _vt_done:
        return
    _vt_done = True
    try:
        import ctypes
        k = ctypes.windll.kernel32
        for h in (-11, -12):                       # STD_OUTPUT_HANDLE, STD_ERROR_HANDLE
            hdl = k.GetStdHandle(h)
            mode = ctypes.c_uint32()
            if k.GetConsoleMode(hdl, ctypes.byref(mode)):
                k.SetConsoleMode(hdl, mode.value | 0x0004)   # ENABLE_VIRTUAL_TERMINAL_PROCESSING
    except Exception:
        pass


def supports_color(stream=None):
    stream = sys.stdout if stream is None else stream
    if os.environ.get("NO_COLOR"):
        return False
    try:
        if not stream.isatty():
            return False
    except Exception:
        return False
    if os.name == "nt":
        _enable_vt_windows()
    return True


def _wrap(text, level, stream):
    c = _COL.get(level, "")
    return (c + text + _RESET) if (c and supports_color(stream)) else text


def line(text, level="info", stream=None):
    stream = sys.stdout if stream is None else stream
    print(_wrap(text, level, stream), file=stream)


def box(title, lines, level="info", stream=None):
    stream = sys.stdout if stream is None else stream
    w = 61
    print(_wrap("=" * w, level, stream), file=stream)
    print(_wrap(" " + title, level, stream), file=stream)
    print("-" * w, file=stream)
    for ln in lines:
        print(" " + str(ln), file=stream)
    print(_wrap("=" * w, level, stream), file=stream)
