#!/bin/bash
# gcloud re-auth - thin wrapper -> Python core (cross-OS). Usable as gcpAuthRefresh: does the
# login (account only if needed, ADC 1 attempt with timeout) then mirrors the per-directory ADC
# copy via adc-mirror. If it fails, gcpAuthRefresh re-fires on the next submit.
# Python from the same root-owned allowlist as the hooks (find-python.sh), never from PATH.
here="$(cd "$(dirname "${BASH_SOURCE[0]:-$0}")" && pwd)"
. "$here/../hooks/find-python.sh"
if [ -z "$PY" ]; then
  echo "ERROR: no Python in the allowed system folders (Xcode Command Line Tools: xcode-select --install)." >&2
  exit 1
fi
exec "$PY" -E -S -B "$here/gcloud-reauth.py"
