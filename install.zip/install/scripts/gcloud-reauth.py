"""GCloud re-authentication core (used by gcloud-reauth.{cmd,sh} and gcpAuthRefresh).

Reauth (invalid_rapt) needs an ACCOUNT login (scope accounts.reauth) BEFORE the ADC login:
`gcloud auth application-default login` alone fails with "cloud-platform scope not consented"
and gcpAuthRefresh would keep re-firing (loop). So:

  1. account login ONLY if its token can't be minted (`gcloud auth print-access-token` fails);
  2. ADC login ONCE with a TIMEOUT (a hung login is killed, never blocks). No internal retry loop:
     if it fails, gcpAuthRefresh re-fires on the next submit, so the whole flow just runs again;
  3. on success, mirror the fresh global ADC into the per-directory copy (reuse adc-mirror.py).

Both interactive logins are serialized across concurrent sessions by a machine-global lock
(`~/.claude/.gcloud-reauth.lock`): the browser + OAuth-callback port are machine resources, so with
per-session CLOUDSDK_CONFIG isolation the logins must not race. A login still alive past KILL_TIMEOUT
(default LOGIN_TIMEOUT) is an orphan/hung leftover (e.g. its parent session was closed) and is killed
before the next login; a healthy login in progress is NOT killed — this run defers and retries.

GOOGLE_APPLICATION_CREDENTIALS is removed from the child gcloud env so the ADC login writes the
global default without the interactive Y/n prompt (gcpAuthRefresh can't answer prompts). Timeouts
are killed (never hang); gcpAuthRefresh also caps the whole run at ~3 min. Exit 0 on success, 1 on
give-up. Stdlib only.
"""
import json
import os
import signal
import subprocess
import sys
import time
import _fmt

LOGIN_TIMEOUT = int(os.environ.get("REAUTH_LOGIN_TIMEOUT", "120"))  # browser-login timeout secs
CHECK_TIMEOUT = int(os.environ.get("REAUTH_CHECK_TIMEOUT", "30"))   # account-token check secs
# A login still alive past this age is orphaned/hung (its owner would have killed it at
# LOGIN_TIMEOUT) -> another concurrent session may kill it. Default == LOGIN_TIMEOUT.
KILL_TIMEOUT = int(os.environ.get("REAUTH_KILL_TIMEOUT", str(LOGIN_TIMEOUT)))
# Machine-global (per-user) lock serializing interactive logins across concurrent sessions: the
# browser + OAuth-callback port are machine resources, not per-config, so with per-session
# CLOUDSDK_CONFIG isolation each session still needs its own login and they must not race.
LOCK_PATH = os.path.join(os.path.expanduser("~"), ".claude", ".gcloud-reauth.lock")
_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def _gcloud():
    import shutil
    return shutil.which("gcloud") or (shutil.which("gcloud.cmd") if os.name == "nt" else None)


def _run(g, args, timeout, env):
    """True if gcloud <args> exits 0 within timeout; False on non-zero/timeout/spawn error."""
    try:
        return subprocess.run([g] + args, timeout=timeout, env=env,
                              creationflags=_NO_WINDOW).returncode == 0
    except Exception:
        return False


def _mirror_adc(timeout=30):
    """Run adc-mirror.py (sync, no network) to refresh the per-directory ADC copy.
    True iff the process completed with rc 0. adc-mirror is fail-open (it ALWAYS exits 0 -
    including the gcp-auto-off no-op when there is no per-dir copy), so a False here means a
    subprocess-level failure (couldn't launch / timeout), not an internal mirror error (S-3)."""
    here = os.path.dirname(os.path.realpath(__file__))
    mirror = os.path.normpath(os.path.join(here, "..", "hooks", "py", "adc-mirror.py"))
    try:
        mr = subprocess.run([sys.executable, "-E", "-S", "-B", mirror],
                            input="", text=True, timeout=timeout, creationflags=_NO_WINDOW)
        return mr.returncode == 0
    except Exception:
        return False


def _now():
    return int(time.time())


def _read_lock(path):
    """Parse the lock file -> dict, or None if absent. A corrupt/unreadable lock is reported as a
    dead holder ({"pid": None}) so the caller removes it and proceeds (fail-safe)."""
    try:
        with open(path, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {"pid": None, "start": 0}
    except FileNotFoundError:
        return None
    except Exception:
        return {"pid": None, "start": 0}


def _write_lock(path, pid):
    try:
        with open(path, "w", encoding="utf-8") as f:
            f.write(json.dumps({"pid": pid, "start": _now()}))
    except OSError:
        pass


def _remove_lock(path):
    try:
        os.remove(path)
    except OSError:
        pass


def _pid_alive(pid):
    """True if pid is a running process. Windows: tasklist (exact-PID filter); POSIX: kill(pid, 0)."""
    if not isinstance(pid, int) or pid <= 0:
        return False
    if os.name == "nt":
        try:
            # tasklist resolved on PATH and accepted only in an admin-owned folder (isp_hooks.system_tool)
            sys.path.insert(0, os.path.join(os.path.dirname(os.path.realpath(__file__)), "..", "hooks", "py"))
            import isp_hooks
            out = subprocess.run([isp_hooks.system_tool_path("tasklist"), "/FI", "PID eq %d" % pid, "/NH"],
                                 capture_output=True, text=True, timeout=10,
                                 creationflags=_NO_WINDOW)
            return str(pid) in (out.stdout or "")
        except Exception:
            return False
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError:
        return False


def _kill_tree(pid):
    """Kill the process and its children. Windows: taskkill /T; POSIX: killpg (the child runs in its
    own session, see _run_login) with a plain-kill fallback."""
    if not isinstance(pid, int) or pid <= 0:
        return
    if os.name == "nt":
        try:
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(pid)],
                           capture_output=True, timeout=15, creationflags=_NO_WINDOW)
        except Exception:
            pass
        return
    try:
        os.killpg(os.getpgid(pid), signal.SIGKILL)
    except Exception:
        try:
            os.kill(pid, signal.SIGKILL)
        except Exception:
            pass


def _lock_decision(exists, alive, age, kill_to):
    """PURE decision for the interactive-login lock. Returns:
      'proceed' - no lock, or holder dead/stale -> take over;
      'kill'    - holder alive but older than kill_to (orphan/hung) -> kill then take over;
      'defer'   - holder alive and within kill_to (healthy login in progress) -> retry later.
    Kill happens ONLY past the timeout: a healthy in-progress login is never killed."""
    if not exists or not alive:
        return "proceed"
    return "kill" if age > kill_to else "defer"


def _run_login(g, args, timeout, env, lockpath):
    """Interactive gcloud login serialized by the machine-global lock. Returns True (ok),
    False (failed/timeout), or None (deferred: another session is mid-login and not yet past
    KILL_TIMEOUT -> the caller should retry on the next submit). Records the CHILD pid in the lock
    so, if this process dies, the orphaned login stays identifiable and killable — but only past
    KILL_TIMEOUT (a healthy login is never killed)."""
    info = _read_lock(lockpath)
    if info is not None:
        pid = info.get("pid")
        age = _now() - int(info.get("start") or 0)
        alive = _pid_alive(pid) if isinstance(pid, int) else False
        decision = _lock_decision(True, alive, age, KILL_TIMEOUT)
        if decision == "defer":
            _fmt.line("    another GCP login in progress (pid %s, %ds) - will retry." % (pid, int(age)), "warn")
            return None
        if decision == "kill":
            _fmt.line("    killing a hung GCP login (pid %s, %ds) before retry..." % (pid, int(age)), "warn")
            _kill_tree(pid)
        _remove_lock(lockpath)

    try:
        os.makedirs(os.path.dirname(lockpath), exist_ok=True)
    except OSError:
        pass
    # atomic claim; write OUR pid at once so the setup window isn't mistaken for a stale lock
    try:
        fd = os.open(lockpath, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError:
        _fmt.line("    another GCP login just started - will retry.", "warn")
        return None
    except OSError:
        fd = None
    if fd is not None:
        try:
            os.write(fd, json.dumps({"pid": os.getpid(), "start": _now()}).encode("utf-8"))
        finally:
            os.close(fd)

    try:
        kw = {"env": env}
        if os.name == "nt":
            kw["creationflags"] = _NO_WINDOW
        else:
            kw["start_new_session"] = True     # own process group -> killpg reaches the whole tree
        p = subprocess.Popen([g] + args, **kw)
    except Exception:
        _remove_lock(lockpath)
        return False

    _write_lock(lockpath, p.pid)               # record the child pid (an orphan stays killable)
    try:
        return p.wait(timeout=timeout) == 0
    except subprocess.TimeoutExpired:
        _kill_tree(p.pid)
        try:
            p.wait(timeout=5)
        except Exception:
            pass
        return False
    finally:
        _remove_lock(lockpath)


def main():
    g = _gcloud()
    if not g:
        _fmt.line("[X] gcloud not found on PATH.", "err", sys.stderr)
        return 1

    env = dict(os.environ)
    env.pop("GOOGLE_APPLICATION_CREDENTIALS", None)   # ADC login -> global default, no Y/n prompt

    _fmt.line("[!] GCloud session expired - re-authenticating...", "warn")

    # 1. account login only if its token can't be minted (reauth/expired) -> avoids a useless
    #    browser. Serialized by the lock (browser/port is machine-global); a defer (None) just
    #    retries on the next submit.
    if not _run(g, ["auth", "print-access-token", "--quiet"], CHECK_TIMEOUT, env):
        _fmt.line("    GCloud account needs re-auth (browser login)...", "info")
        if _run_login(g, ["auth", "login"], LOGIN_TIMEOUT, env, LOCK_PATH) is None:
            return 1   # another login in progress -> gcpAuthRefresh re-fires next submit

    # 2. ADC login ONLY if the ADC can't currently be minted (probe first) -> no browser when the
    #    ADC is already valid, even if gcpAuthRefresh fired for a transient. If it fails, log in
    #    (serialized, with a timeout); gcpAuthRefresh re-fires on the next submit if that also fails.
    if _run(g, ["auth", "application-default", "print-access-token", "--quiet"], CHECK_TIMEOUT, env):
        _fmt.line("    ADC already valid - no browser needed.", "ok")
    else:
        _fmt.line("    ADC login (application-default)...", "info")
        r = _run_login(g, ["auth", "application-default", "login"], LOGIN_TIMEOUT, env, LOCK_PATH)
        if r is None:
            return 1   # another login in progress -> retry on the next submit
        if not r:
            _fmt.line("[X] ADC login failed - retry on the next message.", "err", sys.stderr)
            return 1

    # 3. mirror the fresh global ADC into the per-directory copy (single impl: adc-mirror.py sibling)
    if not _mirror_adc():   # best-effort: l'ADC globale e' valido, ma la copia per-dir potrebbe restare stale
        _fmt.line("[!] Per-directory ADC mirror failed - the global ADC is valid; "
                  "if a per-directory project is active, run set-vertex-project again.", "warn", sys.stderr)

    _fmt.line("[OK] Authentication complete. Re-send your prompt in Claude Code.", "ok")
    return 0


if __name__ == "__main__":
    sys.exit(main())
