#!/usr/bin/env bash
# launcher -> set-vertex-project-doctor.py (cross-OS core). Checks python FIRST so that a missing
# python — itself a managed deploy prerequisite the hooks depend on — stays diagnosable here.
here="$(cd "$(dirname "${BASH_SOURCE[0]:-$0}")" && pwd)"
# Python from the same allowlist as the hooks (find-python.sh). If none is allowed the doctor still
# runs on the python3 of PATH, with a warning, so that the problem stays diagnosable.
. "$here/../hooks/find-python.sh"
if [ -n "$PY" ]; then exec "$PY" -E -S -B "$here/set-vertex-project-doctor.py" "$@"; fi
echo "WARNING: no Python in the allowed system folders (Xcode Command Line Tools: xcode-select --install):" >&2
echo "  the hooks and set-vertex-project cannot run. Running the doctor with the python3 of PATH." >&2
for py in python3 python; do
    if command -v "$py" >/dev/null 2>&1; then exec "$py" -E -S -B "$here/set-vertex-project-doctor.py" "$@"; fi
done
echo "ERROR: python not found at all." >&2
exit 1
