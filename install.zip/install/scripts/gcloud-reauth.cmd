@echo off
rem gcloud re-auth - thin wrapper -> Python core (cross-OS). Usable as gcpAuthRefresh: does the
rem login (account only if needed, ADC 1 attempt with timeout) then mirrors the per-directory ADC
rem copy via adc-mirror. If it fails, gcpAuthRefresh re-fires on the next submit.
rem Python from the same admin-only allowlist as the hooks (find-python.cmd), never from PATH.
call "%~dp0..\hooks\find-python.cmd"
if not defined PY (
  echo ERROR: no Python in C:\Program Files\Python31x - managed deploy prerequisite. Diagnosis: set-vertex-project-doctor 1>&2
  exit /b 1
)
"%PY%" -E -S -B "%~dp0gcloud-reauth.py"
exit /b %errorlevel%
