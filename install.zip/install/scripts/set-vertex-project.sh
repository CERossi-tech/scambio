#!/usr/bin/env bash
# launcher -> set-vertex-project.py (cross-OS core). Checks python FIRST so that a missing
# python — itself a managed deploy prerequisite the hooks depend on — stays diagnosable here.
# Resolve symlinks so that /usr/local/bin/set-vertex-project -> .../scripts/set-vertex-project.sh
# correctly finds set-vertex-project.py next to the real script, not next to the symlink.
_src="${BASH_SOURCE[0]:-$0}"
while [ -L "$_src" ]; do
    _dir="$(cd -P "$(dirname "$_src")" && pwd)"
    _src="$(readlink "$_src")"
    [[ "$_src" != /* ]] && _src="$_dir/$_src"
done
here="$(cd -P "$(dirname "$_src")" && pwd)"
# Python from the same root-owned allowlist as the hooks (find-python.sh), NEVER from PATH: a personal
# python3 first on PATH (Homebrew, pyenv, python.org) has its own CA bundle without the ISP CA and
# fails the CHAP0 call ("Servizio progetti non raggiungibile"), or can be an impostor.
. "$here/../hooks/find-python.sh"
if [ -n "$PY" ]; then exec "$PY" -E -S -B "$here/set-vertex-project.py" "$@"; fi
echo "ERROR: no Python in the allowed system folders (Xcode Command Line Tools: xcode-select --install)." >&2
echo "  It is a managed deploy prerequisite (the hooks need it too). Diagnosis: set-vertex-project-doctor" >&2
exit 1
