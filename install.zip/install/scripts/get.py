#!/usr/bin/env python3
"""GET-only, curl-like wrapper. `curl`/`wget` are denied in Bash (they'd be an
uncontrolled egress/exfil vector, esp. under --bare). This gives the same UX for
the ONE safe case: a plain GET to an ISP-internal host. External content -> WebFetch.

Python is a controlled deploy prerequisite (deps-guard, fail-closed) -> `get` works
everywhere. Stdlib only, no third-party packages.

Usage:  python get.py <url> [-H "Header: value"]... [-i] [-m <seconds>]
                       [--header-env 'Name:VAR']...
                       [--oauth2-bearer VAR | -u UserVar:PassVar]
  Method is ALWAYS GET — no -d/-X/-o/upload. Unknown flags are rejected.
  AUTH — curl flag NAMES, but the arguments are ENV VAR NAMES (never the secret
  itself), so the token never appears on the command line / in logs:
    --oauth2-bearer VAR      -> Authorization: Bearer <$VAR>
    -u, --user UVAR:PVAR     -> Authorization: Basic base64(<$UVAR>:<$PVAR>)
    --header-env 'Name:VAR'  -> header 'Name' = <$VAR>  (repeatable)
  Enforcement lives in THIS script (not a hook), so it holds even under `claude --bare`.

Deployed with the managed package to the OS scripts dir (win: C:/Program Files/
ClaudeCode/scripts/, mac: /Library/Application Support/ClaudeCode/scripts/).
Reads the internal-host list from the deployed egress-domains.json (single source of
truth); falls back to the embedded list if not found. TLS verification is ALWAYS on.

Exit: 0 ok, 1 HTTP/network error, 2 usage/policy error.
"""
import base64
import json
import os
import sys
import urllib.error
import urllib.request
from urllib.parse import urlparse
import _fmt

INTERNAL_FALLBACK = [
    "*.intesasanpaolo.com", "*.sanpaolo.com", "*.sanpaoloimi.com",
    "*.ubibanca.com", "*.previmedical.priv",
]


def internal_hosts():
    paths = []
    # Test override ONLY from config/test-overrides.json of this package (scripts/../config): admin/root-only
    # once installed. Never from an env var, which the user controls (own allowlist -> GET to any host).
    try:
        with open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "config",
                               "test-overrides.json"), encoding="utf-8") as f:
            override = json.load(f).get("CLAUDE_EGRESS_ALLOWLIST")
    except Exception:
        override = None
    if override:
        paths.append(override)
    paths += [
        "C:/Program Files/ClaudeCode/config/egress-domains.json",
        "/Library/Application Support/ClaudeCode/config/egress-domains.json",
    ]
    for p in paths:
        try:
            with open(p, encoding="utf-8") as f:
                lst = (json.load(f).get("egressAllowlist") or {}).get("internalHosts")
            if isinstance(lst, list) and lst:
                return lst
        except Exception:
            pass
    return INTERNAL_FALLBACK


def host_matches(host, patterns):
    host = (host or "").lower()
    for p in patterns:
        p = p.lower()
        if p.startswith("*."):
            if host == p[2:] or host.endswith(p[1:]):
                return True
        elif host == p:
            return True
    return False


USAGE = "\n".join([
    "get — GET-only curl replacement (ISP-internal hosts only; external -> use WebFetch).",
    "",
    "Usage: get <url> [-i] [-m sec] [-H 'K: V']...",
    "           [--header-env 'Name:VAR']... [--oauth2-bearer VAR | -u UserVar:PassVar]",
    "",
    "  -i, --include            include the HTTP status line in the output",
    "  -m, --max-time <sec>     max total time (default 15)",
    "  -H, --header 'K: V'      add a request header (repeatable)",
    "  --oauth2-bearer VAR      Authorization: Bearer  <value of $VAR>",
    "  -u, --user UVAR:PVAR     Authorization: Basic base64($UVAR:$PVAR)",
    "  --header-env 'Name:VAR'  set header 'Name' from $VAR (repeatable)",
    "  -h, --help               show this help",
    "",
    "AUTH: curl flag names, but arguments are ENV VAR NAMES, not the secret itself",
    "  (the token/password never appears on the command line). e.g. -u SVC_USER:SVC_PASS",
    "Method is always GET; -d/-X/-o/upload and non-internal hosts are rejected.",
])


def fail(msg):
    _fmt.line("get.py: " + msg, "err", sys.stderr)          # error line colored (TTY-aware)
    sys.stderr.write("\n" + USAGE + "\n")                    # usage stays plain
    sys.exit(2)


def main():
    args = sys.argv[1:]
    url = None
    include = False
    timeout = 15
    bearer_env = None
    user_var = None
    pass_var = None
    headers = {}

    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-h", "--help"):
            sys.stdout.write(USAGE + "\n")
            sys.exit(0)
        elif a in ("-H", "--header"):
            i += 1
            hh = args[i] if i < len(args) else ""
            idx = hh.find(":")
            if idx > 0:
                headers[hh[:idx].strip()] = hh[idx + 1:].strip()
        elif a in ("-i", "--include"):
            include = True
        elif a in ("-m", "--max-time"):
            i += 1
            try:
                timeout = int(args[i]) if i < len(args) else 15
            except ValueError:
                timeout = 15
            if timeout <= 0:
                timeout = 15
        elif a == "--header-env":
            i += 1
            spec = args[i] if i < len(args) else ""
            idx = spec.find(":")
            if idx <= 0:
                fail("--header-env expects 'HeaderName:ENVVAR'")
            hname = spec[:idx].strip()
            vname = spec[idx + 1:].strip()
            hval = os.environ.get(vname)
            if not hval:
                fail("env var '" + vname + "' is not set (for header " + hname + ")")
            headers[hname] = hval
        elif a == "--oauth2-bearer":
            i += 1
            bearer_env = args[i] if i < len(args) else None   # NAME of the env var, not the token
        elif a in ("-u", "--user"):
            i += 1
            spec = args[i] if i < len(args) else ""
            idx = spec.find(":")
            if idx <= 0:
                fail("-u expects <UserVar>:<PassVar> (env var NAMES, not literal user:password)")
            user_var = spec[:idx].strip()
            pass_var = spec[idx + 1:].strip()
        elif not a.startswith("-"):
            url = a
        else:
            fail("unsupported flag '" + a + "' (GET-only; allowed: -H, -i, -m, "
                 "--header-env, --oauth2-bearer, -u/--user)")
        i += 1

    if not url:
        fail("missing <url>")

    # --- auth from env (curl flag names; arguments are env var NAMES, secret read here) ---
    if bearer_env and (user_var or pass_var):
        fail("use either --oauth2-bearer OR -u, not both")
    if bearer_env:
        tok = os.environ.get(bearer_env)
        if not tok:
            fail("env var '" + bearer_env + "' is not set (bearer token)")
        headers["Authorization"] = "Bearer " + tok
    elif user_var or pass_var:
        if not user_var or not pass_var:
            fail("-u requires <UserVar>:<PassVar>")
        u = os.environ.get(user_var)
        p = os.environ.get(pass_var)
        if not u:
            fail("env var '" + user_var + "' is not set (basic user)")
        if not p:
            fail("env var '" + pass_var + "' is not set (basic password)")
        headers["Authorization"] = "Basic " + base64.b64encode((u + ":" + p).encode()).decode()

    try:
        host = urlparse(url).hostname
    except Exception:
        host = None
    if not host:
        fail("invalid URL")
    if not host_matches(host, internal_hosts()):
        fail("'" + host + "' is not an ISP-internal host. Use the WebFetch tool for external content.")

    req = urllib.request.Request(url, method="GET", headers=headers)  # redirects followed by default
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:      # TLS verified (default context)
            body = r.read().decode("utf-8", "replace")
            if include:
                sys.stdout.write("HTTP %s %s\n" % (r.status, r.reason))
            sys.stdout.write(body)
        sys.exit(0)
    except urllib.error.HTTPError as e:
        body = ""
        try:
            body = e.read().decode("utf-8", "replace")
        except Exception:
            pass
        if include:
            sys.stdout.write("HTTP %s %s\n" % (e.code, e.reason))
        sys.stdout.write(body)
        sys.exit(1)
    except Exception as e:
        _fmt.line("get.py: request failed: %s" % e, "err", sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
