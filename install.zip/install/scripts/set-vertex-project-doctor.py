#!/usr/bin/env python3
"""Claude Code / set-vertex-project environment doctor (macOS + Windows).

Cross-platform, READ-ONLY (one temp write-test in an EXISTING .claude, deleted). Diagnoses the
prerequisites for set-vertex-project + the managed hooks and prints an actionable, paste-friendly
report (self-service + SSO/Kerberos/VPN support). Launched by set-vertex-project-doctor.{sh,cmd},
which first check that python exists (so 'python missing' stays diagnosable).

Every check reuses the function of the hook / wizard that enforces it, so the doctor gives the same
verdict: identity (isp_hooks.resolve_userid_detail, as set-vertex-project), runtime deps
(isp_hooks.runtime_deps), managed config (hooks wired in the deployed 50-hooks.json), authorized
binary (manifest path + SHA256, as binary-integrity, plus the `claude` found on PATH), folder config
(vertex-guard.validate, incl. isp.pkg_version == installed package, + settings-consistency), GCP ADC
(isp_hooks.adc_check), CHAP0 (token, project list as set-vertex-project, project validation as
project-vidima), VPN ISPers (vpn-guard.detect_state), git/marketplace (isp_hooks.trusted_git),
network reachability.
"""
import getpass
import importlib.util
import json
import os
import re
import socket
import subprocess
import sys
import time

IS_WIN = os.name == "nt"
CC = r"C:\Program Files\ClaudeCode" if IS_WIN else "/Library/Application Support/ClaudeCode"
HOOKS = os.path.join(CC, "hooks", "py")
CONFIG = os.path.join(CC, "config")
MSD = os.path.join(CC, "managed-settings.d")

# ---- colors (TTY-aware; enable VT on Windows) ----
if IS_WIN:
    try:
        import ctypes
        _k = ctypes.windll.kernel32
        _k.SetConsoleMode(_k.GetStdHandle(-11), 7)
    except Exception:
        pass
_COLOR = sys.stdout.isatty() and not os.environ.get("NO_COLOR")
def _c(s, code): return ("\033[%sm%s\033[0m" % (code, s)) if _COLOR else s
SUMMARY = False                       # --summary: one OK/WARN/FAIL line per section (for cctui panel)
_SEV = {"ok": 0, "warn": 1, "err": 2}
_sec = {"title": None, "sev": "ok", "rows": []}
def _bump(level):
    if _SEV[level] > _SEV[_sec["sev"]]:
        _sec["sev"] = level
def _flush():
    if _sec["title"] is not None:
        _sec["rows"].append((_sec["title"], _sec["sev"]))
    _sec["sev"] = "ok"
def HDR(t):
    if SUMMARY:
        _flush(); _sec["title"] = t; return
    print("\n" + _c("-- " + t, "1;36"))
def OK(t):
    if not SUMMARY: print("   " + _c(t, "1;32"))
def WR(t):
    _bump("warn")
    if not SUMMARY: print("   " + _c(t, "1;33"))
def ER(t):
    _bump("err")
    if not SUMMARY: print("   " + _c(t, "1;31"))
def DS(t):
    if not SUMMARY: print("   " + _c(t, "2"))


def _which(x):
    from shutil import which
    return which(x)


def _trusted(name):
    """Path of a system command as the hooks accept it (isp_hooks.system_tool: on PATH, admin-owned
    folder), else None: never run by name."""
    h = _isp_hooks()
    return h.system_tool(name)[0] if h and hasattr(h, "system_tool") else None


def _run(argv, timeout=8):
    try:
        p = subprocess.run(argv, capture_output=True, text=True, timeout=timeout,
                           encoding="utf-8", errors="replace")   # ipconfig/klist can emit non-UTF8
        return p.returncode, (p.stdout or "") + (p.stderr or "")
    except Exception as e:
        return -1, str(e)


def _load_json(path):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def _isp_hooks():
    for p in (HOOKS, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "hooks", "py")):
        if os.path.isdir(p) and p not in sys.path:
            sys.path.insert(0, p)
    try:
        import isp_hooks
        return isp_hooks
    except Exception:
        return None


def _load_module(name, path):
    try:
        spec = importlib.util.spec_from_file_location(name, path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod
    except Exception:
        return None


# ------------------------------------------------------------------ sections
def sec_identity():
    HDR("1. identity / matricola (developer.id)")
    h = _isp_hooks()
    user = h.os_login() if h and hasattr(h, "os_login") else getpass.getuser()
    DS("OS login = %s" % user)
    if not h:
        ER("cannot import isp_hooks from %s -> hooks are broken (python/deploy issue)" % HOOKS)
        return
    if not hasattr(h, "resolve_userid_detail"):     # hooks of an older package than this doctor
        try:
            OK("resolve_userid() -> %s" % h.resolve_userid())
        except Exception as e:
            ER("resolve_userid() FAILS -> %s" % e)
        return
    # same resolution, evidence and fix text as set-vertex-project's first window
    uid, source, steps = h.resolve_userid_detail()
    if uid:
        OK("matricola %s (from %s)" % (uid, source))
    else:
        ER("ISP matricola not found: U + 6 characters needed (e.g. U447742) -> set-vertex-project stops, "
           "the hooks block Claude")
    for src, val, ok in steps:
        (DS if ok or uid else ER)("  %-18s %s" % (src + ":", val if ok else h.userid_step_why(val)))
    if not uid:
        for line in h.userid_fix_lines():
            DS(line)
    if not IS_WIN:
        # macOS extras: Kerberos TGT (presence, validity, expiry: same verdict as set-vertex-project) + app-sso UPN
        note = h.kerberos_note(bool(steps and steps[0][2])) if hasattr(h, "kerberos_note") else None
        if note is None:
            WR("klist not runnable (%s): Kerberos ticket not checkable" % getattr(h, "KLIST", "klist"))
        else:
            {"ok": OK, "warn": WR, "err": ER}.get(note[0], DS)(note[1])
        rc, out = _run(["/usr/bin/app-sso", "platform", "-s"], 10)
        upn = h._parse_upn(out) if hasattr(h, "_parse_upn") else ""
        DS("app-sso UPN = %s" % (upn or "(none / app-sso null)"))
    else:
        DS("Windows: matricola = your login (USERNAME); no Platform SSO/Kerberos (that is macOS only)")


def sec_deps():
    HDR("2. runtime deps on PATH (and whether they are in admin-owned system folders)")
    h = _isp_hooks()
    if not h or not hasattr(h, "runtime_deps"):
        ER("cannot import isp_hooks.runtime_deps from %s -> hooks are broken (python/deploy issue)" % HOOKS)
        return
    # system commands run by the hooks (same verdict as vpn-guard: missing = Claude blocked)
    for name in getattr(h, "SYSTEM_TOOLS", ()):
        path, why = h.system_tool(name)
        gated = name in h.GATED_TOOLS
        if not path:
            (ER if gated else WR)("%-8s %s%s" % (name, why, " -> Claude BLOCKED at every prompt" if gated else ""))
        else:
            OK("%-8s %s" % (name, path))
    # same list and same verdict as set-vertex-project's first window (isp_hooks.runtime_deps)
    for name, path, required, system_required in h.runtime_deps():
        if not path:
            (WR if required else DS)("%-8s MISSING" % name)
        elif system_required and not h.is_system_path(path):
            WR("%-8s %s  <- outside the system folders (user-writable: can be replaced / behave differently)"
               % (name, path))
        else:
            OK("%-8s %s" % (name, path))


def sec_managed():
    HDR("3. managed config deployed (%s)" % CC)
    ms = os.path.join(CC, "managed-settings.json")
    (OK if os.path.isfile(ms) else ER)("managed-settings.json %s" % ("present" if os.path.isfile(ms) else "MISSING"))
    drop = sorted(os.path.basename(x) for x in (os.listdir(MSD) if os.path.isdir(MSD) else []))
    DS("drop-ins: %s" % (", ".join(drop) or "(none)"))
    v = _load_json(os.path.join(CONFIG, "version.json"))
    (OK if v and v.get("version") else ER)("version.json -> %s" % ((v or {}).get("version") or "MISSING/empty"))
    (OK if os.path.isfile(os.path.join(CONFIG, "egress-domains.json")) else ER)(
        "egress-domains.json %s" % ("present" if os.path.isfile(os.path.join(CONFIG, "egress-domains.json")) else "MISSING"))
    extra = _extraneous_dirs()
    for d in extra:
        ER("unexpected folder in the installed package: %s" % d)
    if not extra:
        OK("no unexpected folders in %s" % CC)
    if os.path.exists(os.path.join(CONFIG, "test-overrides.json")):
        ER("config/test-overrides.json PRESENT: test values override the controls (VPN, project, allowlist...) "
           "-> it must never be installed: remove it (admin) and contact IT/Security")
    # every hook wired in the deployed 50-hooks.json must exist (a missing one = a control that never runs)
    wired = _load_json(os.path.join(MSD, "50-hooks.json"))
    if not wired:
        ER("50-hooks.json MISSING/invalid -> no managed hook runs (redeploy the package)")
        return
    files = {os.path.join(HOOKS, "isp_hooks.py"),
             os.path.join(CC, "hooks", "find-python.cmd" if IS_WIN else "find-python.sh")}
    for entries in (wired.get("hooks") or {}).values():
        for entry in entries:
            for hk in entry.get("hooks") or []:
                args = hk.get("args") or []
                for i, a in enumerate(args):
                    base = os.path.basename(a)
                    if base.startswith("run-hook.") and i + 1 < len(args):
                        files.add(os.path.normpath(a))
                        files.add(os.path.join(HOOKS, args[i + 1] + ".py"))
                    elif base.startswith("deps-guard."):
                        files.add(os.path.normpath(a))
    missing = sorted(os.path.basename(f) for f in files if not os.path.isfile(f))
    (OK if not missing else ER)("hooks wired in 50-hooks.json: %s" % (
        "%d files, all present" % len(files) if not missing else "MISSING " + ", ".join(missing)))


# Folders of the installed package (relative to CC); anything else is extraneous: backups, bytecode
# caches (__pycache__: a cached .pyc is loaded even with -B), leftovers. 'python' = bundled interpreter
# (future, allowlisted by find-python). On macOS the binary lives in /Applications, not under CC/bin.
_EXPECTED_DIRS = {"bin", "config", "managed-settings.d", "scripts", "hooks", os.path.join("hooks", "py"),
                  "githooks", "python"}


def _extraneous_dirs():
    """Folders under the installed package that are not part of it (relative paths); the bundled
    interpreter folder 'python' is not descended into."""
    out = []
    if not os.path.isdir(CC):
        return out
    for root, dirs, _files in os.walk(CC):
        rel_root = os.path.relpath(root, CC)
        for d in sorted(dirs):
            rel = os.path.normpath(os.path.join(rel_root, d)) if rel_root != "." else d
            if rel not in _EXPECTED_DIRS:
                out.append(rel)
        dirs[:] = [d for d in dirs if (os.path.normpath(os.path.join(rel_root, d)) if rel_root != "." else d)
                   in _EXPECTED_DIRS and d != "python"]
    return out


def sec_binary():
    HDR("4. authorized claude binary (same check as binary-integrity) + the `claude` on PATH")
    h = _isp_hooks()
    bi = _load_module("binint", os.path.join(HOOKS, "binary-integrity.py"))
    if not h or not bi:
        ER("cannot load isp_hooks / binary-integrity from %s -> hooks are broken (redeploy)" % HOOKS)
        return
    manifest = _load_json(h.MANIFEST)
    info = ((manifest or {}).get("platforms") or {}).get(h.platform_key()) or {}
    if not info.get("binary"):
        ER("manifest.json missing/invalid or without platform '%s' (%s) -> binary-integrity blocks every "
           "prompt (redeploy the package)" % (h.platform_key(), h.MANIFEST))
        return
    expected = os.path.join(h.BIN_DIR, info["binary"])
    sha = h.sha256_file(expected) if os.path.isfile(expected) else None
    if not sha:
        ER("authorized binary not found: %s -> redeploy the package" % expected)
    elif sha != (info.get("checksum") or "").lower():
        ER("SHA256 of %s != manifest.json -> binary-integrity blocks every prompt (contact IT/Security)"
           % expected)
    else:
        OK("%s  version %s  SHA256 == manifest" % (expected, manifest.get("version") or "?"))
    rmv = (_load_json(os.path.join(CC, "managed-settings.json")) or {}).get("requiredMinimumVersion")
    if rmv and manifest.get("version") and rmv != manifest.get("version"):
        WR("requiredMinimumVersion %s != packaged binary %s -> an older claude binary can still start "
           "(fix it in the package: managed-settings.json)" % (rmv, manifest.get("version")))
    if hasattr(h, "stale_claude_sessions"):
        old = h.stale_claude_sessions()
        for pid, t0, exe in old:
            ER("Claude session PID %s started %s, BEFORE the package install: it still runs the previous "
               "version (binary and telemetry attributes) -> close it (/exit) and restart Claude"
               % (pid, time.strftime("%d/%m %H:%M", time.localtime(t0))))
        if not old:
            OK("no Claude session started before the package install")
    onpath = _which("claude")
    if not onpath:
        WR("`claude` not found on PATH: start it with the full path %s" % expected)
    elif not bi._same(os.path.realpath(onpath), os.path.realpath(expected)):
        ER("`claude` on PATH is %s, not the authorized binary -> binary-integrity blocks every prompt. "
           "Remove it or put %s first on PATH" % (onpath, h.BIN_DIR))
    else:
        OK("`claude` on PATH -> %s" % onpath)


def _settings_local():
    return _load_json(os.path.join(os.getcwd(), ".claude", "settings.local.json")) or {}


def _otel(env):
    out = {}
    for part in (env.get("OTEL_RESOURCE_ATTRIBUTES") or "").split(","):
        if "=" in part:
            k, v = part.split("=", 1)
            out[k.strip()] = v.strip()
    return out


def sec_settings():
    HDR("5. .claude/settings.local.json (current folder) - verdict of vertex-guard + settings-consistency")
    d = _settings_local()
    if not d:
        WR("not present in this folder -> run set-vertex-project here first")
    else:
        env = d.get("env") or {}
        otel = _otel(env)
        OK("project = %s" % (env.get("ANTHROPIC_VERTEX_PROJECT_ID") or "(unset)"))
        DS("isp.project_id = %s   isp.pkg_version = %s   auto-cycle(gcpAuthRefresh) = %s" % (
            otel.get("isp.project_id") or "(unset)", otel.get("isp.pkg_version") or "(unset)",
            "on" if d.get("gcpAuthRefresh") else "off"))
        DS("GOOGLE_APPLICATION_CREDENTIALS = %s" % (env.get("GOOGLE_APPLICATION_CREDENTIALS") or "(unset -> global ADC)"))
        _isp_hooks()   # sys.path for the hook modules below
        vg = _load_module("vertexguard", os.path.join(HOOKS, "vertex-guard.py"))
        sc = _load_module("setcons", os.path.join(HOOKS, "settings-consistency.py"))
        if not vg or not sc:
            ER("cannot load vertex-guard / settings-consistency from %s -> hooks are broken (redeploy)" % HOOKS)
        else:
            # vertex-guard.validate: identity, isp prefix, gcp coherence, ADC quota, isp.pkg_version ==
            # installed config/version.json (a package upgrade needs set-vertex-project again)
            ok, reason = vg.validate(os.getcwd())
            fix = "" if "set-vertex-project" in reason else " -> run set-vertex-project here"
            (OK if ok else ER)("vertex-guard: %s" % ("config valid" if ok else
                               "Claude will be BLOCKED - %s%s" % (reason, fix)))
            ok, violations = sc._check(os.getcwd())
            if ok:
                OK("settings-consistency: OTEL attributes match this machine")
            for v in violations:
                ER("settings-consistency: Claude will be BLOCKED - %s -> run set-vertex-project here" % v)
    cl = os.path.join(os.getcwd(), ".claude")
    if os.path.isdir(cl):
        wt = os.path.join(cl, "_doctor_write_test")
        try:
            open(wt, "w").write("x"); os.remove(wt); OK("write test: .claude is writable")
        except Exception:
            ER("write test FAILED: cannot write in .claude")
    else:
        DS(".claude not present yet (set-vertex-project will create it)")


def sec_adc():
    HDR("6. GCP ADC - global + per-dir (quota == project + token mint)")
    sl = _settings_local()
    env = sl.get("env") or {}
    project = (env.get("ANTHROPIC_VERTEX_PROJECT_ID") or "").strip()
    gac = (env.get("GOOGLE_APPLICATION_CREDENTIALS") or "").strip()
    auto = bool(sl.get("gcpAuthRefresh"))    # gcp-auto: on -> Claude uses the per-dir ADC; off -> the global
    DS("gcp-auto (gcpAuthRefresh) = %s -> Claude uses the %s ADC" %
       ("on" if auto else "off", "per-dir (local)" if auto else "global"))
    if not project:
        WR("no ANTHROPIC_VERTEX_PROJECT_ID in this folder -> run set-vertex-project first")
        return
    h = _isp_hooks()
    if not h or not hasattr(h, "adc_check"):
        ER("cannot import isp_hooks.adc_check from %s -> hooks are broken (python/deploy issue)" % HOOKS)
        return
    # same verdict and messages as set-vertex-project (isp_hooks.adc_check)
    for level, msg in h.adc_check(project, auto, gac or None):
        {"ok": OK, "warn": WR}.get(level, ER)(msg)


_VIDIMA_MSG = {
    "invalid": "project not enabled for you or budget exhausted",
    "mismatch": "the service answers for a different project",
    "unknown": "project does not exist (404)",
    "denied": "access denied by the service (credential/authorization)",
}


def sec_chap0():
    HDR("7. CHAP0 - token, project list (as set-vertex-project), project validation (as project-vidima)")
    h = _isp_hooks()
    here = os.path.dirname(os.path.abspath(__file__))
    svp = _load_module("svp", os.path.join(here, "set-vertex-project.py"))
    vid = _load_module("vidima", os.path.join(HOOKS, "project-vidima.py"))
    if not h or not svp or not vid:
        ER("cannot load set-vertex-project / project-vidima -> incomplete deploy (redeploy)")
        return
    base = svp._resolve_api_base()
    if not base:
        ER("CHAP0 service not configured (chap0-gateway.json missing, no section for version.json env, or "
           "placeholder URL) -> no project list, set-vertex-project asks the project as free text")
        return
    DS("service = %s" % base)
    try:
        tok = svp.chap0_auth.get_token()
    except Exception as e:
        code = getattr(e, "code", None)
        ER("CHAP0 token NOT obtained (%s) -> no project list, project-vidima blocks" %
           ("token endpoint answered HTTP %s" % code if code else svp._fetch_error_reason(e, 4.0)))
        return
    if not tok:
        ER("CHAP0 token NOT obtained: chap0-gateway.json incomplete for this env (oauth_url/client_id/"
           "client_secret/scope) -> redeploy the package")
        return
    OK("CHAP0 token obtained")
    uid, _src, _steps = h.resolve_userid_detail()
    if not uid:
        ER("no matricola (section 1) -> cannot query the projects")
        return
    try:
        projects = svp._fetch_projects(base, uid)
    except Exception as e:      # 403 propagated by _fetch_projects
        ER("project list refused (%s) -> you are not authorized on the service" % e)
        projects = None
    else:
        if projects is None:
            ER("project list not received: %s" % svp._FETCH_ERR)
        elif not projects:
            WR("no project enabled for %s (only OPEX is possible)" % uid)
        else:
            OK("%d project(s) enabled for %s" % (len(projects), uid))
    isp = _otel(_settings_local().get("env") or {}).get("isp.project_id") or ""
    if not isp:
        DS("no isp.project_id in this folder -> nothing to validate (run set-vertex-project here)")
        return
    state, data = vid._validate(base, isp, uid, 4.0)
    if state == "ok":
        OK("project %s valid (residual budget EUR %s)" % (isp, (data or {}).get("residual_budget_eur", "?")))
    elif state == "unreachable":
        WR("project %s not validated: service unreachable (project-vidima lets Claude run: fail-open)" % isp)
    else:
        why = (data or {}).get("reason") or _VIDIMA_MSG.get(state, state)
        ER("project %s: %s -> project-vidima BLOCKS Claude; choose a valid project with set-vertex-project"
           % (isp, why))


def sec_vpn():
    HDR("8. VPN ISPers (authoritative verdict via vpn-guard.detect_state)")
    h = _isp_hooks()
    cfg = None
    if h and hasattr(h, "load_vpn_gate"):
        try:
            cfg = h.load_vpn_gate()
        except Exception as e:
            WR("cannot load vpnGate (%s)" % e)
    if cfg:
        DS("expected: tunnelSubnets=%s  dnsSuffix=%s  enabled=%s" %
           (cfg.get("tunnelSubnets"), cfg.get("dnsSuffix"), cfg.get("enabled")))
        vg = _load_module("vpnguard", os.path.join(HOOKS, "vpn-guard.py"))
        if vg and hasattr(vg, "detect_state"):
            try:
                st = vg.detect_state(cfg)
                (OK if st == "up" else (WR if st == "inconclusive" else ER))("detect_state() -> %s" % st)
            except Exception as e:
                WR("detect_state error: %s" % e)
        else:
            WR("vpn-guard.py NOT deployed -> no authoritative verdict (redeploy the package); raw evidence below")
    else:
        WR("vpnGate not loadable (isp_hooks too old / incomplete deploy) -> redeploy; raw evidence below")
    # evidence: which net am I on?
    _net = _trusted("ipconfig" if IS_WIN else "ifconfig")
    rc, out = _run([_net, "/all"] if IS_WIN else [_net], 6) if _net else (1, "")
    if not _net:
        DS("network evidence skipped: %s not trusted (see section 2)" % ("ipconfig" if IS_WIN else "ifconfig"))
    ips = sorted(set(re.findall(r"\b(?:10|172|192)\.\d{1,3}\.\d{1,3}\.\d{1,3}\b", out or "")))
    DS("private IPv4 on this host: %s" % (", ".join(ips) or "(none)"))
    suf = (cfg or {}).get("dnsSuffix") or ""
    if suf:
        DS("dnsSuffix '%s' present in net output: %s" % (suf, "yes" if suf.lower() in (out or "").lower() else "no"))
    subs = (cfg or {}).get("tunnelSubnets") or []
    if ips and subs:
        try:
            import ipaddress
            nets = [ipaddress.ip_network(s, strict=False) for s in subs]
            inside = [ip for ip in ips if any(ipaddress.ip_address(ip) in n for n in nets)]
            if inside:
                OK("tunnel IP in an expected subnet: %s" % ", ".join(inside))
            else:
                WR("no IP in %s -> you may be on a DIFFERENT VPN pool (add its subnet to vpnGate.tunnelSubnets, cyber)" % subs)
        except Exception:
            pass
    if not IS_WIN:
        _sc = _trusted("scutil")
        rc, dns = _run([_sc, "--dns"], 5) if _sc else (1, "")
        doms = sorted(set(re.findall(r"search domain\[\d+\]\s*:\s*(\S+)", dns or "")))
        DS("DNS search domains: %s" % (", ".join(doms) or "(none)"))
        DS("note: on macOS vpn-guard matches the tunnel IP (ifconfig has no DNS); the dnsSuffix criterion is Windows-only")
    state_file = os.path.join(os.path.expanduser("~"), ".claude", ".vpn-state")
    try:
        with open(state_file, encoding="utf-8") as _sf:
            DS("last hook state (~/.claude/.vpn-state) = %s" % _sf.read().strip())
    except Exception:
        DS("~/.claude/.vpn-state not written yet")


def sec_git():
    HDR("9. git (from the system-folder allowlist, as the hooks) / ISP marketplace access")
    h = _isp_hooks()
    if h and not hasattr(h, "trusted_git"):          # hooks of an older package: they still use git from PATH
        git = _which("git")
        (OK if git else ER)("git = %s (from PATH: the installed hooks predate the allowlist)" % (git or "MISSING"))
    else:
        git = h.trusted_git() if h else None
    if not git:
        ER("git not found in the system folders (allowlist of isp_hooks.trusted_git) -> secret-scan blocks "
           "commits; install git in the standard path")
        return
    OK("git = %s" % git)
    market = "https://bitbucket.intesasanpaolo.com/scm/isp-code-assistant/claude-marketplace.git"
    env = dict(os.environ); env["GIT_TERMINAL_PROMPT"] = "0"
    try:
        p = subprocess.run([git, "ls-remote", "--symref", market, "HEAD"],
                           capture_output=True, text=True, timeout=12, env=env)
        if p.returncode == 0:
            OK("marketplace reachable + credentials cached (silent clone will work)")
        else:
            WR("marketplace clone would need credentials (not cached) -> run set-vertex-project and answer Y, "
               "or: git ls-remote %s" % market)
    except Exception as e:
        WR("marketplace check error: %s" % e)


def _host(url):
    m = re.search(r"https?://([^/:]+)", url or "")
    return m.group(1) if m else ""


def _package_hosts():
    """Hosts the installed package talks to: marketplace, Vertex (via Apigee), telemetry, CHAP0 + its
    token endpoint. Order kept, duplicates removed."""
    hosts = ["bitbucket.intesasanpaolo.com"]
    vx = (_load_json(os.path.join(MSD, "10-vertex.json")) or {}).get("env") or {}
    tel = (_load_json(os.path.join(MSD, "21-telemetry.json")) or {}).get("env") or {}
    urls = [vx.get("ANTHROPIC_VERTEX_BASE_URL"), tel.get("OTEL_EXPORTER_OTLP_ENDPOINT")]
    gw = _load_json(os.path.join(CONFIG, "chap0-gateway.json")) or {}
    env = ((_load_json(os.path.join(CONFIG, "version.json")) or {}).get("env") or "").lower()
    sec = gw.get(env) if isinstance(gw.get(env), dict) else {}
    urls += [sec.get("api_base_url"), sec.get("oauth_url")]     # CHAP0 service + its token endpoint
    for u in urls:
        hh = _host(u)
        if hh:
            hosts.append(hh)
    return list(dict.fromkeys(hosts))


def sec_net():
    HDR("10. network reachability (:443, native sockets - no curl)")
    for hh in _package_hosts():
        try:
            socket.create_connection((hh, 443), timeout=4).close()
            OK("%s:443 reachable" % hh)
        except Exception as e:
            ER("%s:443 UNREACHABLE (%s) -> check VPN/proxy/firewall" % (hh, type(e).__name__))


def _tls_peer(host):
    """Certificate served by host:443, read WITHOUT verifying (inspection only, nothing is sent):
    {'subject','issuer','not_after'} (CNs, notAfter as epoch) or {'error': ...}."""
    import ssl
    import tempfile
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        with socket.create_connection((host, 443), timeout=5) as s:
            with ctx.wrap_socket(s, server_hostname=host) as t:
                der = t.getpeercert(binary_form=True)
        f = tempfile.NamedTemporaryFile("w", suffix=".pem", delete=False)
        try:
            f.write(ssl.DER_cert_to_PEM_cert(der))
            f.close()
            d = ssl._ssl._test_decode_cert(f.name)      # stdlib decoder (no third-party package)
        finally:
            os.remove(f.name)
        cn = lambda name: next((v for rdn in name for k, v in rdn if k == "commonName"), "?")
        return {"subject": cn(d.get("subject", ())), "issuer": cn(d.get("issuer", ())),
                "not_after": ssl.cert_time_to_seconds(d["notAfter"])}
    except Exception as e:
        return {"error": "%s: %s" % (type(e).__name__, str(e)[:120])}


def _ca_in_os_store(cn):
    """Where a CA with this common name is in the OS trust store: list of locations ([] = absent,
    None = could not check). macOS: System keychain (admin/MDM), system roots, login keychain.
    Windows: LocalMachine/CurrentUser Root and intermediate (CA) stores."""
    if IS_WIN:
        # cn comes from a remote (unverified) certificate: it NEVER enters the command text (PowerShell
        # also treats typographic quotes U+2018..U+201B as quotes); it is passed in an environment
        # variable of the child process and compared as data (exact match on the CN= part).
        ps = ("$n=$env:ISP_DOCTOR_CN; foreach($s in 'LocalMachine\\Root','LocalMachine\\CA','CurrentUser\\Root',"
              "'CurrentUser\\CA'){ if (Get-ChildItem \"Cert:\\$s\" -ErrorAction SilentlyContinue | Where-Object {"
              " ($_.Subject -split ',\\s*') -contains ('CN=' + $n) }) { $s } }")
        try:
            p = subprocess.run([_trusted("powershell") or "powershell-not-trusted", "-NoProfile",
                                "-NonInteractive", "-Command", ps], capture_output=True, text=True, timeout=15,
                               env=dict(os.environ, ISP_DOCTOR_CN=cn), encoding="utf-8", errors="replace")
            rc, out = p.returncode, (p.stdout or "") + (p.stderr or "")
        except Exception as e:
            rc, out = -1, str(e)
        if rc != 0:
            return None
        return [l.strip() for l in out.splitlines() if l.strip() in
                ("LocalMachine\\Root", "LocalMachine\\CA", "CurrentUser\\Root", "CurrentUser\\CA")]
    found = []
    for label, kc in (("System keychain", "/Library/Keychains/System.keychain"),
                      ("system roots", "/System/Library/Keychains/SystemRootCertificates.keychain"),
                      ("login keychain", os.path.expanduser("~/Library/Keychains/login.keychain-db"))):
        if os.path.exists(kc):
            rc, _ = _run(["/usr/bin/security", "find-certificate", "-c", cn, kc], 8)
            if rc == 0:
                found.append(label)
    return found


_PEM_RE = re.compile(r"-----BEGIN CERTIFICATE-----.+?-----END CERTIFICATE-----", re.S)


def _pem_certs(path):
    """Certificates in a PEM bundle: [{'subject','issuer','not_after'}] (CNs, epoch), or raises."""
    import ssl
    import tempfile
    with open(path, encoding="utf-8", errors="replace") as f:
        blocks = _PEM_RE.findall(f.read())
    out = []
    cn = lambda name: next((v for rdn in name for k, v in rdn if k == "commonName"), "?")
    for b in blocks:
        t = tempfile.NamedTemporaryFile("w", suffix=".pem", delete=False)
        try:
            t.write(b + "\n")
            t.close()
            d = ssl._ssl._test_decode_cert(t.name)
            out.append({"subject": cn(d.get("subject", ())), "issuer": cn(d.get("issuer", ())),
                        "not_after": ssl.cert_time_to_seconds(d["notAfter"])})
        except Exception:
            out.append({"subject": "(unreadable certificate)", "issuer": "?", "not_after": 0})
        finally:
            os.remove(t.name)
    return out


def _cert_env():
    """CLAUDE_CODE_CERT_STORE / NODE_EXTRA_CA_CERTS as Claude Code sees them: {var: [(source, value)]},
    highest precedence first (managed > folder settings.local.json > folder settings.json >
    ~/.claude/settings.json > environment of THIS shell)."""
    srcs = []
    managed = dict((_load_json(os.path.join(CC, "managed-settings.json")) or {}).get("env") or {})
    for fn in (sorted(os.listdir(MSD)) if os.path.isdir(MSD) else []):
        managed.update((_load_json(os.path.join(MSD, fn)) or {}).get("env") or {})
    srcs.append(("managed", managed))
    for label, p in (("folder .claude/settings.local.json", os.path.join(os.getcwd(), ".claude", "settings.local.json")),
                     ("folder .claude/settings.json", os.path.join(os.getcwd(), ".claude", "settings.json")),
                     ("~/.claude/settings.json", os.path.join(os.path.expanduser("~"), ".claude", "settings.json"))):
        srcs.append((label, (_load_json(p) or {}).get("env") or {}))
    srcs.append(("environment of this shell", os.environ))
    return {v: [(s, e[v]) for s, e in srcs if e.get(v)] for v in ("CLAUDE_CODE_CERT_STORE", "NODE_EXTRA_CA_CERTS")}


def _machine_context():
    """ssl context trusting ONLY the CAs installed on the machine by an administrator: Windows
    LocalMachine Root + CA stores; macOS System keychain + system roots. Not the user store
    (CurrentUser, login keychain) nor NODE_EXTRA_CA_CERTS. Returns (ctx, error)."""
    import ssl
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    if IS_WIN:
        ps = ("Get-ChildItem Cert:\\LocalMachine\\Root, Cert:\\LocalMachine\\CA -ErrorAction SilentlyContinue | "
              "ForEach-Object { '-----BEGIN CERTIFICATE-----'; [Convert]::ToBase64String($_.RawData, "
              "'InsertLineBreaks'); '-----END CERTIFICATE-----' }")
        _ps = _trusted("powershell")
        rc, pem = _run([_ps, "-NoProfile", "-NonInteractive", "-Command", ps], 30) if _ps else (-1, "")
    else:
        _sec = _trusted("security")
        rc, pem = (-1, "") if not _sec else _run([_sec, "find-certificate", "-a", "-p", "/Library/Keychains/System.keychain",
                        "/System/Library/Keychains/SystemRootCertificates.keychain"], 30)
    blocks = "\n".join(_PEM_RE.findall(pem or ""))
    if not blocks:
        return None, "machine CA store not readable"
    try:
        ctx.load_verify_locations(cadata=blocks)
    except Exception:
        loaded = 0
        for b in _PEM_RE.findall(pem or ""):          # skip single unparseable certificates
            try:
                ctx.load_verify_locations(cadata=b)
                loaded += 1
            except Exception:
                pass
        if not loaded:
            return None, "machine CA store not loadable"
    return ctx, None


def _claude_context(store, extra):
    """ssl context trusting what Claude Code trusts on this machine: with 'system' in
    CLAUDE_CODE_CERT_STORE the OS store as the user sees it (Windows ROOT+CA, machine and user;
    macOS System keychain + system roots + login keychain), plus NODE_EXTRA_CA_CERTS. The bundled
    Mozilla set is approximated by the OS public roots. Returns (ctx, error)."""
    import ssl
    use_system = "system" in (store or "").lower()
    ctx = ssl.create_default_context() if (use_system and IS_WIN) else ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    if use_system and not IS_WIN:
        kcs = ["/Library/Keychains/System.keychain", "/System/Library/Keychains/SystemRootCertificates.keychain"]
        login = os.path.expanduser("~/Library/Keychains/login.keychain-db")
        if os.path.exists(login):
            kcs.append(login)
        rc, pem = _run(["/usr/bin/security", "find-certificate", "-a", "-p"] + kcs, 30)
        blocks = "\n".join(_PEM_RE.findall(pem or ""))
        if blocks:
            try:
                ctx.load_verify_locations(cadata=blocks)
            except Exception:
                for b in _PEM_RE.findall(pem or ""):      # one unparseable keychain cert must not drop all
                    try:
                        ctx.load_verify_locations(cadata=b)
                    except Exception:
                        pass
    if extra and os.path.isfile(extra):
        try:
            ctx.load_verify_locations(cafile=extra)
        except Exception:
            pass                     # reported separately (Claude Code cannot load it either)
    return ctx, None


def _verify(ctx, host):
    """Real TLS handshake with hostname + chain verification against ctx: (True, '') or (False, reason);
    (None, reason) when the host cannot be reached at all."""
    import ssl
    try:
        with socket.create_connection((host, 443), timeout=5) as s:
            with ctx.wrap_socket(s, server_hostname=host):
                return True, ""
    except ssl.SSLCertVerificationError as e:
        return False, getattr(e, "verify_message", "") or str(e)[:120]
    except ssl.SSLError as e:
        return False, str(e)[:120]
    except Exception as e:
        return None, type(e).__name__


def _why(reason):
    r = (reason or "").lower()
    if "local issuer" in r or "unable to get issuer" in r:
        return "issuing CA not among the CAs Claude Code trusts here, or chain incomplete"
    if "self-signed" in r or "self signed" in r:
        return "the root CA of the chain is not trusted"
    if "expired" in r:
        return "a certificate of the chain has expired"
    if "hostname" in r or "ip address mismatch" in r:
        return "the certificate is not issued for this host name"
    return reason


def sec_tls():
    HDR("11. TLS: would Claude Code connect to each package endpoint? (same CAs Claude Code trusts)")
    # Claude Code trusts its bundled Mozilla CAs + the OS store (CLAUDE_CODE_CERT_STORE, default
    # bundled,system) + NODE_EXTRA_CA_CERTS. Verdict = a real TLS verification with those same sources;
    # when it passes, also with ONLY the admin-installed machine CAs (a pass that depends on the user's
    # own CAs is a warning).
    env = _cert_env()
    for var, default in (("CLAUDE_CODE_CERT_STORE", "bundled,system (default)"), ("NODE_EXTRA_CA_CERTS", "(not set)")):
        vals = env[var]
        DS("%s = %s   [%s]" % (var, vals[0][1] if vals else default, vals[0][0] if vals else "default"))
    store = env["CLAUDE_CODE_CERT_STORE"][0][1] if env["CLAUDE_CODE_CERT_STORE"] else "bundled,system"
    if "system" not in store.lower():
        ER("CLAUDE_CODE_CERT_STORE=%s: Claude Code does not use the OS trust store" % store)
    extra = env["NODE_EXTRA_CA_CERTS"][0][1] if env["NODE_EXTRA_CA_CERTS"] else ""
    extra_cns = set()
    if extra and not os.path.isfile(extra):
        WR("NODE_EXTRA_CA_CERTS file MISSING: %s (Claude Code cannot load it)" % extra)
    elif extra:
        try:
            extra_cns = set(c["subject"] for c in _pem_certs(extra))
        except Exception:
            extra_cns = set()
        if not extra_cns:
            WR("NODE_EXTRA_CA_CERTS %s contains no PEM certificate (Claude Code loads nothing from it)" % extra)
    cctx, _ = _claude_context(store, extra)
    mctx, merr = _machine_context()
    store_cache = {}

    def where(iss):
        if iss not in store_cache:
            store_cache[iss] = _ca_in_os_store(iss)
        w = store_cache[iss]
        return "not checkable" if w is None else (", ".join(w) or "nowhere")

    for hh in _package_hosts():
        # the certificate details are information only: the verification below ALWAYS runs
        p = _tls_peer(hh)
        if "error" in p:
            WR("%s: certificate details not readable (%s)" % (hh, p["error"]))
            iss, days, exp = "?", 0, "expiry unknown"
        else:
            iss = p["issuer"]
            days = int((p["not_after"] - time.time()) // 86400)
            exp = "expires in %d days" % days
        ok, reason = _verify(cctx, hh)
        if ok is None:
            WR("%s: not reachable for the verification (%s)" % (hh, reason))
            continue
        if not ok:
            ER("%s: Claude Code would FAIL ('SSL certificate verification failed') - %s [issued by '%s', "
               "%s]" % (hh, _why(reason), iss, exp))
            DS("   CA '%s' found in: %s; NODE_EXTRA_CA_CERTS: %s" % (
                iss, where(iss), "present" if iss in extra_cns else ("absent" if extra else "not set")))
            continue
        mok = _verify(mctx, hh)[0] if mctx is not None else None
        if mok:
            machine = [w for w in (store_cache.get(iss) or _ca_in_os_store(iss) or [])
                       if w.startswith("LocalMachine") or w in ("System keychain", "system roots")]
            (WR if days < 30 else OK)("%s: OK - issued by '%s' (%s), %s" % (
                hh, iss, ", ".join(machine) if machine else "chained to a machine root", exp))
        elif mok is False:
            WR("%s: OK for Claude Code only thanks to CAs NOT installed by an administrator - issued by '%s', "
               "found in: %s; NODE_EXTRA_CA_CERTS: %s" % (
                   hh, iss, where(iss), "present" if iss in extra_cns else ("absent" if extra else "not set")))
        else:
            (WR if days < 30 else OK)("%s: OK - issued by '%s', %s (machine CA store not "
                                      "readable: %s)" % (hh, iss, exp, merr))


def sec_remedy():
    HDR("remedy quick-ref")
    DS("- SSO/Kerberos (mac): renew ISP password if expired; PSSO Authenticate/Repair; klist must show U######@SEDE")
    DS("- ADC missing/expired: gcloud auth application-default login   (or gcloud-reauth)")
    DS("- quota mismatch / no settings / isp.pkg_version != package: run set-vertex-project in this folder")
    DS("- `claude` on PATH is not the authorized binary: remove it, start the one in the package bin folder")
    DS("- VPN down but connected: your tunnel subnet may differ from vpnGate.tunnelSubnets -> raise to cyber")
    DS("- managed config missing: redeploy the managed package")


def main():
    global SUMMARY
    if "--summary" in sys.argv[1:]:
        SUMMARY = True
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    if not SUMMARY:
        print(_c("=" * 62, "1;36"))
        print(_c(" set-vertex-project doctor - %s" % ("Windows" if IS_WIN else "macOS"), "1;36"))
        print(_c("=" * 62, "1;36"))
        # the interpreter matters: a personal Python (Homebrew, pyenv, python.org) has its own CA bundle
        # without the ISP CA -> CHAP0 calls fail with a certificate error, shown as "service unreachable"
        print("   python of this doctor: %s (%s)" % (sys.executable, sys.version.split()[0]))
    h = _isp_hooks()
    if h and not hasattr(h, "resolve_userid_detail"):
        v = (_load_json(os.path.join(CONFIG, "version.json")) or {}).get("version") or "?"
        msg = ("this doctor is newer than the installed package (%s): sections that reuse the hook "
               "functions cannot run. Use the doctor shipped with the installed package." % v)
        if not SUMMARY:
            print("   " + _c(msg, "1;33"))
    fns = [sec_identity, sec_deps, sec_managed, sec_binary, sec_settings, sec_adc, sec_chap0, sec_vpn,
           sec_git, sec_net, sec_tls]
    if not SUMMARY:
        fns.append(sec_remedy)
    for fn in fns:
        try:
            fn()
        except Exception as e:
            ER("section error: %s" % e)
    if SUMMARY:
        _flush()
        _tag = {"ok": "OK  ", "warn": "WARN", "err": "FAIL"}
        _col = {"ok": "1;32", "warn": "1;33", "err": "1;31"}
        for title, sev in _sec["rows"]:
            print("%s  %s" % (_c(_tag[sev], _col[sev]), title))
    else:
        print("")


if __name__ == "__main__":
    main()
