@echo off
REM get — GET-only curl replacement (wraps get.py). ISP-internal hosts only.
REM Usage: get <url> [-H "K: V"] [-i] [-m sec]
REM Python from the same admin-only allowlist as the hooks (find-python.cmd), never from PATH.
call "%~dp0..\hooks\find-python.cmd"
if not defined PY (
  echo get: no Python in C:\Program Files\Python31x - managed deploy prerequisite 1>&2
  exit /b 1
)
"%PY%" -E -S -B "%~dp0get.py" %*
