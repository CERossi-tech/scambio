"""ISP managed status line.

Lines 1-4 (MANDATORY BASE, managed - not removable by the dev):
    L1: usr <developer.id>, vpn-ispers(ivnt:on/off ip:on/off), pkg <isp.pkg_version>, cc <version>, model <model>, ctx N%
    L2: gcp-auto on/off, gcp.acct <account>, gcp <gcp.project_id>
    L3: isp.prj <isp.project_id>, <descrizione>, <NN>% budget   (GREEN ok / RED blocking / plain otherwise)
    L4: wpd <workspace.project_dir = launch root, tail sized to the window width>
vars read from <project_dir>/.claude/settings.local.json (launch dir from workspace.project_dir,
STABLE across cd; same file as the gate); wpd shows workspace.project_dir (the project root). + JSON on stdin.
The ctx label is GREEN <50%, amber 50-85%, RED >85% (context-window usage).

Following lines (dev EXTRA, optional): the dev can append lines WITHOUT removing the base.
Resolution order (first non-empty wins):
  1. `statuslineExtra` (a shell command string) in ~/.claude/settings.json (per-user global)
  2. static file ~/.claude/statusline-extra.txt
The command (1) is EXECUTED (shell, cwd=project_dir, 5s timeout) and its stdout is appended
- mirrors Claude Code's native `statusLine` command (which the managed drop-in overrides), so the
dev regains dynamic extra lines (e.g. git branch). Read ONLY from the per-user global settings,
NOT from the project's .claude/settings.local.json: a repo-shipped settings.local.json carrying a
hostile `statuslineExtra` would otherwise be arbitrary shell exec on every refresh. Config lives in
the dev's own (user-global) file; failures/timeouts are swallowed (the base must never break).

No jq: JSON via stdlib. Deployed in scripts/, invoked by the .cmd/.sh wrapper.
Amber labels (NO_COLOR to disable). gcp is a plain label (no connection coloring - the
ADC-expiry signal is the check-gcp-token hook warning, not the status line).
"""
import json
import os
import shutil
import subprocess
import sys


def _term_cols(d):
    """Available window width, for sizing the dir field. Prefer a width provided on stdin,
    then $COLUMNS, then the terminal size, then 80 as a safe default."""
    for v in (d.get("width"), d.get("cols"), (d.get("terminal") or {}).get("width")):
        try:
            if v and int(v) > 0:
                return int(v)
        except Exception:
            pass
    try:
        c = int(os.environ.get("COLUMNS") or 0)
        if c > 0:
            return c
    except Exception:
        pass
    try:
        return shutil.get_terminal_size((80, 20)).columns
    except Exception:
        return 80


def main():
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")  # for the colored label
    except Exception:
        pass
    try:
        d = json.load(sys.stdin)
    except Exception:
        d = {}
    ws = d.get("workspace") or {}
    proj = ws.get("project_dir") or ws.get("current_dir") or os.getcwd()  # project/launch root: STABLE across cd
    model = (d.get("model") or {}).get("display_name") or "?"
    model = model.replace("(1M context)", "(1M)")
    version = d.get("version") or "?"
    pct = (d.get("context_window") or {}).get("used_percentage")

    dev = gcp = isp = pkg = acct = "-"
    gcp_auto = "off"
    try:
        with open(os.path.join(proj, ".claude", "settings.local.json"), encoding="utf-8") as f:
            _slj = json.load(f)
        env = _slj.get("env") or {}
        gcp_auto = "on" if _slj.get("gcpAuthRefresh") else "off"   # automated GCP re-auth cycle
        gcp = env.get("ANTHROPIC_VERTEX_PROJECT_ID") or "-"
        for part in (env.get("OTEL_RESOURCE_ATTRIBUTES") or "").split(","):
            k, _, v = part.partition("=")
            k = k.strip()
            v = v.strip()
            if k == "developer.id" and v:
                dev = v
            elif k == "isp.project_id" and v:
                isp = v
            elif k == "isp.pkg_version" and v:
                pkg = v
        # GCP authenticated account — priority order:
        # 0. .claude/gcp/.identity: the AUTHORITATIVE ADC identity (email) resolved by
        #    check-gcp-token via tokeninfo. Cheap (one file read) and correct — the true
        #    identity Claude uses, catching the case where gcloud config account diverges
        #    from the ADC identity (e.g. application-default login as another account).
        # 1. GOOGLE_APPLICATION_CREDENTIALS ADC JSON account/client_email (empty for
        #    authorized_user → falls through; set for service-account keys).
        # 2. gcloud active config [core] account (proxy; ADC account field is often empty).
        # 3. Default OS ADC path → ADC JSON account/client_email (last resort).
        _gcloud_root = (os.path.join(os.environ.get("APPDATA", ""), "gcloud")
                        if sys.platform == "win32"
                        else os.path.expanduser("~/.config/gcloud"))
        _gac = env.get("GOOGLE_APPLICATION_CREDENTIALS")
        if _gac:  # 0. authoritative identity from check-gcp-token (.identity next to the ADC copy)
            try:
                with open(os.path.join(os.path.dirname(_gac), ".identity"), encoding="utf-8") as _f:
                    acct = (json.load(_f).get("email") or "").strip() or acct
            except Exception:
                pass
        if acct == "-" and _gac:  # 1. ADC file account/client_email (empty for authorized_user)
            try:
                with open(_gac, encoding="utf-8") as _f:
                    _adc = json.load(_f)
                acct = _adc.get("account") or _adc.get("client_email") or "-"
            except Exception:
                pass
        if acct == "-":  # 2. gcloud CLI config: [core] account =
            try:
                with open(os.path.join(_gcloud_root, "active_config"), encoding="utf-8") as _acf:
                    _cfg_name = _acf.read().strip()
                _cfg_path = os.path.join(_gcloud_root, "configurations", "config_" + _cfg_name)
                with open(_cfg_path, encoding="utf-8") as _cff:
                    for _line in _cff:
                        _k, _, _v = _line.partition("=")
                        if _k.strip() == "account" and _v.strip():
                            acct = _v.strip()
                            break
            except Exception:
                pass
        if acct == "-":  # default ADC path (service accounts use client_email)
            try:
                _adc_path = os.path.join(_gcloud_root, "application_default_credentials.json")
                with open(_adc_path, encoding="utf-8") as _f:
                    _adc = json.load(_f)
                acct = _adc.get("account") or _adc.get("client_email") or "-"
            except Exception:
                pass
    except Exception:
        pass

    # Amber phosphor (#FFB000) bold -> "old terminal / glow" look. ONLY the labels are
    # colored; values keep the default color. NO_COLOR disables all coloring.
    amber = not os.environ.get("NO_COLOR")

    def lab(x):
        return "\033[1;38;2;255;176;0m" + x + "\033[0m" if amber else x

    # Managed base lines. Separator ", " (compact). L1 identity/environment; L2 session.
    SEP = ", "
    # L1 = session: cc, model, ctx
    try:
        pctv = int(float(pct)) if pct is not None else None
    except Exception:
        pctv = None
    # VPN ISPers state (written by the vpn-guard hook to ~/.claude/.vpn-state; cheap file read).
    # New format: JSON {"ip":, "ivnt":, "state":} - ip = tunnel IP/DNS match, ivnt = native
    # Ivanti/Pulse client signal (scutil/Get-NetAdapter), state = combined (up if either is up).
    # Falls back to a legacy nude string (pre-upgrade vpn-guard, mirrored into ip/ivnt for display),
    # or "?" if the file is missing/unparsable/unknown (today's behavior).
    def _vpn_onoff(v):
        if v == "up":
            return "on"
        if v in ("down", "inconclusive"):
            return "off"
        return "?"

    try:
        with open(os.path.join(os.path.expanduser("~"), ".claude", ".vpn-state"), encoding="utf-8") as _vf:
            _vraw = _vf.read().strip()
    except Exception:
        _vraw = ""
    _vip = _vivnt = _vstate = None
    if _vraw:
        try:
            _vjd = json.loads(_vraw)
            if isinstance(_vjd, dict):
                _vstate, _vip, _vivnt = _vjd.get("state"), _vjd.get("ip"), _vjd.get("ivnt")
        except Exception:
            if _vraw in ("up", "down", "inconclusive"):          # legacy nude-string format
                _vstate = _vip = _vivnt = _vraw
    if _vstate not in ("up", "down", "inconclusive"):
        vpn_val = lab("vpn-ispers ") + "?"
    else:
        _vcolor = "\033[1;32m" if _vstate == "up" else "\033[1;31m"
        _vlabel = (_vcolor + "vpn-ispers" + "\033[0m") if amber else "vpn-ispers"
        vpn_val = _vlabel + "(ivnt:%s ip:%s)" % (_vpn_onoff(_vivnt), _vpn_onoff(_vip))
    seg = [lab("usr ") + dev, vpn_val, lab("pkg ") + pkg, lab("cc ") + version, lab("model ") + model]
    if pctv is not None:
        # ctx label colored by context usage: <50% green, 50-85% amber, >85% red.
        if not amber:
            ctx_lab = "ctx "
        elif pctv > 85:
            ctx_lab = "\033[1;31mctx \033[0m"
        elif pctv < 50:
            ctx_lab = "\033[1;32mctx \033[0m"
        else:
            ctx_lab = lab("ctx ")
        seg.append(ctx_lab + "%d%%" % pctv)
    line1 = SEP.join(seg)

    # L2 = identity/environment: gcp-auto, gcp.acct, gcp  (isp.prj moved to its own line below)
    gauto_val = ("\033[1;32mon\033[0m" if amber else "on") if gcp_auto == "on" else "off"
    line2 = SEP.join([lab("gcp-auto ") + gauto_val, lab("gcp.acct ") + acct, lab("gcp ") + gcp])

    # L3 = ISP project on its OWN line: isp.prj <progetto> <descrizione> €<residuo>.
    # Vidima state (project-vidima hook -> <proj>/.claude/.vidima-state): GREEN when ok, RED when
    # blocking (unknown/invalid/empty/mismatch/denied -> all halt every turn), plain otherwise.
    try:
        with open(os.path.join(proj, ".claude", ".vidima-state"), encoding="utf-8") as _vf:
            _vd = json.load(_vf)
    except Exception:
        _vd = {}
    _vstate = _vd.get("state")
    isp_disp = isp if isp else "(none)"
    if amber and _vstate == "ok":
        isp_val = "\033[1;32m" + isp_disp + "\033[0m"
    elif amber and _vstate in ("unknown", "invalid", "empty", "mismatch", "denied"):
        isp_val = "\033[1;31m" + isp_disp + "\033[0m"
    else:
        isp_val = isp_disp
    isp_line = lab("isp.prj ") + isp_val
    _desc = _vd.get("title") or _vd.get("reason")
    if _desc:
        isp_line += ", " + _desc
    _res = _vd.get("residual_eur")
    _tot = _vd.get("total_eur")
    try:
        if _res is not None and _tot:                       # % budget = residuo / totale
            isp_line += ", %.0f%% budget" % (float(_res) / float(_tot) * 100.0)
    except Exception:
        pass

    # L4 = workspace.project_dir (launch root Claude is confined to) on its own line, tail sized to width.
    budget = _term_cols(d) - len("wpd ") - 1
    if budget < 10:
        budget = 10
    wdir = proj if len(proj) <= budget else "..." + proj[-(budget - 3):]
    line3 = lab("wpd ") + wdir

    out = [line1, line2, isp_line, line3]

    # --- dev EXTRA line(s), appended after the managed base (never replaces it) ---
    def _cfg_str(path, key):
        try:
            with open(path, encoding="utf-8") as f:
                v = json.load(f).get(key)
            return v.strip() if isinstance(v, str) else ""
        except Exception:
            return ""

    extra = ""
    # 1: a user COMMAND (mirrors native statusLine). Read ONLY from the per-user global
    # ~/.claude/settings.json, NOT the project's settings.local.json — a repo-shipped
    # settings.local.json with a hostile statuslineExtra would otherwise be arbitrary shell exec.
    cmd = _cfg_str(os.path.join(os.path.expanduser("~"), ".claude", "settings.json"), "statuslineExtra")
    if cmd:
        try:
            r = subprocess.run(cmd, shell=True, capture_output=True, text=True,
                               timeout=5, cwd=proj)
            extra = (r.stdout or "").rstrip("\n")
        except Exception:
            extra = ""   # failure/timeout -> no extra line, base stays intact
    # 2: static file fallback (only if no command output).
    if not extra.strip():
        try:
            with open(os.path.join(os.path.expanduser("~"), ".claude", "statusline-extra.txt"),
                      encoding="utf-8") as f:
                extra = f.read().rstrip("\n")
        except Exception:
            extra = ""
    if extra.strip():
        out.append(extra)

    sys.stdout.write("\n".join(out) + "\n")


if __name__ == "__main__":
    main()
