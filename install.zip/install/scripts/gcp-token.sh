#!/usr/bin/env bash
# OTLP headers helper for Claude Code on macOS/Linux.
# Invoked by `otelHeadersHelper` in managed-settings; must print a JSON object
# of HTTP headers to stdout (or `{}` if the token is unavailable).
#
# Mirror of scripts/gcp-token.cmd (Windows). Keep the two in sync — same PROJECT
# source, same JSON shape, same fallback behavior.

set -uo pipefail

# Project from the per-user env var (set in managed 10-vertex.json today, or by
# the developer via /vertex-setup when the project is not managed). Not scrubbed.
PROJECT="${ANTHROPIC_VERTEX_PROJECT_ID:-}"

TOKEN="$(gcloud auth application-default print-access-token 2>/dev/null)"

if [ -z "${TOKEN}" ] || [ -z "${PROJECT}" ]; then
  printf '{}\n'
else
  printf '{"Authorization": "Bearer %s", "x-goog-user-project": "%s"}\n' "${TOKEN}" "${PROJECT}"
fi
