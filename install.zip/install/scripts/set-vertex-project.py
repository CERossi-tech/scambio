"""ISP - configure Vertex/telemetry PER-DIRECTORY (does NOT start Claude Code).

Cross-OS Python core (one implementation for macOS + Windows), invoked by the thin
set-vertex-project.{sh,cmd} launchers — same pattern as set-vertex-project-doctor.{py,sh,cmd}.
Replaces the previous two full per-OS scripts (.sh embedded-Python / .cmd embedded-PowerShell),
removing the duplication that had to be kept in sync by hand.

Writes the vars into <cwd>/.claude/settings.local.json (personal file, NOT committed):
developer.id (matricola, automatic), gcp.project_id, isp.project_id. Shows existing values
(ENTER = keep). Then the GCP ADC step (automated cycle only) and the optional ISP marketplace
credential caching.

Test seam: if SVP_SKIP_LAUNCH is set, exit right after writing settings.local.json (skip the
gcloud + marketplace steps). stdlib only; Python 3.11+.
"""
import json
import os
import platform
import re
import shutil
import socket
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from collections import OrderedDict as _OD

_HERE = os.path.dirname(os.path.realpath(__file__))
sys.path.insert(0, os.path.join(_HERE, "..", "hooks", "py"))
import isp_hooks as h  # noqa: E402
import chap0_auth  # noqa: E402

IS_WIN = h.IS_WIN
# Prefix-only sanity check: the key must START WITH PRG/STRE/RELE/OPEX. We deliberately do NOT
# validate the rest of the format — tying to a rigid pattern is risky (it could reject valid keys);
# the real validation is server-side. Used only for MANUAL entry; keys picked from the downloaded
# list are server-provided. Keep in sync with vertex-guard.py ISP_RE.
ISP_RE = re.compile(r"^(?:PRG|STRE|RELE|OPEX)")
VERSION_JSON = os.path.join(h.BASE_DIR, "config", "version.json")
# gcpAuthRefresh value: forward-slash path WITH surrounding double-quotes, per OS (kept identical
# to the previous .cmd/.sh so deployed configs are byte-compatible).
_REAUTH = ('"C:/Program Files/ClaudeCode/scripts/gcloud-reauth.cmd"' if IS_WIN
           else '"/Library/Application Support/ClaudeCode/scripts/gcloud-reauth.sh"')
MARKET_URL = "https://bitbucket.intesasanpaolo.com/scm/isp-code-assistant/claude-marketplace.git"


def _global_adc():
    if IS_WIN:
        return os.path.join(os.environ.get("APPDATA", ""), "gcloud", "application_default_credentials.json")
    return os.path.expanduser("~/.config/gcloud/application_default_credentials.json")


def _resolve_api_base():
    """CHAP0 microservice base URL — delegato a chap0_auth.get_api_base_url() (unica fonte:
    api_base_url in chap0-gateway.json[version.json 'env']; nessuna env var).
    None -> free-text ISP prompt, no list menu. (I3: rimosso ramo morto drop-in)"""
    if os.environ.get("SVP_NO_API"):
        return None   # test seam
    return chap0_auth.get_api_base_url()


# --- Windows: enable ANSI/VT + UTF-8 so colors and box-drawing render (Win Terminal / modern
#     PowerShell; best-effort on legacy cmd). No-op on macOS. ---
def _enable_win_ansi():
    if not IS_WIN:
        return
    try:
        import ctypes
        k = ctypes.windll.kernel32
        k.SetConsoleOutputCP(65001)                       # UTF-8 code page
        hout = k.GetStdHandle(-11)                         # STD_OUTPUT_HANDLE
        mode = ctypes.c_uint()
        if k.GetConsoleMode(hout, ctypes.byref(mode)):
            k.SetConsoleMode(hout, mode.value | 0x0004)    # ENABLE_VIRTUAL_TERMINAL_PROCESSING
    except Exception:
        pass


# --- palette (empty when not a TTY / NO_COLOR: keeps pipes + tests clean) ---
_TTY = sys.stdout.isatty() and not os.environ.get("NO_COLOR")


def _sgr(code):
    return code if _TTY else ""


RESET = _sgr("\033[0m")
BOLD = _sgr("\033[1m")
DIM = _sgr("\033[2m")
CYAN = _sgr("\033[96m")
GREEN = _sgr("\033[92m")
AMBER = _sgr("\033[93m")
RED = _sgr("\033[91m")
# back-compat aliases used across the script
C_HDR, C_OK, C_WARN, C_ERR, C_DESC, C_N = BOLD + CYAN, GREEN, AMBER, RED, DIM, RESET


def _paint(s, *codes):
    return ("".join(codes) + s + RESET) if (_TTY and codes) else s


def _cols():
    """Current terminal width (>=48), for full-window framing."""
    try:
        c = shutil.get_terminal_size((80, 24)).columns
    except Exception:
        c = 80
    return max(48, c)


def _banner(title, width=None):
    if width is None:
        width = _cols()
    rule = "─" * (width - 2)
    body = (" " + title)[:width - 2].ljust(width - 2)
    return "\n".join([
        _paint("┌" + rule + "┐", CYAN),
        _paint("│", CYAN) + _paint(body, BOLD, CYAN) + _paint("│", CYAN),
        _paint("└" + rule + "┘", CYAN),
    ])


_ANSI_RE = re.compile(r"\x1b\[[0-9;]*m")


def _vlen(s):
    """Visible length (ANSI escape codes don't count)."""
    return len(_ANSI_RE.sub("", s))


def _clear():
    """Clear screen + scrollback (only on a real terminal), so each wizard step is its own window."""
    if _TTY:
        sys.stdout.write("\033[2J\033[3J\033[H")
        sys.stdout.flush()


def _row(s, width):
    """A box body row with left/right borders + 2-space inner padding (ANSI-aware).
    Plain (uncolored) overlong lines are truncated so the frame never breaks."""
    inner = width - 6
    if "\x1b" not in s and len(s) > inner:
        s = s[:inner - 1] + "…"
    pad = max(0, inner - _vlen(s))
    return _paint("│", CYAN) + "  " + s + " " * pad + "  " + _paint("│", CYAN)


def _window(step, total, title, lines, width=None):
    """Draw a COMPLETE framed panel (top + title + separator + top/bottom margins + body),
    sized to the terminal width. A blocking input line can't sit above a bottom border, so the
    caller prints prompts BELOW the panel (via _pr). Returns the width."""
    if width is None:
        width = _cols()
    _clear()
    rule = "─" * (width - 2)
    header = _paint(title, BOLD, CYAN) + _paint("   · finestra %d/%d" % (step, total), DIM)
    _p(_paint("┌" + rule + "┐", CYAN))
    _p(_row(header, width))
    _p(_paint("├" + rule + "┤", CYAN))
    _p(_row("", width))                                   # top margin
    for ln in lines:
        _p(_row(ln, width))
    _p(_row("", width))                                   # bottom margin
    _p(_paint("└" + rule + "┘", CYAN))                    # complete box on all 4 sides
    return width


def _pr(label):
    """Interactive prompt printed BELOW the closed panel (a blocking input line cannot sit above
    a bottom border, so prompts live under the box). 2-space indent to align with the frame."""
    return _ask("  " + label)


def _hint(s):
    _p("  " + _paint(s, DIM))


_SPIN = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"


def _snake_eat(text):
    """Snake moves right eating `text`:
      - snake head (⠋<) advances one char at a time
      - before moving, the head pauses as * (body flash, stays still)
      - * then becomes . in the trail
    TTY only."""
    if not _TTY:
        return
    frame = 0
    n = len(text)

    for pos in range(n):
        dots = "." * pos
        remaining = text[pos:]
        next_rem  = text[pos + 1:]

        # 1 — snake head at current position
        mouth = "<<<-"[frame % 4]
        sys.stdout.write("\r   " + _paint(dots, DIM)
                         + _paint(_SPIN[frame % len(_SPIN)] + mouth, CYAN)
                         + " " + _paint(remaining, DIM) + "   ")
        sys.stdout.flush()
        time.sleep(0.05)
        frame += 1

        # 2 — asterisk at old position (body flash), head moved to next char; stays still
        mouth = "<<<-"[frame % 4]
        sys.stdout.write("\r   " + _paint(dots, DIM)
                         + _paint("*", AMBER)
                         + _paint(_SPIN[frame % len(_SPIN)] + mouth, CYAN)
                         + (" " + _paint(next_rem, DIM) if next_rem else "") + "   ")
        sys.stdout.flush()
        time.sleep(0.08)
        frame += 1
        # asterisk → dot: absorbed into dots trail for next iteration

    # snake at end of text
    dots = "." * n
    for _ in range(10):
        mouth = "<<<-"[frame % 4]
        sys.stdout.write("\r   " + _paint(dots, DIM)
                         + _paint(_SPIN[frame % len(_SPIN)] + mouth, CYAN) + "   ")
        sys.stdout.flush()
        time.sleep(0.05)
        frame += 1
    sys.stdout.write("\r\033[2K")
    sys.stdout.flush()


def _spin(label, fn, *args, **kwargs):
    """Run a blocking check `fn` while showing a spinner (TTY only). Returns fn's result;
    re-raises its exception. Off a TTY (pipe/tests) it just calls fn — no animation, no output."""
    if not _TTY:
        return fn(*args, **kwargs)
    box = {}

    def _run():
        try:
            box["v"] = fn(*args, **kwargs)
        except BaseException as ex:   # propagate to the caller after the spinner stops
            box["e"] = ex

    t = threading.Thread(target=_run)
    t.start()
    i = 0
    while t.is_alive():
        mouth = "<<<-"[i % 4]   # open 3 frames, closed 1 → slow close
        sys.stdout.write("\r   " + _paint(_SPIN[i % len(_SPIN)] + mouth, CYAN) + " " + _paint(label, DIM))
        sys.stdout.flush()
        t.join(0.08)
        i += 1
    sys.stdout.write("\r\033[2K")   # erase the spinner line
    sys.stdout.flush()
    if "e" in box:
        raise box["e"]
    return box.get("v")


def _p(s=""):
    print(s)


def _ask(prompt):
    try:
        return input(prompt)
    except EOFError:
        return ""


def _load(f):
    """settings.local.json as a dict ({} if absent or empty). An existing but invalid file stops the
    wizard: it is never silently replaced (it may hold the user's own settings)."""
    if not os.path.exists(f):
        return {}
    try:
        with open(f, encoding="utf-8") as fh:
            txt = fh.read()
        d = json.loads(txt) if txt.strip() else {}
    except Exception as e:
        d = e
    if not isinstance(d, dict):
        _p("  " + _paint("✗ %s is not a valid JSON object (%s): fix or remove it, then run "
                         "set-vertex-project again. Nothing was written." % (f, type(d).__name__), RED))
        sys.exit(1)
    return d


def _save_json(path, obj, private=False):
    """Atomic write (temp file in the same folder + os.replace): an interrupted run never leaves a
    truncated file. private=True: owner-only permissions (0600), for files holding a refresh token."""
    tmp = "%s.%d.tmp" % (path, os.getpid())
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600 if private else 0o666)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            json.dump(obj, fh, indent=2, ensure_ascii=False)
            fh.write("\n")
        os.replace(tmp, path)
    except BaseException:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise
    if private:
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass


def _isp_from_otel(otel):
    for p in (otel or "").split(","):
        if p.strip().startswith("isp.project_id="):
            return p.split("=", 1)[1].strip()
    return ""


def _version():
    try:
        with open(VERSION_JSON, encoding="utf-8") as vh:
            return (json.load(vh).get("version") or "").strip()
    except Exception:
        return ""


def _fmt_eur(x):
    try:
        return "{:,.0f}".format(float(x)).replace(",", ".")   # it-style thousands: 33475 -> 33.475
    except Exception:
        return "-"


_FETCH_ERR = ""   # reason of the last _fetch_projects failure, shown to the user (empty = none)


def _fetch_error_reason(e, timeout):
    """Plain-language reason for a /v1/projects failure, so the user is not sent to check the VPN
    when the cause is something else (certificate, token, DNS, invalid response...)."""
    import ssl
    reason = getattr(e, "reason", None)      # urllib.error.URLError wraps the real error here
    inner = reason if isinstance(reason, BaseException) else e
    text = "%s %s" % (e, reason or "")
    if isinstance(inner, ssl.SSLCertVerificationError) or "CERTIFICATE_VERIFY_FAILED" in text:
        fix = ("the Python in C:\\Program Files\\Python31x (MDM)" if IS_WIN else
               "the Command Line Tools Python: /Library/Developer/CommandLineTools/usr/bin/python3 "
               "\"/Library/Application Support/ClaudeCode/scripts/set-vertex-project.py\"")
        return ("the Python in use (%s, %s) does not recognize the ISP certificate of the service - "
                "it is not a VPN problem. Use %s, or remove the personal Python from PATH"
                % (sys.executable, platform.python_version(), fix))
    if isinstance(e, chap0_auth.GatewayAuthError):
        return "CHAP0 gateway token not obtained (%s)" % e
    if isinstance(inner, (socket.timeout, TimeoutError)) or "timed out" in text:
        return "the service did not answer within %gs" % timeout
    if isinstance(inner, socket.gaierror):
        return "service name not resolved (DNS): check the ISPers VPN"
    if isinstance(inner, (ConnectionError, OSError)):
        return "connection to the service failed (%s): check VPN/network" % type(inner).__name__
    if isinstance(e, (ValueError, AttributeError, TypeError)):
        return "invalid response from the service (%s)" % type(e).__name__
    return "%s: %s" % (type(e).__name__, str(e)[:150])


def _fetch_projects(base, uid):
    """GET <base>/v1/projects (header X-User-Id). Returns the list of project dicts,
    [] when the user has no enabled projects (204/empty), None on error/unreachable (reason in
    _FETCH_ERR), or raises urllib.error.HTTPError(403) so the caller can show an authorization error."""
    global _FETCH_ERR
    _FETCH_ERR = ""
    timeout = float(os.environ.get("CHAP0_API_TIMEOUT") or 4.0)
    headers = {"X-User-Id": uid}
    url = base.rstrip("/") + "/v1/projects"
    try:
        # Bearer + 1 retry on 401 handled by chap0_auth (CLAUDECODE-58 gateway auth)
        with chap0_auth.open_with_auth(url, timeout, method="GET", headers=headers) as r:
            if r.status == 204:
                return []
            data = json.load(r)
        return data.get("projects") or []
    except urllib.error.HTTPError as e:
        if e.code == 403:
            raise   # propagate 403 so caller distinguishes "not authorized" from "no projects"
        if e.code == 204:
            return []
        _FETCH_ERR = "the service answered HTTP %s" % e.code
        return None
    except Exception as e:
        _FETCH_ERR = _fetch_error_reason(e, timeout)
        return None


# NB: the ISP project menu is built inline in main's window 1 (panel + prompt-below model);
# the previous _choose_isp helper (open-box rendering) was removed.


_UID_SRC = ""   # where the userid came from, shown again inside the wizard windows


_KRB_NOTE = None   # macOS: (level, text) on the Kerberos ticket, shown next to the matricola (warn/err only)


def _krb_suffix():
    if _KRB_NOTE and _KRB_NOTE[0] in ("warn", "err"):
        return "  " + _paint("⚠ " + _KRB_NOTE[1], RED if _KRB_NOTE[0] == "err" else AMBER)
    return ""


def _uid_line(uid):
    """'utenza' row for the wizard windows (the line printed by _resolve_uid is wiped by _clear())."""
    return (_paint("user      ", DIM) + _paint(uid, BOLD) + "  " + _paint("✓ OK (from %s)" % _UID_SRC, GREEN)
            + _krb_suffix())


def _resolve_uid():
    """Check of the ISP userid, shown to the user: OK line with the source, or the evidence of
    every source tried + how to fix it (then exit, nothing written). Same resolution the hooks use."""
    global _UID_SRC, _KRB_NOTE
    try:
        uid, source, steps = h.resolve_userid_detail()
    except Exception as e:
        uid, source, steps = None, None, [("user check", "error %s" % type(e).__name__, False)]
    if uid:
        _UID_SRC = source
        try:
            _KRB_NOTE = h.kerberos_note(bool(steps and steps[0][2]))   # macOS only (None on Windows)
        except Exception:
            _KRB_NOTE = None
        _p(_paint("✓ User %s — OK (from %s)" % (uid, source), GREEN) + _krb_suffix())
        return uid
    _p(_paint("✗ ISP user not found: a matricola in the format U + 6 characters is needed (e.g. U447742).", RED))
    for src, val, _ok in steps:
        _p("    %-18s %s" % (src + ":", h.userid_step_why(val)))
    for line in h.userid_fix_lines():
        _p("  " + line)
    _p(_paint("  Configuration NOT written.", RED))
    sys.exit(1)


def _old_sessions_gate(interactive):
    """Claude sessions started before the installed package keep running the previous version (binary in
    memory, OTEL attributes of their start): they must be closed first, otherwise nothing is written."""
    while True:
        old = h.stale_claude_sessions()
        if not old:
            return
        _p(_paint("✗ Claude sessions started before the installation of package %s:" % (_version() or "?"), RED))
        for pid, t0, exe in old:
            _p("    PID %-7s started on %s   %s" % (pid, time.strftime("%d/%m %H:%M", time.localtime(t0)), exe))
        _p("  They keep running the previous version, telemetry included.")
        _p("  Close them (/exit in the session, or close the terminal or IDE hosting it).")
        if not interactive:
            _p(_paint("  Configuration NOT written.", RED))
            sys.exit(1)
        try:
            again = input("  Closed? ENTER to check again, q to quit: ").strip().lower() != "q"
        except EOFError:                     # no terminal: nobody can close them now
            again = False
        if not again:
            _p(_paint("  Configuration NOT written.", RED))
            sys.exit(1)


def _write_settings(f, uid, gcp, isp, automated):
    os.makedirs(os.path.dirname(f), exist_ok=True)
    d = _load(f)
    e = d.get("env")
    e = e if isinstance(e, dict) else {}
    ver = _version()
    # preserve extra (non-managed) OTEL attrs already present (e.g. the tracked vpn-ispers=off override)
    managed = ("developer.id", "gcp.project_id", "isp.project_id", "isp.pkg_version", "host.name", "os.type")
    extra = [p.strip() for p in (e.get("OTEL_RESOURCE_ATTRIBUTES") or "").split(",")
             if p.strip() and p.split("=", 1)[0].strip() not in managed]
    otel = "developer.id=%s,gcp.project_id=%s,isp.project_id=%s" % (uid, gcp, isp)
    if ver:
        otel += ",isp.pkg_version=%s" % ver
    # machine identity: OTel standard resource attrs resolved at runtime
    _host = (socket.gethostname() or "").strip()
    _ostype = platform.system().lower()   # windows | darwin | linux
    if _host:
        otel += ",host.name=%s" % _host
    if _ostype:
        otel += ",os.type=%s" % _ostype
    if extra:
        otel += "," + ",".join(extra)
    e["ANTHROPIC_VERTEX_PROJECT_ID"] = gcp
    e["OTEL_RESOURCE_ATTRIBUTES"] = otel
    d["env"] = e
    if automated == "y":
        d["gcpAuthRefresh"] = _REAUTH
    else:
        d.pop("gcpAuthRefresh", None)
        e.pop("GOOGLE_APPLICATION_CREDENTIALS", None)
        d["env"] = e
        _gdir = os.path.join(os.path.dirname(f), "gcp")
        for _fn in ("application_default_credentials.local.json", ".identity"):
            try:
                os.remove(os.path.join(_gdir, _fn))
            except OSError:
                pass
        # also remove the isolated gcloud config dir (its ADC holds a refresh_token) now
        # that this folder is back on the global ADC -> no dangling credential left behind
        shutil.rmtree(os.path.join(os.path.dirname(f), "gcloud"), ignore_errors=True)
    _save_json(f, d)
    _p("   Written to: " + f)
    _p("     ANTHROPIC_VERTEX_PROJECT_ID = " + gcp)
    _p("     OTEL_RESOURCE_ATTRIBUTES    = " + otel)
    _p("     automated cycle             = " + ("on" if d.get("gcpAuthRefresh") else "off"))
    return d


def _gcloud():
    return h.find_gcloud() or ("gcloud.cmd" if IS_WIN else "gcloud")


_LEVEL_STYLE = {"ok": ("✓", GREEN), "warn": ("⚠", AMBER), "err": ("✗", RED)}


def _adc_check(f, gcp, automated):
    """GCP ADC check of this folder (shared logic: isp_hooks.adc_check, also used by the doctor)."""
    local = None
    if automated == "y":
        local = ((_load(f).get("env") or {}).get("GOOGLE_APPLICATION_CREDENTIALS") or "").strip() or None
    try:
        return _spin("Checking GCP credentials…", h.adc_check, gcp, automated == "y", local)
    except Exception as e:
        return [("err", "GCP credentials check not run (%s)" % type(e).__name__)]


def _deps_check():
    """Where python/git/gcloud resolve on PATH (shared logic: isp_hooks.runtime_deps_check, also
    used by the doctor). Report only."""
    try:
        return h.runtime_deps_check()
    except Exception as e:
        return [("err", "software check not run (%s)" % type(e).__name__)]


def _adc_lines(items, width):
    """ADC check items as colored lines wrapped to the panel width (colored lines aren't truncated by
    _row, so they must fit): icon on the first line, continuation lines indented."""
    import textwrap
    rows = []
    for level, msg in items:
        icon, color = _LEVEL_STYLE.get(level, ("•", DIM))
        parts = textwrap.wrap(msg, max(20, width - 12)) or [""]
        rows.append(_paint("%s %s" % (icon, parts[0]), color))
        rows.extend(_paint("  " + p, color) for p in parts[1:])
    return rows


def _gcp_adc(f, gcp):
    """Automated cycle: ensure a valid global ADC, then make the per-directory copy with its own
    quota_project_id and point GOOGLE_APPLICATION_CREDENTIALS at it. Prints below the panel;
    returns a short status. (gcloud's own login output is external.)"""
    g = _gcloud()

    def _check_adc():
        try:
            return subprocess.run([g, "auth", "application-default", "print-access-token"],
                                  stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0
        except Exception:
            return False

    ok = _spin("Checking GCP ADC token…", _check_adc)
    if ok:
        _p("  " + _paint("✓ GCP ADC valid.", GREEN))
        status = "ADC valid"
    else:
        _p("  " + _paint("⚠ GCP ADC missing/expired — opening the browser for the login…", AMBER))
        try:
            if subprocess.run([g, "auth", "application-default", "login"]).returncode != 0:
                _p("  " + _paint("✗ GCP login failed.", RED))
                sys.exit(1)
        except Exception:
            _p("  " + _paint("✗ GCP login failed.", RED))
            sys.exit(1)
        status = "login done"

    global_adc = _global_adc()
    if not os.path.isfile(global_adc):
        _p("  " + _paint("⚠ Global ADC not found: GOOGLE_APPLICATION_CREDENTIALS not set.", AMBER))
        return status + " · global ADC missing"
    adc_dir = os.path.join(os.path.dirname(f), "gcp")
    adc_copy = os.path.join(adc_dir, "application_default_credentials.local.json")
    os.makedirs(adc_dir, exist_ok=True)
    with open(global_adc, encoding="utf-8") as fh:
        adc = json.load(fh)
    adc["quota_project_id"] = gcp
    _save_json(adc_copy, adc, private=True)   # holds the refresh token
    # the copy now holds the CURRENT login: forget the account registered for the old copy, so
    # check-gcp-token re-learns it (otherwise an intended account change is refused as a mismatch)
    try:
        os.remove(os.path.join(adc_dir, ".identity"))
    except OSError:
        pass
    d = _load(f)
    e = d.get("env")
    e = e if isinstance(e, dict) else {}
    e["GOOGLE_APPLICATION_CREDENTIALS"] = adc_copy
    d["env"] = e
    _save_json(f, d)
    _p("  " + _paint("✓ per-directory ADC copy + GOOGLE_APPLICATION_CREDENTIALS set.", GREEN))
    return status + " · per-dir ADC copy"


def _marketplace(choice=None, ask=False):
    """Optional: cache the ISP Bitbucket credentials so the startup marketplace clone succeeds.
    ask=True (wizard): ALWAYS asks; choice ('on'/'off' from --isp-mktplc, if given) is the default
    answer on ENTER, else no. ask=False (non-interactive CLI): choice decides, no prompt.
    Prompts/prints below the panel; returns a short status."""
    if ask:
        dflt = "y" if choice == "on" else "n"
        bbans = _pr("Enable the ISP marketplace now (credential cache)? %s: "
                    % ("[Y/n]" if dflt == "y" else "[y/N]")).strip() or dflt
    else:
        bbans = "y" if choice == "on" else "n"

    # git from the allowlist only: a fake git on PATH would receive the Bitbucket password typed at the prompt
    git = h.trusted_git()
    if not git:
        _p("  " + _paint("⚠ no git in the allowed system folders: marketplace step skipped.", AMBER))
        return "NOT enabled (no allowed git)"

    def _probe(prompt):
        env = dict(os.environ)
        env["GIT_TERMINAL_PROMPT"] = "1" if prompt else "0"
        try:
            return subprocess.run([git, "ls-remote", "--symref", MARKET_URL, "HEAD"],
                                  stdout=subprocess.DEVNULL,
                                  stderr=subprocess.DEVNULL if not prompt else None,
                                  env=env).returncode == 0
        except Exception:
            return False

    cached = _spin("Checking Bitbucket credentials…", _probe, False)
    if bbans[:1].lower() == "y":
        if cached:
            _p("  " + _paint("✓ Bitbucket credentials already cached — marketplace enabled.", GREEN))
            return "enabled (already cached)"
        _p("  " + _paint("A prompt will appear: enter your ISP Bitbucket user/password once.", DIM))
        if _probe(True):
            _p("  " + _paint("✓ Bitbucket credentials cached — marketplace enabled.", GREEN))
            return "enabled"
        _p("  " + _paint("⚠ Bitbucket auth failed — ISP plugins may not load.", AMBER))
        return "NOT enabled (auth failed)"
    if cached:
        _p("  " + _paint("✓ already cached — marketplace stays enabled.", GREEN))
        return "enabled (already cached)"
    _p("  " + _paint("⚠ marketplace NOT enabled (no credentials).", AMBER))
    return "NOT enabled"


_USAGE = """set-vertex-project — configure the GCP/Vertex project + ISP project for the current folder.

Usage:
  set-vertex-project                                       interactive wizard
  set-vertex-project --gcp-auto                            wizard + Y/n prompt for the automatic ADC cycle
  set-vertex-project --gcp-project P --isp-project I [--gcp-auto] [--isp-mktplc on|off]
                                                           non-interactive (P and I together)

Flags:
  --gcp-project VALUE   GCP project (Vertex + OTEL tag). Must be passed with --isp-project.
  --isp-project VALUE   ISP project. Must be passed with --gcp-project.
  --gcp-auto            automatic ADC cycle (gcpAuthRefresh + per-dir ADC copy): interactive
                        shows the Y/n prompt, non-interactive enables it directly.
  --isp-mktplc on|off   ISP marketplace (Bitbucket credential cache). Wizard: the y/n question
                        is always asked, the flag is the default answer (ENTER).
                        Non-interactive: the flag decides, absent = off.
  -h, --help            show this help and exit."""


def _parse_args(argv):
    """Minimal stdlib-only CLI parser.
    Flags:
      -h, --help            print usage and exit 0.
      --gcp-auto            boolean flag: presence = show interactive Y/n prompt (wizard) or enable
                            directly (headless); absence = always OFF, no prompt.
      --gcp-project VALUE   non-interactive GCP project (must come with --isp-project)
      --isp-project VALUE   non-interactive ISP project (must come with --gcp-project)
      --isp-mktplc on|off   marketplace: default answer of the wizard's y/n prompt; decides alone in CLI
    Returns (gcp, isp, auto, mkt): auto is 'y' if --gcp-auto present, else None;
    mkt is 'on'/'off' from --isp-mktplc, default 'off' (like --gcp-auto: absent = off, no prompt)."""
    gcp = isp = auto = None
    mkt = "off"
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            _p(_USAGE)
            sys.exit(0)
        if a == "--gcp-auto":
            auto = "y"
            i += 1
        elif a in ("--gcp-project", "--isp-project", "--isp-mktplc"):
            if i + 1 >= len(argv):
                _p(_paint("✗ %s requires a value." % a, RED))
                sys.exit(1)
            if a == "--gcp-project":
                gcp = argv[i + 1]
            elif a == "--isp-project":
                isp = argv[i + 1]
            else:
                mkt = argv[i + 1].lower()
                if mkt not in ("on", "off"):
                    _p(_paint("✗ --isp-mktplc accepts only on|off (got '%s')." % argv[i + 1], RED))
                    sys.exit(1)
            i += 2
        else:
            _p(_paint("✗ Unknown parameter: %s" % a, RED))
            sys.exit(1)
    if (gcp is None) != (isp is None):
        _p(_paint("✗ --gcp-project and --isp-project must be passed together (non-interactive mode).", RED))
        sys.exit(1)
    return gcp, isp, auto, mkt


def _validate_projects(gcp, isp):
    """Shared project validation for BOTH the interactive wizard and the non-interactive CLI
    path, so the two never diverge (same checks, same error, same exit)."""
    if not gcp:
        _p(_paint("✗ GCP project missing.", RED))
        sys.exit(1)
    if not ISP_RE.match(isp):
        _p(_paint("✗ ISP project '%s' not valid (it must start with PRG, STRE, RELE or OPEX)." % isp, RED))
        sys.exit(1)


def main():
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")   # box-drawing / € on cp1252 consoles
    except Exception:
        pass
    _enable_win_ansi()
    cli_gcp, cli_isp, cli_auto, cli_mkt = _parse_args(sys.argv[1:])
    uid = _resolve_uid()
    _old_sessions_gate(interactive=cli_gcp is None)
    f = os.path.join(os.getcwd(), ".claude", "settings.local.json")

    d = _load(f)
    e = d.get("env") if isinstance(d.get("env"), dict) else {}
    cur_gcp = e.get("ANTHROPIC_VERTEX_PROJECT_ID", "") or ""
    cur_isp = _isp_from_otel(e.get("OTEL_RESOURCE_ATTRIBUTES", ""))
    cur_gar = "on" if d.get("gcpAuthRefresh") else "off"
    # --gcp-auto flag: shows the interactive Y/n prompt (workaround for those who want the feature).
    # Without the flag: always OFF, no prompt (patch default — prevents orphaned gcloud login processes).
    show_auto_prompt = cli_auto is not None   # True when --gcp-auto was passed

    if cli_gcp is not None:   # non-interactive: both --gcp-project and --isp-project given
        gcp, isp = cli_gcp, cli_isp
        automated = "y" if show_auto_prompt else "n"
        _validate_projects(gcp, isp)                    # same validation as the interactive path
        for _ln in _adc_lines(_deps_check(), _cols()):  # same report as the wizard's first window
            _p(_ln)
        _write_settings(f, uid, gcp, isp, automated)
        if not os.environ.get("SVP_SKIP_LAUNCH"):
            # same actions as the interactive path (without the TUI windows): with --gcp-auto run
            # the ADC auto-cycle (login + per-dir ADC copy + GOOGLE_APPLICATION_CREDENTIALS), then
            # the marketplace step. _gcp_adc / _marketplace are the SAME functions the wizard calls.
            if automated == "y":
                _gcp_adc(f, gcp)
            _p("GCP credentials of this folder:")
            for _ln in _adc_lines(_adc_check(f, gcp, automated), _cols()):
                _p("  " + _ln)
            _marketplace(cli_mkt)
        _p("Configuration completed (non-interactive mode).")
        return

    api_base = _resolve_api_base()
    st = {"gcp": cur_gcp, "isp": cur_isp, "auto": "n"}
    TOT = 5 if show_auto_prompt else 4
    deps_items = _deps_check()   # once: report only, never blocks

    while True:   # outer loop: Back from the final recap re-opens the wizard
        # ---- input window 1: ask GCP project FIRST, then fetch+show ISP list ----
        W = _cols()
        lines = ["GCP project for Vertex + OTEL tag (billing/forensics).",
                 "ENTER = keep the current value.", "",
                 _paint("state     ", DIM) + "GCP=%s · ISP=%s · auto-cycle=%s" % (
                     _paint(st["gcp"] or "(none)", BOLD), _paint(st["isp"] or "(none)", BOLD),
                     _paint(cur_gar, GREEN if cur_gar == "on" else DIM)),
                 _uid_line(uid),
                 _paint("folder    " + os.getcwd(), DIM), ""] + _adc_lines(deps_items, W)
        _window(1, TOT, "Vertex project + telemetry", lines, W)
        # 1a. GCP project (before any network call)
        st["gcp"] = _pr("Vertex GCP project [%s]: " % st["gcp"]) or st["gcp"]
        # 1b. fetch ISP projects (spinner below GCP answer), then show framed list
        keys, mode = [], "free"
        groups = _OD()   # populated only when mode=="menu"; init here avoids NameError if refactored
        if api_base:
            try:
                projects = _spin("Fetching ISP projects…", _fetch_projects, api_base, uid)
            except urllib.error.HTTPError as _fe:
                if _fe.code == 403:
                    _p("  " + _paint("⚠ Access to the project API denied (403) — user not authorized. Contact the CHAP0 team.", AMBER))
                projects = None
            if projects is None:
                mode = "unreachable"
            elif not projects:
                mode = "empty"
            else:
                mode = "menu"
                # group projects by first segment (e.g. "RELE0001008") for 2-level drill-down
                for pr in projects:
                    k = pr.get("project_key", "")
                    grp = k.split("-")[0] if "-" in k else k
                    groups.setdefault(grp, []).append(pr)

        if mode == "menu":
            # ---- level 1: pick RELE (or single group → skip straight to level 2) ----
            grp_keys = list(groups.keys())
            if len(grp_keys) == 1:
                chosen_grp = grp_keys[0]
            else:
                # build current-RELE default
                cur_grp = st["isp"].split("-")[0] if st["isp"] and "-" in st["isp"] else ""
                dflt_grp = (grp_keys.index(cur_grp) + 1) if cur_grp in grp_keys else 1
                while True:
                    relw1 = max(8, W - 20)
                    grp_lines = [_paint("GCP project  ", DIM) + _paint(st["gcp"], BOLD), "",
                                 _paint("Select the release (first level):", BOLD)]
                    for gi, gk in enumerate(grp_keys, 1):
                        cnt = len(groups[gk])
                        rel_title = (groups[gk][0].get("release_title") or "")[:max(8, W - len(gk) - 22)]
                        grp_lines.append("  %s %s  %s  %s" % (
                            _paint("[%d]" % gi, BOLD, CYAN),
                            _paint(gk, BOLD),
                            _paint("(%d projects)" % cnt, DIM),
                            _paint(rel_title, DIM)))
                    grp_lines += ["", _paint("[b] back", DIM)]
                    _window(1, TOT, "ISP project — level 1: release", grp_lines, W)
                    ag = _pr("Choose release [1-%d] (ENTER=%d): " % (len(grp_keys), dflt_grp)).strip()
                    if ag in ("b", "<", "indietro", "back"):
                        chosen_grp = None; break
                    if not ag:
                        chosen_grp = grp_keys[dflt_grp - 1]; break
                    if ag.isdigit() and 1 <= int(ag) <= len(grp_keys):
                        chosen_grp = grp_keys[int(ag) - 1]; break
                    _p("  " + _paint("Number out of range.", RED))
                if chosen_grp is None:
                    continue   # back to outer wizard loop (window 1)

            # ---- level 2: pick leaf project within chosen_grp ----
            leaf_projects = groups[chosen_grp]
            # kw2 on 'short' (without the common prefix) so columns align correctly in the window
            def _short(k): return k[len(chosen_grp) + 1:] if k.startswith(chosen_grp + "-") else k
            kw2 = min(max((len(_short(p.get("project_key", ""))) for p in leaf_projects), default=12), 40)
            relw2 = max(8, W - kw2 - 42)
            cur_idx = next((i for i, p in enumerate(leaf_projects, 1)
                            if p.get("project_key") == st["isp"]), 1)
            while True:
                leaf_lines = [_paint("GCP project  ", DIM) + _paint(st["gcp"], BOLD),
                              _paint("Release      ", DIM) + _paint(chosen_grp, BOLD), ""]
                lkeys = []
                for idx, pr in enumerate(leaf_projects, 1):
                    k = pr.get("project_key", "")
                    lkeys.append(k)
                    short = _short(k)
                    leaf_lines.append("  %s %s  %s%s  %s" % (
                        _paint("[%d]" % idx, BOLD, CYAN),
                        _paint(short.ljust(kw2), BOLD),
                        _paint("€%s" % _fmt_eur(pr.get("residual_budget_eur")), GREEN),
                        _paint("/%s" % _fmt_eur(pr.get("total_budget_eur")), DIM),
                        _paint((pr.get("requirement_title") or pr.get("release_title") or "")[:relw2], DIM)))
                leaf_lines += ["", _paint("[b] back to the release   ·   or type a free code", DIM)]
                _window(1, TOT, "ISP project — level 2: %s" % chosen_grp, leaf_lines, W)
                al = _pr("Choose [1-%d] (ENTER=%d), or code: " % (len(lkeys), cur_idx)).strip()
                if al in ("b", "<", "indietro", "back"):
                    if len(grp_keys) == 1:
                        break   # nothing above, break to outer
                    chosen_grp = None; break
                if not al:
                    st["isp"] = lkeys[cur_idx - 1]; break
                if al.isdigit() and 1 <= int(al) <= len(lkeys):
                    st["isp"] = lkeys[int(al) - 1]; break
                st["isp"] = al; break   # free code: server-authoritative validation
            if chosen_grp is None:
                continue   # back to level 1
        elif mode == "unreachable":
            _p("  " + _paint("⚠ Project list not available: %s." % (_FETCH_ERR or "service not reachable (ISPers VPN?)"), AMBER))
            _p("  " + _paint("  The project already declared is kept, otherwise OPEX.", DIM))
            _dfl = st["isp"] or "OPEX"
            st["isp"] = _pr("ISP project code [%s]: " % _dfl).strip() or _dfl
        elif mode == "empty":
            st["isp"] = _pr("No project enabled — manual code or ENTER=OPEX: ").strip() or "OPEX"
        else:
            _dfl = st["isp"] or "OPEX"
            st["isp"] = _pr("ISP project (PRG#######/STRE#######/RELE#######/OPEX) [%s]: " % _dfl).strip() or _dfl

        # ---- window 2 (only when --gcp-auto flag): interactive Y/n for the auto-cycle ----
        if show_auto_prompt:
            _window(2, TOT, "GCP authentication cycle",
                    ["y = AUTOMATIC — Claude re-authenticates + local ADC copy.",
                     "n = MANUAL — gcloud login by hand; global ADC.", "",
                     _paint("choices   ", DIM) + "GCP=%s · ISP=%s" % (
                         _paint(st["gcp"] or "-", BOLD), _paint(st["isp"] or "-", BOLD)),
                     _paint("[b] back   ·   y / n + ENTER = confirm", DIM)])
            ans = ""   # defensive init: _ask() returns "" on EOFError but explicit is clearer
            while True:
                ans = _pr("Automatic? [y/N]: ").strip().lower()
                if ans in ("b", "<", "indietro", "back"):
                    break   # back to window 1 via outer loop restart
                if ans in ("y", "yes", "s", "si"):
                    st["auto"] = "y"; break
                else:
                    st["auto"] = "n"; break
            if ans in ("b", "<", "indietro", "back"):
                continue
        else:
            st["auto"] = "n"   # default off, no prompt

        gcp, isp, automated = st["gcp"], st["isp"], st["auto"]
        _validate_projects(gcp, isp)

        _write_settings(f, uid, gcp, isp, automated)

        if os.environ.get("SVP_SKIP_LAUNCH"):
            return

        # ---- action windows (GCP auth + marketplace): numbered 2-3 or 3-4 depending on TOT ----
        gcp_win = 3 if show_auto_prompt else 2
        mkt_win = 4 if show_auto_prompt else 3
        if automated != "y":
            _window(gcp_win, TOT, "GCP authentication",
                    ["Gets/validates the GCP ADC token (Vertex + telemetry).", "",
                     _paint("MANUAL mode — run the login yourself:", DIM),
                     _paint("gcloud auth application-default login", BOLD),
                     _paint("gcloud auth application-default set-quota-project " + gcp, BOLD),
                     _paint("(the global quota must == the project, otherwise vertex-guard blocks)", DIM)])
            gcp_status = "manual (login up to you)"
        else:
            _window(gcp_win, TOT, "GCP authentication", ["Gets/validates the GCP ADC token (Vertex + telemetry)."])
            gcp_status = _gcp_adc(f, gcp)
        adc_items = _adc_check(f, gcp, automated)   # shown in the recap (lines printed here get cleared)

        _window(mkt_win, TOT, "ISP marketplace access (Bitbucket)",
                ["Bitbucket credential cache (without it, ISP plugins do not start)."])
        mkt_status = _marketplace(cli_mkt, ask=True)   # wizard: always asks (flag = default answer)

        # ---- recap window ----
        recap_win = 5 if show_auto_prompt else 4
        f_disp = f if len(f) <= 56 else "…" + f[-55:]
        W = _cols()
        _window(recap_win, TOT, "Summary — check and confirm",
                ["Review the choices and the check results before leaving.", "",
                 _paint("user         ", DIM) + _paint(uid, BOLD) + "  " + _paint("✓ OK (from %s)" % _UID_SRC, GREEN),
                 _paint("GCP project  ", DIM) + _paint(gcp, BOLD),
                 _paint("ISP project  ", DIM) + _paint(isp, BOLD),
                 _paint("auto-cycle   ", DIM) + _paint("on" if automated == "y" else "off", GREEN if automated == "y" else DIM)
                 + ("" if show_auto_prompt else _paint("  (use --gcp-auto to change it)", DIM)),
                 _paint("GCP ADC      ", DIM) + gcp_status,
                 _paint("marketplace  ", DIM) + mkt_status,
                 _paint("settings     ", DIM) + f_disp,
                 "", _paint("GCP credentials of this folder:", BOLD)]
                + _adc_lines(adc_items, W)
                + ["", _paint("[Enter] finish   ·   [b] go back to change the choices", DIM)], W)
        r = _pr("> ").strip().lower()
        if r in ("b", "<", "indietro", "back"):
            continue      # riapri il wizard mantenendo le scelte correnti
        break

    _clear()
    _snake_eat("Configuration completed…")
    _p(_banner("✓ Configuration completed"))
    _p("   Start Claude with:  " + _paint("claude", BOLD))


if __name__ == "__main__":
    main()
