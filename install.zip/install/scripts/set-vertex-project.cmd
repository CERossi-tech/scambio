@echo off
rem launcher -> set-vertex-project.py (cross-OS core). Checks python FIRST so that a missing
rem python - itself a managed deploy prerequisite the hooks depend on - stays diagnosable here.
rem Python from the same admin-only allowlist as the hooks (find-python.cmd), NEVER from PATH:
rem a personal python first on PATH has its own CA bundle without the ISP CA, or can be an impostor.
call "%~dp0..\hooks\find-python.cmd"
if not defined PY (
  echo ERROR: no Python in C:\Program Files\Python31x - it is a managed deploy prerequisite ^(the hooks need it too^).
  echo   Ask for the standard Python installation. Diagnosis: set-vertex-project-doctor
  exit /b 1
)
"%PY%" -E -S -B "%~dp0set-vertex-project.py" %*
