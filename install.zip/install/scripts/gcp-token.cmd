@echo off
setlocal
set TOKEN=
rem Project from the per-user env var (set in managed 10-vertex.json today, or by
rem the developer via /vertex-setup when the project is not managed). Not scrubbed.
set PROJECT=%ANTHROPIC_VERTEX_PROJECT_ID%
for /f "usebackq delims=" %%T in (`gcloud.cmd auth application-default print-access-token 2^>nul`) do set "TOKEN=%%T"
if not defined TOKEN (
    echo {}
) else if not defined PROJECT (
    echo {}
) else (
    echo {"Authorization": "Bearer %TOKEN%", "x-goog-user-project": "%PROJECT%"}
)
endlocal