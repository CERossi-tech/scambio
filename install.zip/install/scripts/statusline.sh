#!/bin/sh
# ISP managed status line - macOS wrapper. Forwards Claude Code's stdin JSON to
# statusline.py (-E -S). The .py sits next to this script. Python from the same root-owned
# allowlist as the hooks (find-python.sh), never from PATH.
here="$(cd "$(dirname "$0")" && pwd)"
. "$here/../hooks/find-python.sh"
if [ -z "$PY" ]; then
  echo "ISP status line: no Python in the allowed system folders (xcode-select --install)"
  exit 0
fi
exec "$PY" -E -S -B "$here/statusline.py"
