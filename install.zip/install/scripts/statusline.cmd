@echo off
rem ISP managed status line - Windows wrapper. Forwards Claude Code's stdin JSON to
rem statusline.py (-E -S). The .py sits next to this .cmd (%~dp0). Python from the same
rem admin-only allowlist as the hooks (find-python.cmd), never from PATH.
call "%~dp0..\hooks\find-python.cmd"
if not defined PY (
  echo ISP status line: no Python in C:\Program Files\Python31x
  exit /b 0
)
"%PY%" -E -S -B "%~dp0statusline.py"
