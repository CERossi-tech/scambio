@echo off
rem launcher -> set-vertex-project-doctor.py (cross-OS core). Checks python FIRST so that a missing
rem python - itself a managed deploy prerequisite the hooks depend on - stays diagnosable here.
rem Python from the same allowlist as the hooks (find-python.cmd). If none is allowed the doctor
rem still runs on the python of PATH, with a warning, so that the problem stays diagnosable.
call "%~dp0..\hooks\find-python.cmd"
if defined PY (
  "%PY%" -E -S -B "%~dp0set-vertex-project-doctor.py" %*
  exit /b
)
echo WARNING: no Python in C:\Program Files\Python31x: the hooks and set-vertex-project cannot run.
echo   Running the doctor with the python of PATH.
where python >nul 2>&1
if errorlevel 1 (
  echo ERROR: python not found at all.
  exit /b 1
)
python -E -S -B "%~dp0set-vertex-project-doctor.py" %*
